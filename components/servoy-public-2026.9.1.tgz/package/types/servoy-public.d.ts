import * as i0 from '@angular/core';
import { AfterViewInit, OnInit, OnChanges, OnDestroy, ElementRef, Renderer2, ChangeDetectorRef, SimpleChanges, TemplateRef, Signal, PipeTransform, ViewContainerRef } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { NumberSymbol } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { ControlValueAccessor } from '@angular/forms';
import { DateTime } from 'luxon';
import { ComponentFixture } from '@angular/core/testing';

/**
  * This is the servoy api class for components that is injected into the component by default.
  * The  {@link ServoyBaseComponent} has this as an Input property, so every component extending the  {@link ServoyBaseComponent} will have "this.servoyApi"
  * to interact with the servoy system and notify the server.
  */
declare abstract class ServoyApi {
    /**
     * This should be called by components when they want to show a form, optionally a relationname or formindex can be given.
     * It will return a Promise that gives a boolean if the form could be shown (then the component can actually show this form)
     */
    abstract formWillShow(formname: string, relationname?: string, formIndex?: number): Promise<boolean>;
    /**
     * This should be called by components when they it wants to hide a form, optionally a relationname or formindex can be given and
     * also the form/relation/index that should be shown when the given form can be hidden so there is only 1 call to hide one form and show another.
     *
     * It will return a Promise that gives a boolean if the form could be hidden (onHide of a form doesn't block the hide)
     */
    abstract hideForm(formname: string, relationname?: string, formIndex?: number, formNameThatWillShow?: string, relationnameThatWillBeShown?: string, formIndexThatWillBeShown?: number): Promise<boolean>;
    /**
      * Call to notify the server when this property is gone in edit mode (focus in a field). This can also be configured by using the {@link StartEditDirective}
      */
    abstract startEdit(propertyName: string): void;
    /**
      * This apply is only needed for nested dataproviders, so a dataprovider property of custom type, this will push and apply the data to the data model.
      * Normal main spec model dataprovider should be pushed using an Change Emitter.
      */
    abstract apply(propertyName: string, value: unknown): void;
    /**
      * Call this components serverside api with the given arguments
      */
    abstract callServerSideApi(methodName: string, args: Array<unknown>): void;
    /**
      * Returns true if the component is currently rendered in the designer (so it can render with some sample data if needed)
      */
    abstract isInDesigner(): boolean;
    /**
      * Returns true if this component can trust the html it wants to display (no need to sanatize it).
      * This can be a client property set on this component itself or more application wide.
      */
    abstract trustAsHtml(): boolean;
    /**
      * Returns true if this component is placed on a css positioned form (not responsive)
      */
    abstract isInAbsoluteLayout(): boolean;
    /**
      * Returns the markupid that this component can use for itself, can be used like this in the template:  [id]="servoyApi().getMarkupId()"
      */
    abstract getMarkupId(): string;
    /**
      * Returns the formname where this component is part of.
      */
    abstract getFormName(): string;
    /**
      * Internal api, used by {@link ServoyBaseComponent} to register itself to implementors of this ServoyApi object (like form containers)
      */
    abstract registerComponent(component: ServoyBaseComponent<HTMLElement>): void;
    /**
     * Internal api, used by {@link ServoyBaseComponent} to unregister itself to implementors of this ServoyApi object (like form containers)
      */
    abstract unRegisterComponent(component: ServoyBaseComponent<HTMLElement>): void;
    /**
      * Returns the value for the given client property key that was set at the server side on this component.
      */
    abstract getClientProperty(key: string): any;
}

/**
 * This is the BaseComponent all Titanium NGClient components should be extending
 *  It takes care of the initialization of the component by calling {@link #svyOnInit} when the component is fully constructed
 * This will only be fully done when the main div of the component has the #element reference in the tag. So that the ViewChild of angular can be resolved.
 * So the main div of a component should be something like: <div #element>. This will the be the element that will be returned by  {@link #getNativeElement}
 *
 * This base component provides the servoyApi {@link ServoyApi}, the name and also takes care of the custom attributes set in the designer.
 *
 * For performance reasons all compoents should be configured to use:  changeDetection: ChangeDetectionStrategy.OnPush in there Component configuration.
 * this way component detection is only done when a push happens on the Input fields.  If you need to trigger a change detection besides that (because of timeouts or other events)
 * call this.detectChanges()
 */
declare class ServoyBaseComponent<T extends HTMLElement> implements AfterViewInit, OnInit, OnChanges, OnDestroy {
    readonly name: i0.InputSignal<string>;
    readonly servoyApi: i0.InputSignal<ServoyApi>;
    readonly servoyAttributes: i0.InputSignal<{
        [property: string]: string;
    }>;
    readonly elementRef: i0.Signal<ElementRef<T> | undefined>;
    protected readonly renderer: Renderer2;
    protected cdRef: ChangeDetectorRef;
    private viewStateListeners;
    private componentContributor;
    private initialized;
    private changes;
    constructor(renderer?: Renderer2, cdRef?: ChangeDetectorRef);
    /**
     *  final method, do not override use {@link #svyOnInit} for this
     */
    ngOnInit(): void;
    /**
     *  final method, do not override use {@link #svyOnInit} for this
     */
    ngAfterViewInit(): void;
    /**
     *  final method, do not override use {@link #svyOnChanges} for this
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Angular onDestroy hook, called when the component is removed from the dom, use to clean up stuff
     * make sure you call super.ngOnDestroy()
     */
    ngOnDestroy(): void;
    /**
     * This method should be overwritten to get a callback when the component is initialized
     * The template of the component must have an #element in its main tag, else this init will not resolve.
     * make sure you call super.svyOnInit() to get the default behavior
     */
    svyOnInit(): void;
    /**
     * The Servoy replacement of the angular ngOnChanges, this will only be called when the component is initalized.
     *  So that you are sure that you can reference the native element through the renderer to configure it.
     */
    svyOnChanges(_changes: SimpleChanges): void;
    /**
     * Call this method to trigger a change detection if something of this component is changed which didn't came directly from an @Input field change.
     * other events like timeouts or promise resolvements could result in that the component needs to detect stuff.
     */
    detectChanges(): void;
    /**
     * this should return the main native element (like the first div) which is marked as #element in the main div.
     */
    getNativeElement(): T;
    /**
     * sub classes can return a different native child then the default main element.
     */
    getNativeChild(): HTMLElement;
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getRenderer(): Renderer2;
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getWidth(): number;
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getHeight(): number;
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getLocationX(): number;
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getLocationY(): number;
    /**
     * Direcives can add a {@link IViewStateListener} to this component so they are notified when the component is fully initialized
     * so this is for directives the same event and the {@link #svyOnInit} for subcomponents.
     * Directives needs to have a property to gain access to the component by using a attribute on the tag (besides the attribute directive itself) like [hostcomponent]="this"
     */
    addViewStateListener(listener: IViewStateListener): void;
    /**
     * Removes the viewstatelistener
     */
    removeViewStateListener(listener: IViewStateListener): void;
    /**
     * @internal
     */
    protected initializeComponent(): void;
    /**
     * @internal
     */
    protected addAttributes(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServoyBaseComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ServoyBaseComponent<any>, never, never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "servoyApi": { "alias": "servoyApi"; "required": false; "isSignal": true; }; "servoyAttributes": { "alias": "servoyAttributes"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Interface for diretives to register itself to the the ServoyBaseComponent, to get the "svyOnInit" event.
 */
interface IViewStateListener {
    afterViewInit(): void;
}
/**
 * Services can use this to inject itself this contributor and then registering a listener {@link IComponentContributorListener}
 * then a service will get an event when a component is created over all forms.
 */
declare class ComponentContributor {
    private static listeners;
    componentCreated(component: ServoyBaseComponent<any>): void;
    addComponentListener(listener: IComponentContributorListener): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentContributor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComponentContributor>;
}
/**
 * The interface used for {@link ComponentContributor} to listen for {@link ServoyBaseComponent} creation
 */
interface IComponentContributorListener {
    componentCreated(component: ServoyBaseComponent<any>): void;
}

interface IDeferred<T> {
    readonly promise: Promise<T>;
    reject(reason: unknown): void;
    resolve(value: T): void;
}
declare class Deferred<T> implements IDeferred<T> {
    readonly promise: Promise<T>;
    private _resolve;
    private _reject;
    constructor();
    reject(reason: unknown): void;
    resolve(value: T): void;
}

declare class JSEvent {
    formName?: string;
    elementName?: string;
    svyType: string;
    eventType: string;
    modifiers?: number;
    x?: number;
    y?: number;
    timestamp: number;
    data?: unknown;
}
interface EventLike {
    target: EventTarget;
    altKey?: boolean;
    shiftKey?: boolean;
    ctrlKey?: boolean;
    metaKey?: boolean;
    pageX?: number;
    pageY?: number;
    detail?: any;
}

declare class WindowRefService {
    get nativeWindow(): Window;
    static ɵfac: i0.ɵɵFactoryDeclaration<WindowRefService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WindowRefService>;
}

declare enum LogLevel {
    ERROR = 1,
    WARN = 2,
    INFO = 3,
    DEBUG = 4,
    SPAM = 5
}
declare class LogConfiguration {
    isDebugMode: boolean;
    level: LogLevel;
    constructor(isDebugMode?: boolean, level?: LogLevel);
}
interface ServoyWindow extends Window {
    svyLogConfiguration: LogConfiguration;
    logFactory: LoggerFactory;
    logLevels: {
        [property: string]: LogLevel;
    };
    console: Console;
}
declare class LoggerService {
    private svyLogConfiguration;
    private className;
    private console;
    private enabled;
    constructor(windowRefService: WindowRefService, svyLogConfiguration: LogConfiguration, className: string);
    buildMessage(message: string | (() => string)): string | undefined;
    get spam(): (...data: unknown[]) => void;
    get debug(): (...data: unknown[]) => void;
    get info(): (...data: unknown[]) => void;
    get warn(): (...data: unknown[]) => void;
    get error(): (...data: unknown[]) => void;
    toggleDebugMode(): boolean;
    get logLevel(): LogLevel;
    set logLevel(level: LogLevel);
    private getTime;
}
declare class LoggerFactory {
    private instances;
    private defaultLogConfiguration;
    private windowRefService;
    constructor(windowRefService?: WindowRefService);
    getLogger(cls: string): LoggerService;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerFactory>;
}

declare class PopupForm {
    component: string;
    form: string;
    x: number;
    y: number;
    width: number;
    height: number;
    showBackdrop: boolean;
    doNotCloseOnClickOutside: boolean;
    onClose: Callback;
    parent: PopupForm;
    parentInstance: object;
}
declare class Callback {
    formname: string;
    script: string;
}

/**
 * This is the main servoy service that can be used by components or services to get a lot of information of the current client
 * or interact with the server by calling the server or generating the correct urls to the server.
 */
declare abstract class ServoyPublicService {
    /**
     * get the character for the NumberSymbol that is given like Decimal from the current locale of the client.
     */
    getLocaleNumberSymbol(symbol: NumberSymbol): string;
    /**
     * Let the system op the file dialog, this is used by the {@link UploadDirective}
     */
    abstract showFileOpenDialog(title: string, multiselect: boolean, acceptFilter: string, url: string): void;
    abstract showMessageDialog(dialogTitle: string, dialogMessage: string, styleClass: string, values: string[], buttonsText: string[], inputType: string, defaultButtonIndex: number, okButtonText?: string): Promise<string>;
    /**
     * This created the correct {@link JSEvent} object that is used for handler calls to the server, tries to fill in as much as it can.
     */
    abstract createJSEvent(event: EventLike, eventType: string, contextFilter?: string, contextFilterElement?: unknown): JSEvent;
    /**
     * Returns the current locale string the client is in.
     */
    abstract getLocale(): string;
    /**
     * Returns the full {@link Locale} object of the client.
     */
    abstract getLocaleObject(): Locale;
    /**
     * Returns ag grid's locale map for the current locale
     */
    abstract getAGGridLocale(): {
        [key: string]: string;
    };
    /**
     * Internal api, directives can use this to call server side registered services. (this is internal Servoy services).
     * Do not try to use this instead of callServiceServerSideApi() - which has to be used for calling server side JS scripting of custom services from packages.
     */
    abstract callService<T>(serviceName: string, methodName: string, argsObject: unknown, async?: boolean): Promise<T>;
    /**
     * Get the i18n messages for the given keys.
     *
     * @deprecated use listenForI18NMessages(...keys: string[]):I18NListener
     */
    abstract getI18NMessages(...keys: string[]): Promise<unknown>;
    /**
     * Get and listen for i18n message keys, this will call I18NListener.messages() for with an object of key value pairs for all the keys given for the current locale.
     * It will also call that same method again if the locale changed in the client with the updated values.
     * If the caller is destroyed the I18NListener.destroy() must be called to deregister this listener.
     */
    abstract listenForI18NMessages(...keys: string[]): I18NListener;
    /**
     * Use this to call a script at the server that was given to use by a function spec property.
     */
    abstract executeInlineScript<T>(formname: string, script: string, params: unknown[]): Promise<T>;
    /**
     * Services can use this to call there own server side api
     */
    abstract callServiceServerSideApi<T>(servicename: string, methodName: string, args: Array<unknown>): Promise<T>;
    /**
     * Returns an upload url that can be used to push binary data to the given form/component/property combination. (MediaUpload component)
     */
    abstract generateUploadUrl(formname: string, componentName: string, propertyName: string, tus?: boolean): string;
    /**
     * Returns an upload url to push binary data to a service serverside function (that gets the file as an argument)
     */
    abstract generateServiceUploadUrl(serviceName: string, apiFunctionName: string, tus?: boolean): string;
    /**
     * Use this to get a url to a solutions media for download or src/href
     */
    abstract generateMediaDownloadUrl(media: string): string;
    /**
     * returns the ui property value for the given key that is set as a ui property on the application.
     */
    abstract getUIProperty(key: string): any;
    /**
      * returns the {@link IFormCache} on the client to be able to get some extra data from it like size of that form.
      */
    abstract getFormCacheByName(containedForm: string): IFormCache;
    /**
     * Services should use this function to push there changed model data to the server so the data is accesable in a servoy solution or stored for a browser refresh.
     * @deprecated please use the version of this method that also gives the oldPropertyValue as an argument - sendServiceChangeToServer
     */
    abstract sendServiceChanges(serviceName: string, propertyName: string, propertyValue: unknown): void;
    /**
     * Services should use this function to push there changed model data to the server (when needed),
     * so the data is accesable in a servoy solution or stored for a browser refresh.
     *
     * @param propertyValue the new value that the service has (and should send to server) for the given propertyName; if you didn't assign it yet to the service's property,
     *                      this method will do it for you.
     * @param oldPropertValue the value that this property used to have before (or has if you did not change the reference - in this case it should be the same as „propertyValue”);
     *                        this value is used in case of smart types (custom array/custom objects) in order to detect if it's a full change by reference for example
     */
    abstract sendServiceChangeToServer(serviceName: string, propertyName: string, propertyValue: unknown, oldPropertyValue: unknown): void;
    /**
     * show a form popup {@link PopupForm}
     */
    abstract showForm(popup: PopupForm): void;
    /**
     * cancel/hide the form popup that is currently showing.
     */
    abstract cancelFormPopup(disableClearPopupFormCallToServer_or_name: boolean | string): void;
    /**
     * Internal api, used by ngutils services to set the styleclass of forms, the argument is a map of formname->styleclases
     *
     * @internal
     */
    abstract setFormStyleClasses(styleclasses: {
        property: string;
    }): void;
    /**
     * Returns the value of the testing mode flag (servoy.ngclient.testingMode) from the admin page
     */
    abstract isInTestingMode(): boolean;
    /**
     * Returns a TemplateRef for rendering a child component inside a formcomponent property.
     * The formName identifies which form hosts the component that needs to render formcomponent children.
     * The item should have a 'type' property with the camelCased component directive name.
     */
    abstract getTemplateForFormComponentChild(formName: string, item: IComponentCache): TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServoyPublicService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServoyPublicService>;
}
/**
 * Cache for a servoy form.
 * Simple interface around form data instances (not the actual form ui instances) on the client.
 */
interface IFormCache {
    absolute: boolean;
    size: {
        width: number;
        height: number;
    };
    getComponent(name: string): IComponentCache | undefined;
}
/**
 * Simple interface around component data instances on the client
 */
interface IComponentCache {
    name: string;
    model: {
        [property: string]: any;
    };
    layout: {
        [property: string]: any;
    };
}
/**
 * Locale object that has the language and country fields.
 */
interface Locale {
    language: string;
    country: string;
    full: string;
}
interface I18NListener {
    messages(callback: (messages: Map<string, string>) => void): I18NListener;
    destroy(): void;
}

type CustomObjectTypeConstructor = (new () => ICustomObjectValue);
declare class SpecTypesService {
    private log;
    private registeredCustomObjectTypes;
    constructor(logFactory?: LoggerFactory);
    /**
     * This method is DEPRECATED, as now, more .spec info about components/services is being sent to client (types + pushToServer info), and
     * for pushToServer SHALLOW or DEEP in .spec file (for custom objects/custom arrays), a proxy object will be used
     * on client to automatically detect reference changes and send them to server as needed.
     *
     * So there isn't a need anymore to provide 'watched' properties list by extending BaseCustomObject or manually pushing them. Just make sure that, if it
     * has pushToServer > ALLOW and if you assign a new full value (array or obj) to the property on client, read it back from the model after it's pushed to server (as that will be
     * updated/wrapped into a Proxy of your new value) and use that one instead.
     *
     * If you still need/want to use a custom class for your custom objects (maybe you want to have methods on them or do instanceof Checks in code...) you
     * can do that by calling registerCustomObjectType(...) instead; the constructor's class you give there does not need to be a BaseCustomObject. For backwards
     * compatibility, this method will call the new registerCustomObjectType(...).
     *
     * @deprecated
     */
    registerType(customObjectTypeName: string, customObjectTypeConstructor: typeof BaseCustomObject): void;
    /**
     * Registers a custom object type constructor to the system for components that want to use specialized classes for custom objects that come from the server.
     *
     * Calling this IS NOT MANDATORY. You can just use simple interfaces (or interfaces that extend as well ICustomObjectValue) for your custom objects now. See .registerType(...) deprecation comment for more information.
     *
     * @param customObjectTypeName the type name as defined in the .spec of the component/service, prefixed with the name of the
     *          component/service + ".". For example "bootstrapextracomponents-navbar.menuItem".
     * @param customObjectTypeConstructor a constructor that custom object type should use when receiving new values from the server for
     *          the given customObjectTypeName. Be aware though that the values of the given class constructor will be augmented (via prototype chain)
     *          with some internal implementation of the custom object type.
     */
    registerCustomObjectType(customObjectTypeName: string, customObjectTypeConstructor: CustomObjectTypeConstructor): void;
    getRegisteredCustomObjectTypeConstructor(customObjectTypeName: string): CustomObjectTypeConstructor | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpecTypesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SpecTypesService>;
}
/**
 * This type is DEPRECATED.
 *
 * You can remove extends BaseCustomObject from any custom types that you have.
 *
 * You can even turn your custom types into interfaces (that can also - optionally - implement ICustomObjectValue - if you need that; see details below). The
 * system will automatically generate the correct object for that interface (as long as it follows what is defined in the .spec file for this custom
 * object) - and you can use it.
 *
 * For example you can use something like ('extends ICustomObjectValue' is only needed for sending deeply nested changes to server in case of plain 'object'
 * typed subproperties):
 *      @Input() myCustomObjectProperty: IMyCustomObject;
 *
 *      interface IMyCustomObject extends ICustomObjectValue {
 *          p1: string; // for example
 *          (... any properties that are defined in the component's spec file for this custom object ...)
 *      }
 *
 * Now, more .spec info about components/services is being automatically sent to client (types + pushToServer info), and
 * for pushToServer SHALLOW/DEEP or even for ALLOW in .spec file (for custom objects/custom arrays), a proxy object will be used
 * on client to automatically detect reference changes in subproperties (and send them to server if it is SHALLOW/DEEP) (note: for deep nested JSON changes
 * in plain 'object' subproperties - if any - you need to use ICustomObjectValue interface in order to tell the system that it changed, but
 * that is probably rarely needed).
 *
 * So there isn't a need anymore to provide 'watched' properties list by extending BaseCustomObject or to manually push them to server by using
 * getter/setter pair; that is done automatically via use of Proxy objects. Just make sure that, if it has pushToServer >= ALLOW, and if you assign
 * a new full value (full custom object value - although it is the same for arrays from .spec as well) to the property on client-side, you read it
 * back from the model when you need to use it (as that reference will be updated to a newly created Proxy of your new value - after being sent to server)
 * and use the new reference instead.
 *
 * @deprecated
 */
declare class BaseCustomObject {
    /**
     * DEPRECATED: See class jsdoc for more information.
     *
     * @deprecated
     */
    getStateHolder(): BaseCustomObjectState;
    /**
     * DEPRECATED: See class jsdoc for more information.
     *
     * @deprecated
     */
    getWatchedProperties(): Array<string>;
}
/**
 * DEPRECATED: See BaseCustomObject jsdoc for more information.
 *
 * @deprecated
 */
declare class BaseCustomObjectState {
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    getChangedKeys(): Set<string | number>;
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    markAllChanged(_notifyListener: boolean): void;
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    setPropertyAndHandleChanges(thisBaseCustoomObject: any, internalPropertyName: any, _propertyName: any, value: any): void;
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    notifyChangeListener(): void;
}
/**
 * This type is DEPRECATED (you can stop using ICustomArray for arrays declared as such in component/service .spec files; just use them as Array<T> or
 * ICustomArrayValue<T>).
 *
 * You can expect these custom arrays to implement ICustomArrayValue (if you need that; see details below). The system
 * will automatically generate the correct value implementing that interface for typed arrays (as long as it follows what is defined in the .spec file)
 * - and you can use it.
 *
 * Now, more .spec info about components/services is being sent to client (types + pushToServer info, ...), and
 * for pushToServer SHALLOW/DEEP or even for ALLOW in .spec file (for custom objects/custom arrays), a proxy object will be used
 * on client to automatically detect reference changes in elements (and send them to server if it is SHALLOW/DEEP) (note: for deep nested JSON changes
 * in plain 'object' elements of an array - if any - you need to use the ICustomArrayValue interface in order to tell the system that it changed, but
 * that is probably rarely needed).
 *
 * So there isn't a need anymore mark as changed manually (except for the deep neste JSON elements case mentioned above) or to manually push them to server
 * by using getter/setter pair; that is done automatically via use of Proxy objects. Just make sure that, if it has pushToServer >= ALLOW, and if you assign
 * a new full value (full custom array value - although it is the same for custom objects from .spec as well) to the property on client-side, you read it
 * back from the model when you need to use it (as that reference will be updated to a newly created Proxy of your new value, that also implements ICustomArrayValue
 *  - after being sent to server) and use the new reference instead.
 *
 * @deprecated
 */
interface ICustomArray<T> extends Array<T> {
    getStateHolder(): ArrayState;
    markForChanged(): void;
}
/**
 * This type is DEPRECATED - see ICustomArray jsdoc for more information.
 *
 * @deprecated
 */
declare class ArrayState extends BaseCustomObjectState {
    /**
     * DEPRECATED: See ICustomArray jsdoc for more information.
     *
     * @deprecated
     */
    initDiffer(): void;
    /**
     * DEPRECATED: See ICustomArray jsdoc for more information.
     *
     * @deprecated
     */
    clearChanges(): void;
    /**
     * DEPRECATED: See ICustomArray jsdoc for more information.
     *
     * @deprecated
     */
    getChangedKeys(): Set<string | number>;
}
/** @deprecated see ArrayState jsdoc */
declare const getDeprecatedCustomArrayState: () => ArrayState;
/**
 * Value present for properties in model of Servoy components/services if they are declared in the .spec file as custom arrays. (someType[])
 *
 * For example you can use:
 *     @Input() myCustomArrayProperty: Array<MyArrayElementType>;
 *
 * or, if you needed to send deeply nested changes to server in case of plain 'object' array element type (see markElementAsHavingDeepChanges(...) method jsdoc):
 *     @Input() myCustomArrayProperty: ICustomArrayValue<MyArrayElementType>;
 *
 */
interface ICustomArrayValue<T> extends Array<T> {
    /**
     * Calling this method is (rarely) only needed if both:
     *   1. you want to send client side changes back to the server (calculated pushToServer .spec config for the elements of this array is >= ALLOW)
     *   2. AND you store in the array simple json values that are nested, and type elements simply as 'object' in the .spec file. So if the array
     *      is declared in the .spec file as 'object[]' and you change an element/index in it client-side not by reference, but
     *      by content nested inside the array element value (e.g. myArray[5].subProp = 15) instead. Calling this method is not needed if you do
     *      for example myArray[5] = { subProp: 14, otherSubProp: true }, so a change by reference of index 5.
     *
     * In these case (1 and 2), in order for the updated element value to be marked as needing to be sent to server, call this method.
     *
     * Calling this is generally not needed because, if pushToServer is ALLOW or greater (SHALLOW / DEEP) on elements, the array will mark (as needing
     * to be sent to server) automatically any inserts/deletes and changes by reference in the array. It will mark an element as changed as well in case of
     * nested changes that happen in other array or custom object types ONLY if they are declared as such in the component/service Servoy .spec file
     * (so they are not typed as simple 'object'). That is why you do not need to call this method for those situations. Call it only for
     * nested JSON element values typed as 'object' in the .spec file, that have changes in them but are not changed by reference.
     *
     * These marked elements, if they have ALLOW pushToServer, not higher, will not be sent to server right away, but whenever a send/emit of the
     * component's/service's root property (that contains this value - can be even this value directly) is sent to server. This can be triggered directly via
     * an .emit(...) on the @Output() of a component's root property (and in case of services, ServoyPublicService.sendServiceChanges(...)) or automatically
     * by some other SHALLOW or DEEP pushToServer value change somewhere else in the same root property.
     *
     * IMPORTANT: This method is available for custom arrays received from server and for ones created client - side by components, but, for the latter, only after
     * they were sent once to server (you have to get them again from model or parent obj/array as they will be replaced by a new instance - that has this method).
     * DO NOT add this method yourself in newly created custom array instances client-side, as that will not help!
     */
    markElementAsHavingDeepChanges?(index: number): void;
}
/**
 * Value present for properties in model of Servoy components/services if they are declared in the .spec file as custom object types. (sp in the 'types' section).
 *
 * You can declare your custom types as simple interfaces (that can also - optionally - implement ICustomObjectValue - if you need that; see details in jsdoc of
 * markSubPropertyAsHavingDeepChanges(...) method). The system will automatically generate the correct object for that interface (as long as it follows what is
 * defined in the .spec file for this custom object) - and you can use it.
 *
 * For example you can use something like ('extends ICustomObjectValue' is only needed for sending deeply nested changes to server in case of plain 'object'
 * typed subproperties):
 * <pre><code>
 *      @Input() myCustomObjectProperty: IMyCustomObject;
 *
 *      interface IMyCustomObject extends ICustomObjectValue { // extends ICustomObjectValue is optional; the ICustomObjectValue.markSubPropertyAsHavingDeepChanges method will be added automatically
 *          p1: string; // for example
 *          (... all other properties that are defined in the component's spec file for this custom object type ...)
 *      }
 * </code></pre>
 * If you feel like the interface is not enough and your custom types need to have some client-side special class with client side only methods, for example if you
 * have a tab-panel component with some 'tab' type, that is possible. You have to declare your class:
 * <pre><code>
 *     class Tab implements ICustomObjectValue { ...your_fields_and_methods... } // implements ICustomObjectValue is optional; do not declare the markSubPropertyAsHavingDeepChanges - that will be added automatically (when from/to server happens)
 * </code></pre>
 * then call:
 * <pre><code>
 *     specTypesService.registerCustomObjectType("mycomponent.tab", Tab);
 * </code></pre>
 * The custom objects sent from server for 'mycomponent.tab' type will have Tab added to their prototype chain automatically. Both those comming from server
 * and any new Tab instances created on client (after they are sent to the server the first time) will have the markSubPropertyAsHavingDeepChanges method added
 * to them automatically via the prototype chain as well. So you can use then something like this (if you ever need to):
 * <pre><code>
 *     (tab as ICustomObjectValue).markSubPropertyAsHavingDeepChanges(nameOfSomePlainObjectPropertyWithNestedJSONContentInIt);
 * </code></pre>
 */
interface ICustomObjectValue extends Record<string, any> {
    /**
     * If you extend/implement this interface, DO NOT IMPLEMENT THIS METHOD YOURSELF; it will be added under the hood by the custom object type code.
     *
     * Calling this method is (rarely) only needed if both:
     *   1. you want to send client side changes back to the server (calculated pushToServer .spec config for the elements of this array is >= ALLOW)
     *   2. AND you store in the custom object's subproperties simple json values that are nested, and type subproperties simply as 'object' in the .spec
     *      file. So if the subprop. is declared in the .spec file as 'object' and you change that subproperty in it client-side not by reference, but
     *      by content nested inside the subproperty value (e.g. myCustomObject.subProp[3].x = 15) instead. Calling this method is not needed if you do
     *      for example myCustomObject.subProp = [ { x: [14, 0], y: true } ], so a change by reference of subProp.
     *
     * In that case (1 and 2), in order for the updated subproperty value to be marked as needing to be sent to server, call this method.
     *
     * Calling this is generally not needed because, if pushToServer is ALLOW or greater (SHALLOW / DEEP) on a subproperty, the custom object will mark
     * automatically as needing to be sent to server any new/deleted subproperties and changes by reference in the object. It will mark an element as changed
     * as well in case of nested changes that happen in other custom array or custom object types ONLY if they are declared as such in the .spec file (so not
     * simple 'object's), so you do not need to call this method for those situations. Only for nested JSON subproperty values that change, are typed as 'object' in
     * the component/service .spec file, but are not changed by reference.
     *
     * These marked subproperties, if they have ALLOW pushToServer, not higher, will not be sent to server right away, but whenever a send of the
     * component's/service's root property (that contains this value - can be even this value directly) is sent to server. This can be triggered directly via
     * an .emit(...) on the @Output() of a component's root property (and in case of services, ServoyPublicService.sendServiceChanges(...)) or automatically by
     * some other SHALLOW or DEEP pushToServer value change somewhere else in the same root property.
     *
     * IMPORTANT: This method is available for custom objects received from server and for ones created client - side by components, but, for the latter, only after
     * they were sent once to server (you have to get them again from model or parent obj/array as they will be replaced by a new instance - that has this method).
     * DO NOT add this method yourself in newly created custom object instances client-side, as that will not help!
     */
    markSubPropertyAsHavingDeepChanges?(subPropertyName: string): void;
}
interface IValuelist extends Array<{
    displayValue: string;
    realValue: any;
}> {
    filterList(filterString: string): Observable<any>;
    getDisplayValue(realValue: any): Observable<any>;
    hasRealValues(): boolean;
    isRealValueDate(): boolean;
}
interface IFoundsetTree extends Array<any> {
    getChildren(parentID: string, level: number): Promise<any>;
    updateSelection(idarray: Array<string>): void;
    updateCheckboxValue(id: string, value: boolean): void;
    updateExpandedNodes(paths: Array<string>): void;
    getAndResetNewChildren(): {
        key: any;
    };
    getAndResetUpdatedCheckboxValues(): {
        key: boolean;
    };
}
interface IJSMenu {
    items: IJSMenuItem[];
    name: string;
    styleClass: string;
    pushDataProviderValue(category: string, propertyName: string, itemIndex: number, dataproviderValue: any): void;
    setSelectedItem(itemID: string): void;
}
interface IJSMenuItem {
    items: IJSMenuItem[];
    menuText: string;
    styleClass: string;
    itemID: string;
    enabled: boolean;
    iconStyleClass: string;
    tooltipText: string;
    isSelected: boolean;
    extraProperties: {
        Navbar: any;
        Sidenav: any;
    };
}
interface IPopupSupportComponent {
    closePopup(): void;
}
interface IFoundsetFieldsOnly {
    /**
     * An identifier that allows you to use this foundset via the 'foundsetRef' and
     * 'record' types.
     *
     * 'record' and 'foundsetRef' .spec types use it to be able to send RowValue
     * and FoundsetValue instances as record/foundset references on server (so
     * if an argument or property is typed as one of those in .spec file).
     *
     * In reverse, if a 'foundsetRef' type sends a foundset from server to client
     * (for example as a return value of callServerSideApi) it will translate to
     * this identifier on client (so you can use it to find the actual foundset
     * property in the model, if server side script put it in the model as well).
     */
    foundsetId: number;
    /**
     * the size of the foundset on server (so not necessarily the total record count
     * in case of large DB tables)
     */
    serverSize: number;
    /**
     * this is the data you need to have loaded on client (just request what you need via provided
     * loadRecordsAsync or loadExtraRecordsAsync)
     */
    viewPort: ViewPort;
    /**
     * array of selected records in foundset; indexes can be out of current
     * viewPort as well
     */
    selectedRowIndexes: number[];
    /**
     * sort string of the foundset, the same as the one used in scripting for
     * foundset.sort and foundset.getCurrentSort. Example: 'orderid asc'.
     */
    sortColumns: string;
    /**
     * the multiselect mode of the server's foundset; if this is false,
     * selectedRowIndexes can only have one item in it
     */
    multiSelect: boolean;
    /**
     * the findMode state of the server's foundset
     */
    findMode: boolean;
    /**
     * if the foundset is large and on server-side only part of it is loaded (so
     * there are records in the foundset beyond 'serverSize') this is set to true;
     * in this way you know you can load records even after 'serverSize' (requesting
     * viewport to load records at index serverSize-1 or greater will load more
     * records in the foundset)
     */
    hasMoreRows: boolean;
    /**
     * columnFormats is only present if you specify
     * "provideColumnFormats": true inside the .spec file for this foundset property;
     * it gives the default column formatting that Servoy would normally use for
     * each column of the viewport - which you can then also use in the
     * browser yourself; keys are the dataprovider names and values are objects that contain
     * the format contents
     */
    columnFormats?: Record<string, any>;
}
/**
 * Interface for client side values of 'foundset' typed properties in .spec files.
 */
interface IFoundset extends IFoundsetFieldsOnly {
    /**
     * Request a change of viewport bounds from the server; the requested data will be loaded
     * asynchronously in 'viewPort'.
     *
     * @param startIndex the index that you request the first record in "viewPort.rows" to have in
     *                   the real foundset (so the beginning of the viewPort).
     * @param size the number of records to load in viewPort.
     *
     * @return a promise that will get resolved when the requested records arrived browser-
     *                   side. As with any promise you can register success, error callbacks, finally, ...
     *                   See JSDoc of RequestInfoPromise.requestInfo and FoundsetChangeEvent.requestInfos
     *                   for more information about determining if a listener event was caused by this call.
     */
    loadRecordsAsync(startIndex: number, size: number): RequestInfoPromise<any>;
    /**
     * Request more records for your viewPort; if the argument is positive more records will be
     * loaded at the end of the 'viewPort', when negative more records will be loaded at the beginning
     * of the 'viewPort' - asynchronously.
     *
     * @param negativeOrPositiveCount the number of records to extend the viewPort.rows with before or
     *                                after the currently loaded records.
     * @param dontNotifyYet if you set this to true, then the load request will not be sent to server
     *                      right away. So you can queue multiple loadLess/loadExtra before sending them
     *                      to server. If false/undefined it will send this (and any previously queued
     *                      request) to server. See also notifyChanged(). See also notifyChanged().
     *
     * @return a promise that will get resolved when the requested records arrived browser-
     *                   side. As with any promise you can register success, error callbacks, finally, ...
     *                   That allows custom component to make sure that loadExtra/loadLess calls from
     *                   client do not stack on not yet updated viewports to result in wrong bounds.
     *                   See JSDoc of RequestInfoPromise.requestInfo and FoundsetChangeEvent.requestInfos
     *                   for more information about determining if a listener event was caused by this call.
     */
    loadExtraRecordsAsync(negativeOrPositiveCount: number, dontNotifyYet?: boolean): RequestInfoPromise<any>;
    /**
     * Request a shrink of the viewport; if the argument is positive the beginning of the viewport will
     * shrink, when it is negative then the end of the viewport will shrink - asynchronously.
     *
     * @param negativeOrPositiveCount the number of records to shrink the viewPort.rows by before or
     *                                after the currently loaded records.
     * @param dontNotifyYet if you set this to true, then the load request will not be sent to server
     *                      right away. So you can queue multiple loadLess/loadExtra before sending them
     *                      to server. If false/undefined it will send this (and any previously queued
     *                      request) to server. See also notifyChanged(). See also notifyChanged().
     *
     * @return a promise that will get resolved when the requested records arrived browser
     *                   -side. As with any promise you can register success, error callbacks, finally, ...
     *                   That allows custom component to make sure that loadExtra/loadLess calls from
     *                   client do not stack on not yet updated viewports to result in wrong bounds.
     *                   See JSDoc of RequestInfoPromise.requestInfo and FoundsetChangeEvent.requestInfos
     *                   for more information about determining if a listener event was caused by this call.
     */
    loadLessRecordsAsync(negativeOrPositiveCount: number, dontNotifyYet?: boolean): RequestInfoPromise<any>;
    /**
     * If you queue multiple loadExtraRecordsAsync and loadLessRecordsAsync by using dontNotifyYet = true
     * then you can - in the end - send all these requests to server (if any are queued) by calling
     * this method. If no requests are queued, calling this method will have no effect.
     */
    notifyChanged(): void;
    /**
     * Sort the foundset by the dataproviders/columns identified by sortColumns.
     *
     * The name property of each sortColumn can be filled with the dataprovider name the foundset provides
     * or specifies. If the foundset is used with a component type (like in table-view) then the name is
     * the name of the component on who's first dataprovider property the sort should happen. If the
     * foundset is used with another foundset-linked property type (dataprovider/tagstring linked to
     * foundsets) then the name you should give in the sortColumn is that property's 'idForFoundset' value
     * (for example a record 'dataprovider' property linked to the foundset will be an array of values
     * representing the viewport, but it will also have a 'idForFoundset' prop. that can be used for
     * sorting in this call; this 'idForFoundset' was added in version 8.0.3).
     *
     * @param sortColumns an array of JSONObjects { name : dataprovider_id,
     *                    direction : sortDirection }, where the sortDirection can be "asc" or "desc".
     * @return a promise that will get resolved when the new sort
     *                   will arrive browser-side. As with any promise you can register success, error
     *                   and finally callbacks.
     *                   See JSDoc of RequestInfoPromise.requestInfo and FoundsetChangeEvent.requestInfos
     *                   for more information about determining if a listener event was caused by this call.
     */
    sort(sortColumns: Array<{
        name: string;
        direction: ('asc' | 'desc');
    }>): RequestInfoPromise<any>;
    /**
     * Request a selection change of the selected row indexes. Returns a promise that is resolved
     * when the client receives the updated selection from the server. If successful, the array
     * selectedRowIndexes will also be updated. If the server does not allow the selection change,
     * the reject function will get called with the 'old' selection as parameter.
     *
     * If requestSelectionUpdate is called a second time, before the first call is resolved, the
     * first call will be rejected and the caller will receive the string 'canceled' as the value
     * for the parameter serverRows.
     * E.g.: foundset.requestSelectionUpdate([2,3,4]).then(function(serverRows){},function(serverRows){});
     *
     * @return a promise that will get resolved when the requested selection update arrived back browser-
     *                   side. As with any promise you can register success, error callbacks, finally, ...
     *                   See JSDoc of RequestInfoPromise.requestInfo and FoundsetChangeEvent.requestInfos
     *                   for more information about determining if a listener event was caused by this call.
     */
    requestSelectionUpdate(selectedRowIdxs: number[]): RequestInfoPromise<any>;
    /**
     * It will send a data update for a cell (a column in a row) in the foundset to the server.
     * Please make sure to adjust the viewport value as well not just call this method.
     *
     * This method is useful if you do not want to use push-to-server SHALLOW in .spec file but do it manually instead, or if
     * you have nested JSON object/arrays as cell values and you need to tell the foundset that something nested has changed (DEEP watches are not available in NG2) or
     * if you just need a promise to know when the change was done or failed on server.
     *
     * The calculated pushToServer for the foundset property should be set to 'allow' if you use this method. Then the server will accept
     * data changes from this property, but there will be no automatic proxies to detect the changes-by-reference to cell values, so the component uses this call
     * to send cell changes instead.
     *
     * @param rowID the _svyRowId column of the client side row
     * @param columnName the name of the column to be updated on server (in that row).
     * @param newValue the new data in that cell
     * @param oldValue the old data that used to be in that cell
     * @return (first versions of this method didn't return anything; more recent ones return this) a promise that will get resolved when the new cell value
     *                   update is done server-side (resolved if ok, rejected if it failed). As with any promise you can register success, error
     *                   and finally callbacks.
     */
    columnDataChangedByRowId(rowID: string, columnName: string, newValue: any, oldValue: any): Promise<any>;
    /**
     * Convenience method that does exactly what #columnDataChangedByRowId does, but based on a row index from the viewport not on that row's ID.
     */
    columnDataChanged(rowIndex: number, columnName: string, newValue: any, oldValue: any): Promise<any>;
    /**
     * Please use columnDataChangedByRowId(...) instead.
     *
     * @deprecated please use columnDataChangedByRowId(...) instead.
     */
    updateViewportRecord(rowID: string, columnID: string, newValue: any, oldValue: any): void;
    /**
     * Receives a client side rowID (taken from myFoundsetProp.viewPort.rows[idx]._svyRowId)
     * and gives a Record reference, an object
     * which can be resolved server side to the exact Record via the 'record' property type;
     * for example if you call a handler or a servoyApi().callServerSideApi(...) and want
     * to give it a Record as parameter and you have the rowID and foundset in your code,
     * you can use this method. E.g: servoyApi().callServerSideApi("doSomethingWithRecord",
     *                     [this.myFoundsetProperty.getRecordRefByRowID(clickedRowId)]);
     *
     * NOTE: if in your component you know the whole row (so myFoundsetProp.viewPort.rows[idx])
     * already - not just the rowID - that you want to send you can just give that directly to the
     * handler/serverSideApi; you do not need to use this method in that case. E.g:
     * // if you have the index inside the viewport
     * servoyApi().callServerSideApi("doSomethingWithRecord",
     *           [this.myFoundsetProperty.viewPort.rows[clickedRowIdx]]);
     * // or if you have the row directly
     * servoyApi().callServerSideApi("doSomethingWithRecord", [clickedRow]);
     *
     * This method has been added in Servoy 8.3.
     */
    getRecordRefByRowID(rowId: string): object | null;
    /**
     * Sets the preferred viewPort options hint on the server for this foundset, so that the next
     * (initial or new) load will automatically return that many rows, even without any of the loadXYZ
     * methods above being called.
     *
     * You can use this when the component size is not known initially and the number of records the
     * component wants to load depends on that. As soon as the component knows how many it wants
     * initially it can call this method.
     *
     * These can also be specified initially using the .spec options "initialPreferredViewPortSize" and
     * "sendSelectionViewportInitially". But these can be altered at runtime via this method as well
     * because they are used/useful in other scenarios as well, not just initially: for example when a
     * related foundset changes parent record, when a search/find is performed and so on.
     *
     * See also the description of "foundsetInitialPageSize" property type for a way to set this
     * at design-time (via properties view) or before the form is shown for components that 'page' data.
     *
     * @param preferredSize the preferred number or rows that the viewport should get automatically
     *                      from the server.
     * @param sendViewportWithSelection if this is true, the auto-sent viewport will contain
     *                                            the selected row (if any).
     * @param centerViewportOnSelected if this is true, the selected row will be in the middle
     *                                           of auto-sent viewport if possible. If it is false, then
     *                                           the foundset property type will assume a 'paging'
     *                                           strategy and will send the page that contains the
     *                                           selected row (here the page size is assumed to be
     *                                           preferredSize).
     */
    setPreferredViewportSize(preferredSize: number, sendViewportWithSelection?: boolean, centerViewportOnSelected?: boolean): void;
    /**
     * Adds a change listener that will get triggered when server sends changes for this foundset.
     *
     * @param changeListener the listener to register.
     * @return a function to unregister the listener
     */
    addChangeListener(changeListener: FoundsetChangeListener): () => void;
    removeChangeListener(changeListener: FoundsetChangeListener): void;
}
interface ViewPort {
    startIndex: number;
    size: number;
    rows: ViewPortRow[];
}
interface ViewPortRow extends Record<string, any> {
    _svyRowId: string;
    /** components that use the foundset property are free to use this property however they like; it is not set/used by the foundset impl. */
    _cache?: Map<string, any>;
}
/**
 * Besides working like a normal Promise that you can use to get notified when some action is done (success/error/finally), chain etc., this promise also
 * contains field "requestInfo" which can be set by the user and could later be reported in some listener events back to the user (in case this same action
 * is going to trigger those listeners as well).
 *
 * @since 2021.09
 */
interface RequestInfoPromise<T> extends Promise<T> {
    /**
     * You can assign any value to it. The value that you assign - if any - will be given back in the
     * event object of any listener that will be triggered as a result of the promise's action. So in
     * case the same action, when done, will trigger both the "then" of the Promise and a separate
     * listener, that separate listener will contain this "requestInfo" value.
     *
     * This is useful for some components that want to know if some change (reported by the listener)
     * happened due to an action that the component requested or due to changes in the outside world.
     * (eg: FoundsetPropertyValue.loadRecordsAsync(...) returns RequestInfoPromise and
     * FoundsetChangeEvent.requestInfos array can return that RequestInfoPromise.requestInfo on the
     * event that was triggered by that loadRecordsAsync).
     */
    requestInfo?: any;
}
interface FoundsetChangeEvent extends ViewportChangeEvent {
    /**
     * If this change event is caused by one or more calls (by the component) on the IFoundset obj
     * (like loadRecordsAsync requestSelectionUpdate and so on), and the caller then assigned a value to
     * the returned RequestInfoPromise's "requestInfo" field, then that value will be present in this array.
     *
     * This is useful for some components that want to know if some change (reported in this FoundsetChangeEvent)
     * happened due to an action that the component requested or due to changes in the outside world. (eg:
     * IFoundset.loadRecordsAsync(...) returns RequestInfoPromise and FoundsetChangeEvent.requestInfos array can
     * contain that RequestInfoPromise.requestInfo on the event that was triggered by that loadRecordsAsync).
     *
     * @since 2021.09
     */
    requestInfos?: any[];
    /**
     * If a full value update was received from server, this key is set; if both the newValue and
     * the oldValue are non-null, the oldValue's reference will be reused (so the reference of the
     * foundset property doesn't change, just it's contents are updated) and oldValue given below is
     * actually a shallow-copy of the old value's properties/keys; this can help in some component
     * implementations.
     */
    fullValueChanged?: {
        oldValue: IFoundsetFieldsOnly;
        newValue: IFoundset;
    };
    serverFoundsetSizeChanged?: {
        oldValue: number;
        newValue: number;
    };
    foundsetDefinitionChanged?: boolean;
    hasMoreRowsChanged?: {
        oldValue: boolean;
        newValue: boolean;
    };
    multiSelectChanged?: {
        oldValue: boolean;
        newValue: boolean;
    };
    columnFormatsChanged?: {
        oldValue: Record<string, Record<string, unknown>>;
        newValue: Record<string, Record<string, unknown>>;
    };
    sortColumnsChanged?: {
        oldValue: string;
        newValue: string;
    };
    selectedRowIndexesChanged?: {
        oldValue: number[];
        newValue: number[];
    };
    viewPortStartIndexChanged?: {
        oldValue: number;
        newValue: number;
    };
    viewPortSizeChanged?: {
        oldValue: number;
        newValue: number;
    };
    viewportRowsCompletelyChanged?: {
        oldValue: ViewPortRow[];
        newValue: ViewPortRow[];
    };
    userSetSelection?: boolean;
}
interface ViewportChangeEvent {
    viewportRowsCompletelyChanged?: {
        oldValue: any[];
        newValue: any[];
    };
    viewportRowsUpdated?: ViewportRowUpdates;
}
type ViewportChangeListener = (changeEvent: ViewportChangeEvent) => void;
type FoundsetChangeListener = (changeEvent: FoundsetChangeEvent) => void;
interface ViewportRowUpdate {
    type: ChangeType;
    startIndex: number;
    endIndex: number;
}
type ViewportRowUpdates = ViewportRowUpdate[];
declare enum ChangeType {
    ROWS_CHANGED = 0,
    /**
     * When an INSERT happened but viewport size remained the same, it is
     * possible that some of the rows that were previously at the end of the viewport
     * slided out of it;
     * NOTE: insert signifies an insert into the client viewport, not necessarily
     * an insert in the foundset itself; for example calling "loadExtraRecordsAsync"
     * can result in an insert notification + bigger viewport size notification
     */
    ROWS_INSERTED = 1,
    /**
     * When a DELETE happened inside the viewport but there were more rows available in the
     * foundset after current viewport, it is possible that some of those rows
     * slided into the viewport;
     * NOTE: delete signifies a delete from the client viewport, not necessarily
     * a delete in the foundset itself; for example calling "loadLessRecordsAsync" can
     * result in a delete notification + smaller viewport size notification
     */
    ROWS_DELETED = 2
}
/**
 * Interface for client side values of 'component' typed properties in .spec files. (so used as child components within the .spec of a component)
 */
interface IChildComponentPropertyValue extends IComponentCache {
    name: string;
    /** this is the shared part of the model; you might want to use modelViewport (which uses this as prototype) instead if the child component has foundset-linked properties */
    model: {
        [property: string]: any;
    };
    handlers: any;
    foundsetConfig?: {
        recordBasedProperties?: Array<string>;
        apiCallTypes?: Array<any>;
    };
    /** this is the true cell viewport which is already composed inside IChildComponentPropertyValue of shared (non foundset dependent) part and row specific (foundset dependent props) part */
    modelViewport: any[];
    /**
     * This function has to be set/provided by the ng2 component that uses this child "component" typed property, because
     * that one controls the UI of the child component represented by this property (or child components in case of
     * foundset linked components like in list form component for example). Then when there are changes comming from server, the 'component'
     * property type will call this function as needed.
     */
    triggerNgOnChangeWithSameRefDueToSmartPropertyUpdate: (propertiesChangedButNotByRef: {
        propertyName: string;
        newPropertyValue: any;
    }[], rowIndex: number) => void;
    /**
     * This gives a way to trigger handlers.
     *
     * In case this component is not foundset-linked, use mappedHandlers directly (which is a function).
     * In case this component is foundset-linked, use mappedHandlers.selectRecordHandler(rowId) to trigger the handler for the component of the correct row in the foundset.
     */
    mappedHandlers: Map<string, {
        (): Promise<any>;
        selectRecordHandler(rowId: any): () => Promise<any>;
    }>;
    /**
     * Parent components that use this child 'component' typed value will need to give a svyServoyApi to the actual child components (whether it's a viewport of them
     * for this child component value (foundset linked components similar to list form component child usage) or only one). They can use this startEdit to provide
     * that to child components based on specific rows in the foundset (via rowId param).
     */
    startEdit(propertyName: string, rowId: any): void;
    /**
     * Parent components that use this child 'component' typed value will need to give a svyServoyApi to the actual child components (whether it's a viewport of them
     * for this child component value (foundset linked components similar to list form component child usage) or only one). They can use this sendChanges to provide
     * 'apply' of dataproviders to child components based on specific rows in the foundset (via rowId param) or even in order to provide non-dataprovider send change
     * API or emit() implementation based on specific rows in the foundset (via rowId param).
     */
    sendChanges(propertyName: string, modelOfComponent: Record<string, any>, oldValue: any, rowId: any, isDataprovider?: boolean): void;
    /**
     * Adds a change listener that will get triggered when server sends granular or full modelViewport changes for this component.
     *
     * @param viewportChangeListener the listener to register.
     */
    addViewportChangeListener(viewportChangeListener: ViewportChangeListener): () => void;
    removeViewportChangeListener(viewportChangeListener: ViewportChangeListener): void;
}

declare class TabFixDirective {
    readonly typeahead: i0.InputSignal<IPopupSupportComponent>;
    startedTyping: boolean;
    constructor();
    onFocus(target: any): void;
    handleKeyDown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabFixDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabFixDirective, "[svyTabFix]", never, { "typeahead": { "alias": "svyTabFix"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TooltipService {
    isTooltipActive: Subject<boolean>;
    readonly isTooltipActiveSignal: Signal<boolean>;
    tipInitialTimeout: any;
    tipTimeout: any;
    private tooltipDiv;
    private tipmousemouveEventX;
    private tipmousemouveEventY;
    private tipmousemouveEventIsPage;
    private doc;
    private windowRefService;
    private _isTooltipActiveSignal;
    constructor();
    /**
     * Showsthe tooltip on the screen on the position of the mouse event, showing the message with a initial delay and dismissing it after dismissDelay.
     */
    showTooltip(event: MouseEvent, message: string, initialDelay: number, dismissDelay: number): void;
    /**
     *  hides the tooltip directly that is currently showing.
     */
    hideTooltip(): void;
    private getTooltipDiv;
    private tipmousemove;
    private adjustAndShowTooltip;
    private internalHideTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TooltipService>;
}

/**
 * It's meant to not depend on ServoyPublicService, but rather to be directly configurable via an htmlTooltipInitialDelay and htmlTooltipDismissDelay attrs/inputs.
 * It is useful for usage in the palette part of the form designer - which is not a Servoy client.
 */
declare class HTMLTooltipDirective {
    readonly tooltipText: i0.InputSignal<string | undefined>;
    readonly tooltipInitialDelay: i0.InputSignal<number | undefined>;
    readonly tooltipDismissDelay: i0.InputSignal<number | undefined>;
    isActive: boolean;
    protected tooltipService: TooltipService;
    constructor();
    onMouseEnter(event: PointerEvent): void;
    protected getInitialDelay(): number;
    protected getDismissDelay(): number;
    onMouseLeave(): void;
    onClick(): void;
    onContextMenu(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HTMLTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HTMLTooltipDirective, "[htmlTooltip]", never, { "tooltipText": { "alias": "htmlTooltip"; "required": false; "isSignal": true; }; "tooltipInitialDelay": { "alias": "tooltipInitialDelay"; "required": false; "isSignal": true; }; "tooltipDismissDelay": { "alias": "tooltipDismissDelay"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class TooltipDirective extends HTMLTooltipDirective {
    readonly tooltipText: i0.InputSignal<string | undefined>;
    private servoyService;
    protected getInitialDelay(): number;
    protected getDismissDelay(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TooltipDirective, "[svyTooltip]", never, { "tooltipText": { "alias": "svyTooltip"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class MnemonicletterFilterPipe implements PipeTransform {
    transform(input: string, letter: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MnemonicletterFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MnemonicletterFilterPipe, "mnemonicletterFilter", true>;
}
declare class NotNullOrEmptyPipe implements PipeTransform {
    transform(value: any[], _args?: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotNullOrEmptyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<NotNullOrEmptyPipe, "notNullOrEmpty", true>;
}
declare class HtmlFilterPipe implements PipeTransform {
    transform(input: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<HtmlFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<HtmlFilterPipe, "htmlFilter", true>;
}
declare class TrustAsHtmlPipe implements PipeTransform {
    private domSanitizer;
    constructor(domSanitizer?: DomSanitizer);
    transform(input: string, trustAsHtml: boolean): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrustAsHtmlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TrustAsHtmlPipe, "trustAsHtml", true>;
}

/**
  * Class reflecting a Format object coming from the server (format spec property)
  */
declare class Format {
    display: string;
    uppercase: boolean;
    lowercase: boolean;
    type: string;
    isMask: boolean;
    isRaw: boolean;
    isNumberValidator: boolean;
    edit: string;
    placeHolder: string;
    percent: string;
    allowedCharacters: string;
    maxLength: number;
}
/**
 * This service is able to format/parse/unformat data of different types (dates,numbers) according to the format string of the format spec property.
 *
 * Components can use the {@link FormatDirective} that uses this service in the component template: [svyFormat]="format"
 */
declare class FormattingService {
    private servoyService;
    constructor(servoyService?: ServoyPublicService);
    /**
     * format the data give with the {@link Format} object give, optionally using the display or edit format.
     */
    format(data: any, format: Format, useEditFormat: boolean): string;
    /**
     * utility function to test if a certain key is pressed
     */
    testKeyPressed(event: KeyboardEvent, keyCode: number): boolean;
    /**
     * utility function to test if only numbers ar pressed.
     */
    testForNumbersOnly(e: any, keyChar: any, vElement: any, vFindMode: any, vCheckNumbers: any, vSvyFormat: any, skipMaxLength: any): boolean;
    /**
     * calls the { @link #unformat} function for unformatting/parsing the data given
     */
    parse(data: any, format: Format, useEditFormat: boolean, currentValue?: any, useHeuristics?: boolean): any;
    /**
     * unformats/parse the give data according to the given format and type
     */
    unformat(data: any, servoyFormat: string, type: string, currentValue?: any, useHeuristics?: boolean): any;
    private findClosestDate;
    private addToFormats;
    private containsAllLetters;
    private getHeuristicFormats;
    private compareInputWithFormat;
    private unformatNumbers;
    private numbersonly;
    private numbersonlyForChar;
    private getSelectedText;
    private formatNumbers;
    private formatText;
    private formatDate;
    private convertFormat;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormattingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormattingService>;
}

/**
  * This is the format directive [svyFormat]="format" that can format the dataprovider value in a input field and parse the value back when the user changes the value.
  * this is an Angular  ControlValueAccessor  that sits between the angular component ( {@link ServoyBaseComponent } and the dom element, it writes the formatted value to the dom
  * and parses and pushes the parsed value back into the component.
  *
  * it uses the {@link FormattingService} for this.
  */
declare class FormatDirective implements ControlValueAccessor, AfterViewInit, OnChanges {
    private static DATETIMEFORMAT;
    private static DATEFORMAT;
    private static MONTHFORMAT;
    private static WEEKFORMAT;
    private static TIMEFORMAT;
    private static BROWSERNUMBERFORMAT;
    readonly format: i0.InputSignal<Format>;
    readonly findmode: i0.InputSignal<boolean>;
    private hasFocus;
    private realValue;
    private isKeyPressEventFired;
    private oldInputValue;
    private listeners;
    private maskFormat;
    private readonly log;
    private focusText;
    private _renderer;
    private _elementRef;
    private formatService;
    private doc;
    constructor(renderer?: Renderer2, elementRef?: ElementRef, formatService?: FormattingService, doc?: any, logFactory?: LoggerFactory);
    touched(target: EventTarget | null): void;
    focussed(): void;
    keyDown(event: KeyboardEvent): void;
    input(target: EventTarget | null): void;
    dateInputChange(value: any): void;
    setRealValue(value: any): void;
    onChangeCallback: (_: any) => void;
    onTouchedCallback: () => void;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    writeValue(value: any): void;
    private getType;
    private setFormat;
    private upperOrLowerCase;
    private inputFiredForNumbersCheck;
    private findDelta;
    private getNumbersFromString;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormatDirective, "[svyFormat]", never, { "format": { "alias": "svyFormat"; "required": false; "isSignal": true; }; "findmode": { "alias": "findmode"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class DecimalkeyconverterDirective {
    readonly svyFormat: i0.InputSignal<Format>;
    private element;
    private servoyService;
    constructor(el?: ElementRef, servoyService?: ServoyPublicService);
    onKeypress(e: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DecimalkeyconverterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DecimalkeyconverterDirective, "[svyDecimalKeyConverter]", never, { "svyFormat": { "alias": "svyDecimalKeyConverter"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FormatFilterPipe implements PipeTransform {
    private readonly log;
    private formatService;
    constructor(formatService?: FormattingService, logFactory?: LoggerFactory);
    transform(input: any, format: Format): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormatFilterPipe, "formatFilter", true>;
}

declare class EmptyValueFilterPipe implements PipeTransform {
    transform(input: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmptyValueFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<EmptyValueFilterPipe, "emptyValue", true>;
}

declare class StartEditDirective {
    readonly dataProviderID: i0.InputSignal<string>;
    readonly hostComponent: i0.InputSignal<ServoyBaseComponent<HTMLElement>>;
    private log;
    constructor(logFactory?: LoggerFactory);
    onFocus(e: FocusEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StartEditDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StartEditDirective, "[svyStartEdit]", never, { "dataProviderID": { "alias": "svyStartEdit"; "required": false; "isSignal": true; }; "hostComponent": { "alias": "hostComponent"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class ImageMediaIdDirective implements OnChanges, IViewStateListener, OnDestroy {
    readonly media: i0.InputSignal<any>;
    readonly hostComponent: i0.InputSignal<ServoyBaseComponent<HTMLElement>>;
    private imgStyle;
    private rollOverImgStyle;
    private clearStyle;
    private _elemRef;
    private _renderer;
    private windowRefService;
    private resizeObserver;
    constructor(elemRef?: ElementRef<HTMLElement>, renderer?: Renderer2, windowRefService?: WindowRefService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    afterViewInit(): void;
    private setImageStyle;
    private parseImageOptions;
    private setCSSStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageMediaIdDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ImageMediaIdDirective, "[svyImageMediaId]", never, { "media": { "alias": "svyImageMediaId"; "required": false; "isSignal": true; }; "hostComponent": { "alias": "hostComponent"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class AutosaveDirective {
    private servoyService;
    private elementRef;
    constructor(servoyService?: ServoyPublicService, elementRef?: ElementRef);
    onClick(target: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutosaveDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AutosaveDirective, "[svyAutosave]", never, {}, {}, never, never, true, never>;
}

declare class UploadDirective implements OnInit {
    readonly formname: i0.InputSignal<string>;
    readonly componentName: i0.InputSignal<string>;
    private url;
    private propertyName;
    private servoyService;
    constructor(servoyService?: ServoyPublicService);
    click(e: Event): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<UploadDirective, "[svyUpload]", never, { "formname": { "alias": "formname"; "required": false; "isSignal": true; }; "componentName": { "alias": "componentName"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SabloTabseq implements OnInit, OnChanges, OnDestroy {
    readonly designTabSeqInput: i0.InputSignal<number | undefined>;
    readonly configInput: i0.InputSignal<SabloTabseqConfig>;
    designTabSeq: number | undefined;
    designChildIndexToArrayPosition: {
        [designChildTabSeq: number]: number;
    };
    designChildTabSeq: Array<number>;
    runtimeChildIndexes: {
        [designChildIndex: number]: RuntimeIndex | Array<RuntimeIndex>;
    };
    runtimeIndex: RuntimeIndex;
    initializing: boolean;
    isEnabled: boolean;
    private parentSTS;
    private _elemRef;
    constructor(elemRef?: ElementRef<Element>);
    private get config();
    private setParentSTS;
    registerChildHandler(event: Event): boolean;
    private unregisterChildSTS;
    recalculateIndexesHandler(event: Event): boolean;
    recalculateIndexes(designChildIndex: number, initialRootRecalculate: boolean, event?: Event): boolean;
    disableTabseq(event: Event): boolean;
    enableTabseq(event: Event): boolean;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    recalculateChildRuntimeIndexesStartingAt(posInDesignArray: number, triggeredByParent: boolean): void;
    hasOwnTabIndex(): boolean;
    updateCurrentDomElTabIndex(): void;
    setDOMTabIndex(tabindex: number | undefined): void;
    triggerRecalculatePSTSInParent(designChildIndex: number): void;
    triggerRegisterCSTSInParent(designChildIndex: number, runtimeChildIndex: RuntimeIndex): void;
    triggerUnregisterCSTSInParent(designChildIndex: number, runtimeChildIndex: RuntimeIndex): void;
    triggerInParent(eventName: string, arg: unknown): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SabloTabseq, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SabloTabseq, "[sabloTabseq]", never, { "designTabSeqInput": { "alias": "sabloTabseq"; "required": false; "isSignal": true; }; "configInput": { "alias": "sabloTabseqConfig"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
interface SabloTabseqConfig {
    /** If this is the top-most tabSeq container. */
    root?: boolean;
    /** If this is a tabSeq container.
     *  Child DOM elements of this element are considered to be traversed by tab sequence at the 'design' tab index value of this container.
     *  So at runtime all child DOM elements of this element will get a tabIndex value that sets them between the parent element's siblings,
     *  according to the 'design' tab index value of the parent and it's siblings.
     */
    container?: boolean;
    /** Tells sablo-tabseq that it should 'reserve' a number of tabIndexes for that container on top of the ones it currently needs.
     *  That can help later on, if more elements are added to that container and it needs more tabIndexes assigned - it can just use them
     *  without recalculating the tabIndexes of the parents (so less calculations to be done in the browser) - at least for a while,
     *  until it runs out of reserved indexes.
     */
    reservedGap?: number;
    /**
     * By default 'tabindex' is added to the element of the 'sabloTabseq' directive. Using this helper function, that is called when
     * the 'tabindex' is about to be set, it is possible to add the 'tabindex' on a different (nested) element.
     */
    tabSeqSetter?: {
        setTabIndex: (index: number) => void;
    };
}
interface RuntimeIndex {
    startIndex: number;
    nextAvailableIndex: number;
    sablotabseq: SabloTabseq;
}

declare class ServoyPublicModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServoyPublicModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServoyPublicModule, never, [typeof TabFixDirective, typeof TooltipDirective, typeof HTMLTooltipDirective, typeof MnemonicletterFilterPipe, typeof NotNullOrEmptyPipe, typeof HtmlFilterPipe, typeof FormatDirective, typeof DecimalkeyconverterDirective, typeof FormatFilterPipe, typeof EmptyValueFilterPipe, typeof StartEditDirective, typeof ImageMediaIdDirective, typeof AutosaveDirective, typeof UploadDirective, typeof SabloTabseq, typeof TrustAsHtmlPipe], [typeof TabFixDirective, typeof TooltipDirective, typeof HTMLTooltipDirective, typeof MnemonicletterFilterPipe, typeof NotNullOrEmptyPipe, typeof HtmlFilterPipe, typeof FormatDirective, typeof DecimalkeyconverterDirective, typeof FormatFilterPipe, typeof EmptyValueFilterPipe, typeof StartEditDirective, typeof ImageMediaIdDirective, typeof AutosaveDirective, typeof UploadDirective, typeof SabloTabseq, typeof TrustAsHtmlPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServoyPublicModule>;
}

declare class MaskFormat {
    private format;
    private _renderer;
    private element;
    private formatService;
    private doc;
    private ignore;
    private firstNonMaskPos;
    private settings;
    private buffer;
    private tests;
    private converters;
    private mask;
    private focusText;
    private filteredMask;
    private listeners;
    constructor(format: Format, _renderer: Renderer2, element: HTMLInputElement, formatService: FormattingService, doc: Document);
    private onFocus;
    private setCaretOnFocus;
    private onBlur;
    private onKeypress;
    private onKeydown;
    private setCaret;
    private seekPrevious;
    private seekNext;
    private clear;
    private clearBuffer;
    private writeBuffer;
    private checkVal;
    private getPlaceHolder;
    destroy(): void;
}

interface WebStorage {
    prefix: string;
    /**
     * Test the client's support for storing values in the web store.
     *
     * @return {boolean} True if the client has support for the web store, else false.
     */
    isSupported(): boolean;
    /**
     * Add or update the specified key/value pair in the web store.
     *
     * @param {string} key The name to store the value under.
     * @param {mixed} value The value to set (all values are stored as JSON.)
     * @return {boolean} True on success, else false.
     */
    set(key: string, value: any): boolean;
    /**
     * Getter for the key/value web store.
     *
     * @param {string} key Name of the value to retrieve.
     * @return {mixed} The value previously added under the specified key, else null.
     */
    get(key: string): any;
    /**
     * Check if a key exists.
     *
     * @param {string} key Name of the key to test.
     * @return {boolean} True if the key exists, else false.
     */
    has(key: string): boolean;
    /**
     * Remove a specified value from the key/value web store.
     *
     * @param {string} key Name of the value to remove.
     * @return {boolean} True on success, else false.
     */
    remove(key: string): boolean;
    clear(): boolean;
    /**
     * Returns an integer representing the number of items stored
     * in the key/value web store.
     *
     * @return {number} The number of items currently stored in
     *   the key/value web store.
     */
    length(): number;
    /**
     * Return the name of the nth key in the key/value web store.
     *
     * @param {number} index An integer representing the number of the key to
     *   the return the name of.
     * @return {string|null} The name of the key if available or null otherwise.
     */
    key(index: number): string;
}

declare class LocalStorageService implements WebStorage {
    hasLocalStorage: boolean;
    prefix: string;
    private log;
    constructor(logFactory?: LoggerFactory);
    isSupported(): boolean;
    set(key: string, value: any): boolean;
    get(key: string): any;
    has(key: string): boolean;
    remove(key: string): boolean;
    clear(): boolean;
    key(index: number): string;
    changePrefix(newPrefix: string): void;
    length(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalStorageService>;
}

declare class SessionStorageService implements WebStorage {
    hasSessionStorage: boolean;
    prefix: string;
    private log;
    constructor(logFactory?: LoggerFactory);
    isSupported(): boolean;
    set(key: string, value: any): boolean;
    get(key: string): any;
    has(key: string): boolean;
    remove(key: string): boolean;
    clear(): boolean;
    key(index: number): string;
    length(): number;
    changePrefix(newPrefix: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SessionStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SessionStorageService>;
}

declare class MainViewRefService {
    private _mainRef;
    get mainContainer(): ViewContainerRef;
    set mainContainer(ref: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<MainViewRefService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MainViewRefService>;
}

declare class PropertyUtils {
    static setHorizontalAlignment(element: any, renderer: Renderer2, halign: any): void;
    static setRotation(element: HTMLElement, renderer: Renderer2, rotation: number, size?: {
        width: number;
        height: number;
    }): void;
    static setBorder(element: any, renderer: Renderer2, newVal: any): void;
    static setFont(element: any, renderer: Renderer2, newVal: any): void;
    static setVisible(element: any, renderer: Renderer2, newVal: any): void;
    static addSelectOnEnter(element: any, renderer: Renderer2, doc: Document): void;
    static getScrollbarsStyleObj(scrollbars: number): Record<string, any>;
    static setScrollbars(element: any, renderer: Renderer2, value: any): void;
    static getPropByStringPath(o: any, s: any): any;
}

/**
 * Returns a zero-based index for first day of the week, as used by the specified locale
 * e.g. Sunday (returns 0), or Monday (returns 1)
 *
 * @param locale
 * @returns
 */
declare const getFirstDayOfWeek: (locale: string) => number;
/**
 * Floors the specified date to the beginning of week.
 *
 * @param date
 * @returns
 */
declare const floorToWeek: (date: DateTime) => DateTime;
declare const setFirstDayOfWeek: (value: number) => void;

declare class ServoyPublicServiceTestingImpl extends ServoyPublicService {
    private locale;
    private messages;
    private forms;
    private localeNumberSymbol;
    addForm(name: string, formCache: IFormCache): void;
    getFormCacheByName(containedForm: string): IFormCache;
    generateServiceUploadUrl(serviceName: string, apiFunctionName: string): string;
    generateUploadUrl(formname: string, componentName: string, propertyName: string): string;
    generateMediaDownloadUrl(media: string): string;
    getUIProperty(key: string): any;
    executeInlineScript<T>(formname: string, script: string, params: any[]): Promise<T>;
    callServiceServerSideApi<T>(servicename: string, methodName: string, args: Array<any>): Promise<T>;
    addMessage(key: string, message: string): void;
    getI18NMessages(...keys: string[]): Promise<any>;
    listenForI18NMessages(...keys: string[]): I18NListener;
    callService<T>(serviceName: string, methodName: string, argsObject: any, async?: boolean): Promise<T>;
    setLocale(locale: Locale): void;
    getLocale(): string;
    getLocaleObject(): Locale;
    getAGGridLocale(): {
        [key: string]: string;
    };
    createJSEvent(event: EventLike, eventType: string, contextFilter?: string, contextFilterElement?: any): JSEvent;
    showFileOpenDialog(title: string, multiselect: boolean, acceptFilter: string, url: string): void;
    showMessageDialog(dialogTitle: string, dialogMessage: string, styleClass: string, values: string[], buttonsText: string[], inputType: string): Promise<string>;
    getLocaleNumberSymbol(symbol: NumberSymbol): string;
    setLocaleNumberSymbol(symbol: string): void;
    /** @deprecated */
    sendServiceChanges(_serviceName: string, _propertyName: string, _propertyValue: any): void;
    sendServiceChangeToServer(_serviceName: string, _propertyName: string, _propertyValue: any, _oldPropertyValue: any): void;
    showForm(_popup: PopupForm): void;
    cancelFormPopup(_disableClearPopupFormCallToServer_or_name: boolean | string): void;
    setFormStyleClasses(_styleclasses: {
        property: string;
    }): void;
    isInTestingMode(): boolean;
    getTemplateForFormComponentChild(_formName: string, _item: IComponentCache): TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServoyPublicServiceTestingImpl, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServoyPublicServiceTestingImpl>;
}
declare class ServoyPublicTestingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServoyPublicTestingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServoyPublicTestingModule, never, [typeof ServoyPublicModule], [typeof ServoyPublicModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServoyPublicTestingModule>;
}

declare class ServoyApiTesting implements ServoyApi {
    formWillShow(formname: string, relationname?: string, formIndex?: number): Promise<boolean>;
    hideForm(formname: string, relationname?: string, formIndex?: number, formNameThatWillShow?: string, relationnameThatWillBeShown?: string, formIndexThatWillBeShown?: number): Promise<boolean>;
    startEdit(propertyName: string): void;
    apply(propertyName: string, value: unknown): void;
    callServerSideApi(methodName: string, args: Array<unknown>): Promise<null>;
    isInDesigner(): boolean;
    trustAsHtml(): boolean;
    isInAbsoluteLayout(): boolean;
    getMarkupId(): string;
    getFormName(): string;
    registerComponent(component: ServoyBaseComponent<HTMLElement>): void;
    unRegisterComponent(component: ServoyBaseComponent<HTMLElement>): void;
    getClientProperty(key: string): string;
}

declare function runOnPushChangeDetection<T>(cf: ComponentFixture<T>): Promise<any>;

declare class PopupStateService {
    private activePopups;
    private activePopupCount;
    readonly isPopupActive: Signal<boolean>;
    isAnyPopupActive(): boolean;
    activatePopup(id: string): void;
    deactivatePopup(id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopupStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PopupStateService>;
}

export { ArrayState, AutosaveDirective, BaseCustomObject, BaseCustomObjectState, Callback, ChangeType, ComponentContributor, DecimalkeyconverterDirective, Deferred, EmptyValueFilterPipe, Format, FormatDirective, FormatFilterPipe, FormattingService, HTMLTooltipDirective, HtmlFilterPipe, ImageMediaIdDirective, JSEvent, LocalStorageService, LogConfiguration, LogLevel, LoggerFactory, LoggerService, MainViewRefService, MaskFormat, MnemonicletterFilterPipe, NotNullOrEmptyPipe, PopupForm, PopupStateService, PropertyUtils, SabloTabseq, ServoyApi, ServoyApiTesting, ServoyBaseComponent, ServoyPublicModule, ServoyPublicService, ServoyPublicServiceTestingImpl, ServoyPublicTestingModule, SessionStorageService, SpecTypesService, StartEditDirective, TabFixDirective, TooltipDirective, TooltipService, TrustAsHtmlPipe, UploadDirective, WindowRefService, floorToWeek, getDeprecatedCustomArrayState, getFirstDayOfWeek, runOnPushChangeDetection, setFirstDayOfWeek };
export type { CustomObjectTypeConstructor, EventLike, FoundsetChangeEvent, FoundsetChangeListener, I18NListener, IChildComponentPropertyValue, IComponentCache, IComponentContributorListener, ICustomArray, ICustomArrayValue, ICustomObjectValue, IDeferred, IFormCache, IFoundset, IFoundsetFieldsOnly, IFoundsetTree, IJSMenu, IJSMenuItem, IPopupSupportComponent, IValuelist, IViewStateListener, Locale, RequestInfoPromise, SabloTabseqConfig, ServoyWindow, ViewPort, ViewPortRow, ViewportChangeEvent, ViewportChangeListener, ViewportRowUpdate, ViewportRowUpdates };
