import * as i0 from '@angular/core';
import { input, viewChild, inject, Renderer2, ChangeDetectorRef, Directive, Injectable, DOCUMENT, signal, HostListener, ElementRef, Pipe, Inject, forwardRef, NgModule, computed } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject } from 'rxjs';
import { getLocaleNumberSymbol, NumberSymbol } from '@angular/common';
import * as i1 from '@angular/platform-browser';
import { DomSanitizer } from '@angular/platform-browser';
import numbro from 'numbro';
import BigNumber from 'bignumber.js';
import { DateTime } from 'luxon';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { __decorate, __param } from 'tslib';

/**
 * This is the BaseComponent all Titanium NGClient components should be extending
 *  It takes care of the initialization of the component by calling {@link #svyOnInit} when the component is fully constructed
 * This will only be fully done when the main div of the component has the #element reference in the tag. So that the ViewChild of angular can be resolved.
 * So the main div of a component should be something like: <div #element>. This will the be the element that will be returned by  {@link #getNativeElement}
 *
 * This base component provides the servoyApi {@link ServoyApi}, the name and also takes care of the custom attributes set in the designer.
 *
 * For performance reasons all compoents should be configured to use:  changeDetection: ChangeDetectionStrategy.OnPush in there Component configuration.
 * this way component detection is only done when a push happens on the Input fields.  If you need to trigger a change detection besides that (because of timeouts or other events)
 * call this.detectChanges()
 */
// eslint-disable-next-line
class ServoyBaseComponent {
    constructor(renderer, cdRef) {
        this.name = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
        this.servoyApi = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "servoyApi" }] : /* istanbul ignore next */ []));
        this.servoyAttributes = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "servoyAttributes" }] : /* istanbul ignore next */ []));
        this.elementRef = viewChild('element', /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "elementRef" }] : /* istanbul ignore next */ []));
        this.viewStateListeners = new Set();
        this.initialized = false;
        this.changes = null;
        this.renderer = renderer ?? inject(Renderer2);
        this.cdRef = cdRef ?? inject(ChangeDetectorRef);
        this.componentContributor = new ComponentContributor();
    }
    /**
     *  final method, do not override use {@link #svyOnInit} for this
     */
    ngOnInit() {
        this.initializeComponent();
        this.servoyApi().registerComponent(this);
    }
    /**
     *  final method, do not override use {@link #svyOnInit} for this
     */
    ngAfterViewInit() {
        this.initializeComponent();
        if (this.elementRef() && this.changes) {
            this.svyOnChanges(this.changes);
            this.changes = null;
        }
        if (!this.elementRef()) {
            console.log('component should have #element it its template for correct initalization for targetting the main div');
            console.log(this);
        }
        this.cdRef.detectChanges();
    }
    /**
     *  final method, do not override use {@link #svyOnChanges} for this
     */
    ngOnChanges(changes) {
        this.initializeComponent();
        if (!this.elementRef()) {
            if (this.changes == null) {
                this.changes = changes;
            }
            else {
                for (const property of Object.keys(changes)) {
                    this.changes[property] = changes[property];
                }
            }
        }
        else {
            if (this.changes == null) {
                this.svyOnChanges(changes);
            }
            else {
                for (const property of Object.keys(changes)) {
                    this.changes[property] = changes[property];
                }
                this.svyOnChanges(this.changes);
                this.changes = null;
            }
        }
    }
    /**
     * Angular onDestroy hook, called when the component is removed from the dom, use to clean up stuff
     * make sure you call super.ngOnDestroy()
     */
    ngOnDestroy() {
        this.servoyApi().unRegisterComponent(this);
        if (this.getNativeElement())
            this.getNativeElement()['svyHostComponent'] = null;
    }
    /**
     * This method should be overwritten to get a callback when the component is initialized
     * The template of the component must have an #element in its main tag, else this init will not resolve.
     * make sure you call super.svyOnInit() to get the default behavior
     */
    svyOnInit() {
        this.addAttributes();
        this.componentContributor.componentCreated(this);
        this.viewStateListeners.forEach(listener => listener.afterViewInit());
        if (this.getNativeElement())
            this.getNativeElement()['svyHostComponent'] = this;
    }
    /**
     * The Servoy replacement of the angular ngOnChanges, this will only be called when the component is initalized.
     *  So that you are sure that you can reference the native element through the renderer to configure it.
     */
    svyOnChanges(_changes) {
        if (_changes['servoyAttributes'] && !_changes['servoyAttributes'].firstChange) {
            if (_changes['servoyAttributes'].previousValue) {
                for (const key of Object.keys(_changes['servoyAttributes'].previousValue)) {
                    this.renderer.removeAttribute(this.getNativeElement(), key);
                }
            }
            if (_changes['servoyAttributes'].currentValue) {
                for (const key of Object.keys(_changes['servoyAttributes'].currentValue)) {
                    this.renderer.setAttribute(this.getNativeElement(), key, _changes['servoyAttributes'].currentValue[key]);
                }
            }
        }
    }
    /**
     * Call this method to trigger a change detection if something of this component is changed which didn't came directly from an @Input field change.
     * other events like timeouts or promise resolvements could result in that the component needs to detect stuff.
     */
    detectChanges() {
        this.cdRef.detectChanges();
    }
    /**
     * this should return the main native element (like the first div) which is marked as #element in the main div.
     */
    getNativeElement() {
        return this.elementRef() ? this.elementRef().nativeElement : null;
    }
    /**
     * sub classes can return a different native child then the default main element.
     */
    getNativeChild() {
        return this.elementRef().nativeElement;
    }
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getRenderer() {
        return this.renderer;
    }
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getWidth() {
        return this.getNativeElement().parentNode.parentNode.offsetWidth;
    }
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getHeight() {
        return this.getNativeElement().parentNode.parentNode.offsetHeight;
    }
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getLocationX() {
        return this.getNativeElement().parentNode.parentNode.offsetLeft;
    }
    /**
     * returns the Renderer2 object which must be used to access/change the dom elements for this component
     */
    getLocationY() {
        return this.getNativeElement().parentNode.parentNode.offsetTop;
    }
    /**
     * Direcives can add a {@link IViewStateListener} to this component so they are notified when the component is fully initialized
     * so this is for directives the same event and the {@link #svyOnInit} for subcomponents.
     * Directives needs to have a property to gain access to the component by using a attribute on the tag (besides the attribute directive itself) like [hostcomponent]="this"
     */
    addViewStateListener(listener) {
        this.viewStateListeners.add(listener);
    }
    /**
     * Removes the viewstatelistener
     */
    removeViewStateListener(listener) {
        this.viewStateListeners.delete(listener);
    }
    /**
     * @internal
     */
    initializeComponent() {
        if (!this.initialized && this.elementRef()) {
            this.initialized = true;
            this.svyOnInit();
        }
    }
    /**
     * @internal
     */
    addAttributes() {
        if (!this.servoyAttributes())
            return;
        for (const key of Object.keys(this.servoyAttributes())) {
            this.renderer.setAttribute(this.getNativeElement(), key, this.servoyAttributes()[key]);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyBaseComponent, deps: [{ token: i0.Renderer2 }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.1.0", type: ServoyBaseComponent, isStandalone: true, inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, servoyApi: { classPropertyName: "servoyApi", publicName: "servoyApi", isSignal: true, isRequired: false, transformFunction: null }, servoyAttributes: { classPropertyName: "servoyAttributes", publicName: "servoyAttributes", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "elementRef", first: true, predicate: ["element"], descendants: true, isSignal: true }], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyBaseComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ChangeDetectorRef }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], servoyApi: [{ type: i0.Input, args: [{ isSignal: true, alias: "servoyApi", required: false }] }], servoyAttributes: [{ type: i0.Input, args: [{ isSignal: true, alias: "servoyAttributes", required: false }] }], elementRef: [{ type: i0.ViewChild, args: ['element', { isSignal: true }] }] } });
/**
 * Services can use this to inject itself this contributor and then registering a listener {@link IComponentContributorListener}
 * then a service will get an event when a component is created over all forms.
 */
class ComponentContributor {
    static { this.listeners = new Set(); }
    componentCreated(component) {
        ComponentContributor.listeners.forEach(listener => listener.componentCreated(component));
    }
    addComponentListener(listener) {
        ComponentContributor.listeners.add(listener);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ComponentContributor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ComponentContributor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ComponentContributor, decorators: [{
            type: Injectable
        }] });

class Deferred {
    constructor() {
        this.promise = new Promise((resolve, reject) => {
            this._reject = reject;
            this._resolve = resolve;
        });
    }
    reject(reason) {
        this._reject(reason);
    }
    resolve(value) {
        this._resolve(value);
    }
}

class JSEvent {
}

const getWindow = () => {
    return window;
};
class WindowRefService {
    get nativeWindow() {
        return getWindow();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: WindowRefService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: WindowRefService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: WindowRefService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

// log levels for when debugEnabled(true) is called - if that is false, these levels are irrelevant
// any custom debug levels can be used as well - these are just stored here so that custom code can test the level and see if it should log its message
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["ERROR"] = 1] = "ERROR";
    LogLevel[LogLevel["WARN"] = 2] = "WARN";
    LogLevel[LogLevel["INFO"] = 3] = "INFO";
    LogLevel[LogLevel["DEBUG"] = 4] = "DEBUG";
    LogLevel[LogLevel["SPAM"] = 5] = "SPAM";
})(LogLevel || (LogLevel = {}));
class LogConfiguration {
    constructor(isDebugMode = false, level = LogLevel.WARN) {
        this.isDebugMode = isDebugMode;
        this.level = level;
    }
}
const noop = () => undefined;
class LoggerService {
    constructor(windowRefService, svyLogConfiguration, className) {
        this.svyLogConfiguration = svyLogConfiguration;
        this.className = className;
        this.enabled = false;
        const win = windowRefService.nativeWindow;
        this.console = win.console;
    }
    buildMessage(message) {
        if (this.enabled) {
            return message instanceof Function ? message() : message;
        }
    }
    get spam() {
        if (this.svyLogConfiguration.level >= LogLevel.SPAM) {
            this.enabled = true;
            return this.console.debug.bind(this.console, this.getTime() + ' SPAM ' + this.className + ' - ');
        }
        this.enabled = false;
        return noop;
    }
    get debug() {
        if (this.svyLogConfiguration.isDebugMode || this.svyLogConfiguration.level >= LogLevel.DEBUG) {
            this.enabled = true;
            return this.console.debug.bind(this.console, this.getTime() + ' DEBUG ' + this.className + ' - ');
        }
        this.enabled = false;
        return noop;
    }
    get info() {
        if (this.svyLogConfiguration.isDebugMode || this.svyLogConfiguration.level >= LogLevel.INFO) {
            this.enabled = true;
            return this.console.info.bind(this.console, this.getTime() + ' INFO ' + this.className + ' - ');
        }
        this.enabled = false;
        return noop;
    }
    get warn() {
        if (this.svyLogConfiguration.isDebugMode || this.svyLogConfiguration.level >= LogLevel.WARN) {
            this.enabled = true;
            return this.console.warn.bind(this.console, this.getTime() + ' WARN ' + this.className + ' - ');
        }
        this.enabled = false;
        return noop;
    }
    get error() {
        if (this.svyLogConfiguration.isDebugMode || this.svyLogConfiguration.level >= LogLevel.ERROR) {
            this.enabled = true;
            return this.console.error.bind(this.console, this.getTime() + ' ERROR ' + this.className + ' - ');
        }
        this.enabled = false;
        return noop;
    }
    toggleDebugMode() {
        return this.svyLogConfiguration.isDebugMode = !this.svyLogConfiguration.isDebugMode;
    }
    get logLevel() {
        return this.svyLogConfiguration.level;
    }
    set logLevel(level) {
        this.svyLogConfiguration.level = level;
    }
    getTime() {
        const time = new Date();
        return time.getHours() + ':' + time.getMinutes() + ':' + time.getSeconds();
    }
}
class LoggerFactory {
    constructor(windowRefService) {
        this.instances = {};
        this.windowRefService = windowRefService ?? inject(WindowRefService);
        const win = this.windowRefService.nativeWindow;
        win.logFactory = this;
        this.defaultLogConfiguration = win.svyLogConfiguration;
        if (this.defaultLogConfiguration == null) {
            this.defaultLogConfiguration = new LogConfiguration();
            win.svyLogConfiguration = this.defaultLogConfiguration;
            win.logLevels = { error: LogLevel.ERROR, debug: LogLevel.DEBUG, info: LogLevel.INFO, warn: LogLevel.WARN, spam: LogLevel.SPAM };
        }
    }
    getLogger(cls) {
        if (this.instances[cls] === undefined) {
            this.instances[cls] = new LoggerService(this.windowRefService, new LogConfiguration(this.defaultLogConfiguration.isDebugMode, this.defaultLogConfiguration.level), cls);
        }
        return this.instances[cls];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: LoggerFactory, deps: [{ token: WindowRefService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: LoggerFactory, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: LoggerFactory, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: WindowRefService }] });

/**
  * This is the servoy api class for components that is injected into the component by default.
  * The  {@link ServoyBaseComponent} has this as an Input property, so every component extending the  {@link ServoyBaseComponent} will have "this.servoyApi"
  * to interact with the servoy system and notify the server.
  */
class ServoyApi {
}

class TooltipService {
    constructor() {
        this.isTooltipActive = new Subject();
        this.doc = inject(DOCUMENT);
        this.windowRefService = inject(WindowRefService);
        this._isTooltipActiveSignal = signal(false, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "_isTooltipActiveSignal" }] : /* istanbul ignore next */ []));
        this.tipmousemove = (e) => {
            if (e.pageX || e.pageY) {
                this.tipmousemouveEventIsPage = true;
                this.tipmousemouveEventX = e.pageX;
                this.tipmousemouveEventY = e.pageY;
            }
            else if (e.clientX || e.clientY) {
                this.tipmousemouveEventIsPage = false;
                this.tipmousemouveEventX = e.clientX;
                this.tipmousemouveEventY = e.clientY;
            }
        };
        this.isTooltipActiveSignal = this._isTooltipActiveSignal.asReadonly();
        this.isTooltipActive.subscribe(v => this._isTooltipActiveSignal.set(v));
    }
    /**
     * Showsthe tooltip on the screen on the position of the mouse event, showing the message with a initial delay and dismissing it after dismissDelay.
     */
    showTooltip(event, message, initialDelay, dismissDelay) {
        let e = event;
        if (!e)
            e = this.windowRefService.nativeWindow.event;
        let targ;
        if (e.target)
            targ = e.target;
        else if (e.srcElement)
            targ = e.srcElement;
        if (targ.nodeType === 3) // defeat Safari bug
            targ = targ.parentNode;
        if (targ.tagName && targ.tagName.toLowerCase() === 'option') { // stop tooltip if over option element
            this.hideTooltip();
            return;
        }
        const tDiv = this.getTooltipDiv();
        tDiv.innerHTML = message;
        tDiv.style.zIndex = '99999';
        tDiv.style.width = '';
        tDiv.style.overflow = 'hidden';
        this.tipmousemove(e);
        if (this.doc.addEventListener) {
            this.doc.addEventListener('mousemove', this.tipmousemove, false);
        }
        this.tipInitialTimeout = setTimeout(() => this.adjustAndShowTooltip(dismissDelay), initialDelay);
    }
    /**
     *  hides the tooltip directly that is currently showing.
     */
    hideTooltip() {
        this.internalHideTooltip();
    }
    getTooltipDiv() {
        if (!this.tooltipDiv) {
            this.tooltipDiv = this.doc.createElement('div');
            this.tooltipDiv.id = 'mktipmsg';
            this.tooltipDiv.className = 'mktipmsg tooltip-inner'; // tooltip-inner class is also used by ui-bootstrap-tpls-0.10.0
            this.doc.getElementsByTagName('body')[0].appendChild(this.tooltipDiv);
        }
        return this.tooltipDiv;
    }
    adjustAndShowTooltip(dismissDelay) {
        let x = 0;
        let y = 0;
        if (this.tipmousemouveEventX || this.tipmousemouveEventY) {
            if (this.tipmousemouveEventIsPage) {
                x = this.tipmousemouveEventX;
                y = this.tipmousemouveEventY;
            }
            else {
                x = this.tipmousemouveEventX + this.doc.body.scrollLeft + this.doc.documentElement.scrollLeft;
                y = this.tipmousemouveEventY + this.doc.body.scrollTop + this.doc.documentElement.scrollTop;
            }
        }
        let wWidth = 0;
        let wHeight = 0;
        if (typeof (this.windowRefService.nativeWindow.innerWidth) == 'number') {
            //Non-IE
            wWidth = this.windowRefService.nativeWindow.innerWidth;
            wHeight = this.windowRefService.nativeWindow.innerHeight;
        }
        else if (this.doc.documentElement && (this.doc.documentElement.clientWidth || this.doc.documentElement.clientHeight)) {
            //IE 6+ in 'standards compliant mode'
            wWidth = this.doc.documentElement.clientWidth;
            wHeight = this.doc.documentElement.clientHeight;
        }
        const tDiv = this.getTooltipDiv();
        tDiv.style.left = x + 10 + 'px';
        tDiv.style.top = y + 10 + 'px';
        tDiv.style.display = 'block';
        const tooltipOffsetWidth = x + 10 + tDiv.offsetWidth;
        if (wWidth < tooltipOffsetWidth) {
            let newLeft = x - 10 - tDiv.offsetWidth;
            if (newLeft < 0) {
                newLeft = 0;
                tDiv.style.width = x - 10 + 'px';
            }
            if (newLeft === 0)
                newLeft = tDiv.offsetWidth;
            tDiv.style.left = newLeft + 'px';
        }
        const tooltipOffsetHeight = y + 10 + tDiv.offsetHeight;
        if (wHeight < tooltipOffsetHeight) {
            const newTop = y - 10 - tDiv.offsetHeight;
            tDiv.style.top = newTop + 'px';
        }
        this.isTooltipActive.next(true);
        this.tipTimeout = setTimeout(() => this.hideTooltip(), dismissDelay);
    }
    internalHideTooltip() {
        if (this.doc.removeEventListener)
            this.doc.removeEventListener('mousemove', this.tipmousemove, false);
        clearTimeout(this.tipInitialTimeout);
        clearTimeout(this.tipTimeout);
        if (this.tooltipDiv) {
            this.tooltipDiv.style.display = 'none';
            this.isTooltipActive.next(false);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TooltipService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TooltipService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TooltipService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

/**
 * It's meant to not depend on ServoyPublicService, but rather to be directly configurable via an htmlTooltipInitialDelay and htmlTooltipDismissDelay attrs/inputs.
 * It is useful for usage in the palette part of the form designer - which is not a Servoy client.
 */
class HTMLTooltipDirective {
    constructor() {
        this.tooltipText = input(undefined, { ...(ngDevMode ? { debugName: "tooltipText" } : /* istanbul ignore next */ {}), alias: 'htmlTooltip' });
        this.tooltipInitialDelay = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "tooltipInitialDelay" }] : /* istanbul ignore next */ []));
        this.tooltipDismissDelay = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "tooltipDismissDelay" }] : /* istanbul ignore next */ []));
        this.isActive = false;
        this.tooltipService = inject(TooltipService);
        this.tooltipService.isTooltipActive.pipe(takeUntilDestroyed()).subscribe(a => {
            this.isActive = a;
        });
    }
    onMouseEnter(event) {
        if (this.tooltipText()) {
            let initialDelay = this.getInitialDelay();
            if (initialDelay === null || isNaN(initialDelay))
                initialDelay = 750;
            let dismissDelay = this.getDismissDelay();
            if (dismissDelay === null || isNaN(dismissDelay))
                dismissDelay = 5000;
            this.tooltipService.showTooltip(event, this.tooltipText(), initialDelay, dismissDelay);
        }
    }
    getInitialDelay() {
        return this.tooltipInitialDelay();
    }
    getDismissDelay() {
        return this.tooltipDismissDelay();
    }
    onMouseLeave() {
        this.tooltipService.hideTooltip();
    }
    onClick() {
        this.tooltipService.hideTooltip();
    }
    onContextMenu() {
        this.tooltipService.hideTooltip();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: HTMLTooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: HTMLTooltipDirective, isStandalone: true, selector: "[htmlTooltip]", inputs: { tooltipText: { classPropertyName: "tooltipText", publicName: "htmlTooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipInitialDelay: { classPropertyName: "tooltipInitialDelay", publicName: "tooltipInitialDelay", isSignal: true, isRequired: false, transformFunction: null }, tooltipDismissDelay: { classPropertyName: "tooltipDismissDelay", publicName: "tooltipDismissDelay", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "pointerenter": "onMouseEnter($event)", "pointerleave": "onMouseLeave()", "click": "onClick()", "contextmenu": "onContextMenu()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: HTMLTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[htmlTooltip]',
                    standalone: true
                }]
        }], ctorParameters: () => [], propDecorators: { tooltipText: [{ type: i0.Input, args: [{ isSignal: true, alias: "htmlTooltip", required: false }] }], tooltipInitialDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipInitialDelay", required: false }] }], tooltipDismissDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipDismissDelay", required: false }] }], onMouseEnter: [{
                type: HostListener,
                args: ['pointerenter', ['$event']]
            }], onMouseLeave: [{
                type: HostListener,
                args: ['pointerleave']
            }], onClick: [{
                type: HostListener,
                args: ['click']
            }], onContextMenu: [{
                type: HostListener,
                args: ['contextmenu']
            }] } });

/**
 * This is the main servoy service that can be used by components or services to get a lot of information of the current client
 * or interact with the server by calling the server or generating the correct urls to the server.
 */
class ServoyPublicService {
    /**
     * get the character for the NumberSymbol that is given like Decimal from the current locale of the client.
     */
    getLocaleNumberSymbol(symbol) {
        return getLocaleNumberSymbol(this.getLocale(), symbol);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicService, decorators: [{
            type: Injectable
        }] });

class TooltipDirective extends HTMLTooltipDirective {
    constructor() {
        super(...arguments);
        this.tooltipText = input(undefined, { ...(ngDevMode ? { debugName: "tooltipText" } : /* istanbul ignore next */ {}), alias: 'svyTooltip' });
        this.servoyService = inject(ServoyPublicService);
    }
    getInitialDelay() {
        let initialDelay = super.getInitialDelay();
        if (initialDelay === null || isNaN(initialDelay))
            initialDelay = this.servoyService.getUIProperty("tooltipInitialDelay");
        return initialDelay;
    }
    getDismissDelay() {
        let dismissDelay = super.getDismissDelay();
        if (dismissDelay === null || isNaN(dismissDelay))
            dismissDelay = this.servoyService.getUIProperty("tooltipDismissDelay");
        return dismissDelay;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TooltipDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: TooltipDirective, isStandalone: true, selector: "[svyTooltip]", inputs: { tooltipText: { classPropertyName: "tooltipText", publicName: "svyTooltip", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyTooltip]',
                    standalone: true
                }]
        }], propDecorators: { tooltipText: [{ type: i0.Input, args: [{ isSignal: true, alias: "svyTooltip", required: false }] }] } });

class DecimalkeyconverterDirective {
    constructor(el, servoyService) {
        this.svyFormat = input(undefined, { ...(ngDevMode ? { debugName: "svyFormat" } : /* istanbul ignore next */ {}), alias: 'svyDecimalKeyConverter' });
        const elRef = el ?? inject(ElementRef);
        this.element = elRef.nativeElement;
        this.servoyService = servoyService ?? inject(ServoyPublicService);
    }
    onKeypress(e) {
        if (e.which === 110 && this.svyFormat() && this.svyFormat().type === 'NUMBER') {
            const caretPos = this.element.selectionStart;
            const startString = this.element.value.slice(0, caretPos);
            const endString = this.element.value.slice(this.element.selectionEnd, this.element.value.length);
            this.element.value = (startString + this.servoyService.getLocaleNumberSymbol(NumberSymbol.Decimal) + endString);
            this.element.focus();
            if (this.element.type === 'text')
                this.element.setSelectionRange(caretPos + 1, caretPos + 1);
            if (e.preventDefault)
                e.preventDefault();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: DecimalkeyconverterDirective, deps: [{ token: i0.ElementRef }, { token: ServoyPublicService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: DecimalkeyconverterDirective, isStandalone: true, selector: "[svyDecimalKeyConverter]", inputs: { svyFormat: { classPropertyName: "svyFormat", publicName: "svyDecimalKeyConverter", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "keydown": "onKeypress($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: DecimalkeyconverterDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyDecimalKeyConverter]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: ServoyPublicService }], propDecorators: { svyFormat: [{ type: i0.Input, args: [{ isSignal: true, alias: "svyDecimalKeyConverter", required: false }] }], onKeypress: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

class MnemonicletterFilterPipe {
    transform(input, letter) {
        if (letter && input)
            return input.replace(letter, '<u>' + letter + '</u>');
        return input;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: MnemonicletterFilterPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: MnemonicletterFilterPipe, isStandalone: true, name: "mnemonicletterFilter" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: MnemonicletterFilterPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'mnemonicletterFilter',
                    standalone: true
                }]
        }] });
class NotNullOrEmptyPipe {
    transform(value, _args) {
        if (value)
            return value.filter(a => a && !(a.realValue === null || a.realValue === '')
                || !(a.displayValue === null || a.displayValue === ''));
        return value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: NotNullOrEmptyPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: NotNullOrEmptyPipe, isStandalone: true, name: "notNullOrEmpty" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: NotNullOrEmptyPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'notNullOrEmpty',
                    standalone: true
                }]
        }] });
class HtmlFilterPipe {
    transform(input) {
        if (input && input.indexOf && input.indexOf('<body') >= 0 && input.lastIndexOf('</body') >= 0) {
            input = input.substring(input.indexOf('<body') + 6, input.lastIndexOf('</body'));
        }
        return input;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: HtmlFilterPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: HtmlFilterPipe, isStandalone: true, name: "htmlFilter" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: HtmlFilterPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'htmlFilter',
                    standalone: true
                }]
        }] });
class TrustAsHtmlPipe {
    constructor(domSanitizer) {
        this.domSanitizer = domSanitizer ?? inject(DomSanitizer);
    }
    transform(input, trustAsHtml) {
        if (trustAsHtml && input) {
            return this.domSanitizer.bypassSecurityTrustHtml(input);
        }
        return input;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TrustAsHtmlPipe, deps: [{ token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: TrustAsHtmlPipe, isStandalone: true, name: "trustAsHtml" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TrustAsHtmlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'trustAsHtml',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i1.DomSanitizer }] });

const MILLSIGN = '\u2030';
const SVY_FORMAT_DECIMAL_CHAR = '.';
/**
  * Class reflecting a Format object coming from the server (format spec property)
  */
class Format {
    constructor() {
        this.display = null;
        this.uppercase = false;
        this.lowercase = false;
        this.type = null;
        this.isMask = false;
        this.isRaw = false;
        this.isNumberValidator = false;
        this.edit = null;
        this.placeHolder = '';
        this.percent = '';
        this.allowedCharacters = '';
        this.maxLength = 0;
    }
}
/**
 * This service is able to format/parse/unformat data of different types (dates,numbers) according to the format string of the format spec property.
 *
 * Components can use the {@link FormatDirective} that uses this service in the component template: [svyFormat]="format"
 */
class FormattingService {
    constructor(servoyService) {
        this.servoyService = servoyService ?? inject(ServoyPublicService);
    }
    /**
     * format the data give with the {@link Format} object give, optionally using the display or edit format.
     */
    format(data, format, useEditFormat) {
        if ((!format) || (!format.type) || ((typeof data === 'number') && isNaN(data))) {
            if (!format && (typeof data === 'number') && !isNaN(data)) {
                // make sure is always returned with correct type, otherwise compare will not work well
                return data.toString();
            }
            return data;
        }
        const formatString = useEditFormat ? format.edit : format.display;
        if (data === undefined || data === null)
            return '';
        if ((format.type === 'NUMBER') || (format.type === 'INTEGER')) {
            return this.formatNumbers(data, formatString);
        }
        else if (format.type === 'TEXT') {
            let formattedValue = this.formatText(data, formatString);
            if (format.uppercase)
                formattedValue = formattedValue.toUpperCase();
            else if (format.lowercase)
                formattedValue = formattedValue.toLowerCase();
            return formattedValue;
        }
        else if (format.type === 'DATETIME') {
            return this.formatDate(data, formatString);
        }
        return data;
    }
    /**
     * utility function to test if a certain key is pressed
     */
    testKeyPressed(event, keyCode) {
        let code;
        if (!event)
            event = window.event;
        if (!event)
            return false;
        if (event.keyCode)
            code = event.keyCode;
        else if (event.which)
            code = event.which;
        return code === keyCode;
    }
    /**
     * utility function to test if only numbers ar pressed.
     */
    testForNumbersOnly(e, keyChar, vElement, vFindMode, vCheckNumbers, vSvyFormat, skipMaxLength) {
        if (!vFindMode && vCheckNumbers) {
            if (this.testKeyPressed(e, 13) && e.target.tagName.toUpperCase() === 'INPUT') {
                // enter key is pressed
            }
            else if (vSvyFormat.type === 'INTEGER') {
                const currentLanguageNumeralSymbols = numbro.languageData();
                if (keyChar === undefined || keyChar === null) {
                    return this.numbersonly(e, false, currentLanguageNumeralSymbols.delimiters.decimal, currentLanguageNumeralSymbols.delimiters.thousands, currentLanguageNumeralSymbols.currency
                        .symbol, vSvyFormat.percent, vElement, skipMaxLength === true ? 0 : vSvyFormat.maxLength, null);
                }
                else {
                    return this.numbersonlyForChar(keyChar, false, currentLanguageNumeralSymbols.delimiters.decimal, currentLanguageNumeralSymbols.delimiters.thousands, currentLanguageNumeralSymbols.currency.symbol, vSvyFormat.percent, vElement, skipMaxLength === true ? 0 : vSvyFormat.maxLength);
                }
            }
            else if (vSvyFormat.type === 'NUMBER' || ((vSvyFormat.type === 'TEXT') && vSvyFormat.isNumberValidator)) {
                const currentLanguageNumeralSymbols = numbro.languageData();
                if (keyChar === undefined || keyChar === null) {
                    return this.numbersonly(e, true, currentLanguageNumeralSymbols.delimiters.decimal, currentLanguageNumeralSymbols.delimiters.thousands, currentLanguageNumeralSymbols.currency.symbol, vSvyFormat.percent, vElement, skipMaxLength === true ? 0 : vSvyFormat.maxLength, vSvyFormat);
                }
                else {
                    return this.numbersonlyForChar(keyChar, true, currentLanguageNumeralSymbols.delimiters.decimal, currentLanguageNumeralSymbols.delimiters.thousands, currentLanguageNumeralSymbols.currency.symbol, vSvyFormat.percent, vElement, skipMaxLength === true ? 0 : vSvyFormat.maxLength);
                }
            }
        }
        return true;
    }
    /**
     * calls the { @link #unformat} function for unformatting/parsing the data given
     */
    parse(data, format, useEditFormat, currentValue, useHeuristics) {
        return this.unformat(data, (useEditFormat && format.edit && !format.isMask) ? format.edit : format.display, format.type, currentValue, useHeuristics);
    }
    /**
     * unformats/parse the give data according to the given format and type
     */
    unformat(data, servoyFormat, type, currentValue, useHeuristics) {
        if ((!servoyFormat) || (!type) || (!data && data !== 0))
            return data;
        if ((type === 'NUMBER') || (type === 'INTEGER')) {
            return this.unformatNumbers(data, servoyFormat);
        }
        else if (type === 'TEXT') {
            return data;
        }
        else if (type === 'DATETIME') {
            if ('' === data)
                return null;
            servoyFormat = this.convertFormat(servoyFormat);
            let d = DateTime.fromFormat(data, servoyFormat, { locale: this.servoyService.getLocale() }).toJSDate();
            if (isNaN(d.getTime()) && useHeuristics) {
                const possibleDates = new Map();
                for (const newFormat of this.getHeuristicFormats(servoyFormat, data)) {
                    d = DateTime.fromFormat(data, newFormat, { locale: this.servoyService.getLocale() }).toJSDate();
                    if (!isNaN(d.getTime())) {
                        possibleDates.set(newFormat, d);
                    }
                }
                d = this.findClosestDate(possibleDates, servoyFormat);
            }
            // if format has not year/month/day use the one from the current model value
            // because luxon will just use current date
            if (currentValue && !isNaN(currentValue.getTime())) {
                if (servoyFormat.indexOf('y') === -1) {
                    d.setFullYear(currentValue.getFullYear());
                }
                if (servoyFormat.indexOf('W') === -1 && servoyFormat.indexOf('o') === -1) {
                    if (servoyFormat.indexOf('M') === -1) {
                        d.setMonth(currentValue.getMonth());
                    }
                    if (servoyFormat.indexOf('d') === -1) {
                        d.setDate(currentValue.getDate());
                    }
                }
            }
            return d;
        }
        return data;
    }
    findClosestDate(dateMap, servoyFormat) {
        // if there is just one return that.
        if (dateMap.size === 1)
            return dateMap.values().next().value;
        // else find the one closest to the current format (starts with the same letters)
        const strippedFormat = servoyFormat.replace(/[^a-zA-Z]/g, '');
        for (const key of dateMap.keys()) {
            if (strippedFormat.startsWith(key) || servoyFormat.startsWith(key)) {
                return dateMap.get(key);
            }
        }
        // fallback to closest date
        const currentDateTime = new Date().getTime();
        const dateArray = Array.from(dateMap.values());
        const dateArrayConverted = dateArray.map(date => date.getTime()).map(time => Math.abs(currentDateTime - time));
        const index = dateArrayConverted.indexOf(Math.min(...dateArrayConverted));
        return dateArray[index];
    }
    addToFormats(formats, formatLetters, newChar, isSeparator) {
        const size = formats.length;
        if (size == 0) {
            formats.push(newChar);
        }
        else {
            const formatsCopy = Array.from(formats);
            if (newChar.match(/[a-zA-Z]/) && formatLetters.indexOf(newChar) == -1) {
                formatLetters.push(newChar);
            }
            for (let i = 0; i < formatsCopy.length; i++) {
                const newFormat = formatsCopy[i] + newChar;
                if (isSeparator && formatsCopy[i].lastIndexOf(newChar) == formatsCopy[i].length - 1)
                    continue;
                if (formats.indexOf(newFormat) == -1) {
                    if (!this.containsAllLetters(newFormat, formatLetters))
                        continue;
                    let insertIndex = -1;
                    if (newChar.match(/[a-zA-Z]/) && newFormat.indexOf(newChar) < newFormat.length - 1) {
                        insertIndex = formats.indexOf(formatsCopy[i]);
                    }
                    if (insertIndex >= 0) {
                        formats.splice(insertIndex, 0, newFormat);
                    }
                    else {
                        formats.push(newFormat);
                    }
                }
            }
        }
    }
    containsAllLetters(newFormat, formatLetters) {
        for (const formatLetter of formatLetters) {
            if (newFormat.indexOf(formatLetter) < 0) {
                return false;
            }
        }
        return true;
    }
    getHeuristicFormats(servoyFormat, input) {
        const formats = new Array();
        const formatLetters = new Array();
        if (servoyFormat) {
            for (let index = 0; index < servoyFormat.length; index++) {
                const currentChar = servoyFormat.charAt(index);
                if (currentChar.match(/[a-zA-Z]/)) {
                    this.addToFormats(formats, formatLetters, currentChar, false);
                }
                else {
                    this.addToFormats(formats, formatLetters, currentChar, true);
                }
            }
        }
        if (input) {
            return formats.filter(format => format.length === input.length && this.compareInputWithFormat(input, format));
        }
        return formats;
    }
    compareInputWithFormat(input, format) {
        for (let i = 0; i < input.length; i++) {
            const inputChar = input[i];
            const formatChar = format[i];
            if ((!inputChar.match(/[0-9]/) || !formatChar.match(/[a-zA-Z]/)) && inputChar !== formatChar) {
                return false;
            }
        }
        return true;
    }
    unformatNumbers(data, format) {
        if (data === '')
            return data;
        //treat scientiffic numbers
        if (data.toString().toLowerCase().indexOf('e') > -1 && !isNaN(data)) {
            return new Number(data).valueOf();
        }
        let multFactor = 1;
        const MILLSIGN = '\u2030';
        if (format.indexOf(MILLSIGN) > -1 && format.indexOf('\'' + MILLSIGN + '\'') == -1) {
            multFactor *= 0.001;
        }
        if (format.indexOf('\'') > -1) {
            // replace the literals
            const parts = format.split('\'');
            for (let i = 0; i < parts.length; i++) {
                if (i % 2 === 1) {
                    data = data.replace(new RegExp(parts[i], 'g'), '');
                }
            }
        }
        const formatDecimalSeparatorPos = format.indexOf('\.');
        if (formatDecimalSeparatorPos > -1) {
            const currentLanguageNumeralSymbols = numbro.languageData();
            const dataDecimalSeparatorPos = data.indexOf(currentLanguageNumeralSymbols.delimiters.decimal);
            if (dataDecimalSeparatorPos > -1) {
                const decimalLen = format.length - formatDecimalSeparatorPos - 1;
                let adjustedData = data.toString().substring(0, dataDecimalSeparatorPos + 1);
                const decimal = data.toString().substring(dataDecimalSeparatorPos + 1);
                if (decimal.length > decimalLen) {
                    adjustedData += decimal.substring(0, decimalLen);
                    data = adjustedData;
                }
            }
        }
        // first try it with the BigNumber library
        // and test if this number can be represented as a javascript number without loosing precision
        // if not, return the string representation of the number
        const stripped = data.replaceAll(numbro.languageData().delimiters.thousands, '').replace(numbro.languageData().delimiters.decimal, '.');
        let bigNumber;
        try {
            bigNumber = new BigNumber(stripped);
        }
        catch (e) {
            // If v10 throws because of symbols like '+' or '%', 
            // we fall back to a NaN BigNumber to let your existing logic take over.
            bigNumber = new BigNumber(NaN);
        }
        if (!bigNumber.isNaN() && !bigNumber.isEqualTo(bigNumber.toNumber())) {
            return bigNumber.toString();
        }
        // This regex matches optional sign, optional % or ‰ before, the number (with decimals and scientific notation), and optional % or ‰ after
        const dataNumbers = stripped.match(/[-+]?[%‰]?\d*\.?\d+(?:[eE][-+]?\d+)?[%‰]?/);
        let ret = numbro(dataNumbers ? dataNumbers[0].replace('.', numbro.languageData().delimiters.decimal) : data).value();
        ret *= multFactor;
        return ret;
    }
    numbersonly(e, decimal, decimalChar, groupingChar, currencyChar, percentChar, vElement, mlength, vSvyFormat) {
        let key;
        if (window.event) {
            key = window.event['keyCode'];
        }
        else if (e) {
            key = e.which;
        }
        else {
            return true;
        }
        if ((key == null) || (key === 0) || (key === 8) || (key === 9) || (key === 13) || (key === 27) || (e.ctrlKey && key === 97) || (e.ctrlKey && key === 99) ||
            (e.ctrlKey && key === 118) || (e.ctrlKey && key === 120)) { //added CTRL-A, X, C and V
            return true;
        }
        const keychar = String.fromCharCode(key);
        if (this.numbersonlyForChar(keychar, decimal, decimalChar, groupingChar, currencyChar, percentChar, vElement, mlength) && vSvyFormat !== null) {
            const value = vElement.value;
            if (value.includes(decimalChar) && window.getSelection().toString() !== value) {
                const allowToConcat = value.indexOf(decimalChar);
                if (e.target.selectionStart <= allowToConcat) {
                    return true;
                }
                if (vSvyFormat.edit) {
                    const maxDecimals = vSvyFormat.edit.split(SVY_FORMAT_DECIMAL_CHAR)[1].length;
                    if (value.split(decimalChar)[1].length >= maxDecimals) {
                        return false;
                    }
                }
            }
            return true;
        }
        else {
            return this.numbersonlyForChar(keychar, decimal, decimalChar, groupingChar, currencyChar, percentChar, vElement, mlength);
        }
    }
    numbersonlyForChar(keychar, decimal, decimalChar, groupingChar, currencyChar, percentChar, vElement, mlength) {
        const value = vElement.value;
        if (mlength > 0 && value) {
            let counter = 0;
            if (('0123456789').indexOf(keychar) !== -1)
                counter++;
            const stringLength = value.length;
            for (let i = 0; i < stringLength; i++) {
                if (('0123456789').indexOf(value.charAt(i)) !== -1)
                    counter++;
            }
            const selectedTxt = this.getSelectedText(vElement);
            if (selectedTxt) {
                // selection will get deleted/replaced by typed key
                for (let i = 0; i < selectedTxt.length; i++) {
                    if (('0123456789').indexOf(selectedTxt.charAt(i)) !== -1)
                        counter--;
                }
            }
            if (counter > mlength)
                return false;
        }
        if ((('-0123456789').indexOf(keychar) > -1)) {
            return true;
        }
        else if (decimal && (keychar === decimalChar)) {
            return true;
        }
        else if (keychar === groupingChar) {
            return true;
        }
        else if (keychar === currencyChar) {
            return true;
        }
        else if (keychar === percentChar) {
            return true;
        }
        return false;
    }
    getSelectedText(textarea) {
        let sel = null;
        if (textarea) {
            const start = textarea['selectionStart'];
            const end = textarea['selectionEnd'];
            sel = textarea['value'].substring(start, end);
        }
        return sel;
    }
    formatNumbers(data, servoyFormat) {
        if (!servoyFormat)
            return data;
        if (data === '')
            return data;
        let nmbr = Number(data);
        if (typeof data === 'string' && nmbr.toString() != data) {
            // this is very likely a bignumber.
            try {
                data = new BigNumber(data);
                if (data.isNaN())
                    return '';
            }
            catch (e) {
                return '';
            }
        }
        else {
            data = Number(data); // just to make sure that if it was a string representing a number we turn it into a number
            if (typeof data === 'number' && isNaN(data))
                return ''; // cannot format something that is not a number
        }
        const initialData = data;
        let patchedFormat = servoyFormat; // patched format for numbro format
        let i;
        let prefix = '';
        let sufix = '';
        if (patchedFormat.indexOf(';') > 0) {
            if (data < 0) {
                patchedFormat = patchedFormat.split(';')[1];
            }
            else
                patchedFormat = patchedFormat.split(';')[0];
        }
        if (data < 0)
            data *= -1;
        if (patchedFormat.indexOf('\u00A4') >= 0) {
            patchedFormat = patchedFormat.replace(new RegExp('\u00A4', 'g'), numbro.languageData().currency.symbol);
        }
        if (servoyFormat.indexOf('-') >= 0 && initialData >= 0 && servoyFormat.indexOf(';') < 0) {
            patchedFormat = patchedFormat.replace(new RegExp('-', 'g'), '');
        }
        if (patchedFormat.indexOf('%') > -1 && patchedFormat.indexOf('\'%\'') === -1) {
            data *= 100;
        }
        else if (patchedFormat.indexOf(MILLSIGN) > -1 && patchedFormat.indexOf('\'' + MILLSIGN + '\'') === -1) {
            data *= 1000;
        }
        let numberStart = patchedFormat.length;
        let index = patchedFormat.indexOf('0');
        if (index >= 0) {
            numberStart = index;
        }
        index = patchedFormat.indexOf('#');
        if (index >= 0 && index < numberStart) {
            numberStart = index;
        }
        let numberEnd = 0;
        index = patchedFormat.lastIndexOf('0');
        if (index >= 0) {
            numberEnd = index;
        }
        index = patchedFormat.lastIndexOf('#');
        if (index >= 0 && index > numberEnd) {
            numberEnd = index;
        }
        if (numberStart > 0) {
            prefix = patchedFormat.substring(0, numberStart);
        }
        if (numberEnd < patchedFormat.length - 1) {
            sufix = patchedFormat.substring(numberEnd + 1);
        }
        patchedFormat = patchedFormat.substring(numberStart, numberEnd + 1);
        let ret;
        prefix = prefix.replace(new RegExp('\'', 'g'), '');
        sufix = sufix.replace(new RegExp('\'', 'g'), '');
        if (servoyFormat.indexOf('-') === -1 && initialData < 0 && servoyFormat.indexOf(';') < 0) {
            prefix = prefix + '-';
        }
        // scientific notation case
        if (servoyFormat.indexOf('E') > -1) {
            const frmt = /([0#.,]+)E0+.*/.exec(patchedFormat)[1];
            let integerDigits = 0;
            let fractionalDigits = 0;
            let countIntegerState = true;
            for (i = 0; i < frmt.length; i++) {
                const chr = frmt[i];
                if (chr === '.') {
                    countIntegerState = false;
                    continue;
                }
                if (chr === ',')
                    continue;
                if (countIntegerState) {
                    integerDigits++;
                }
                else {
                    fractionalDigits++;
                }
            }
            ret = new BigNumber(data).toExponential(integerDigits + fractionalDigits);
        }
        else {
            let leftFormat = '';
            let rightFormat = '';
            if (patchedFormat.indexOf('.') >= 0) {
                leftFormat = patchedFormat.split('.')[0];
                rightFormat = patchedFormat.split('.')[1];
            }
            else {
                leftFormat = patchedFormat;
            }
            let minLenCharacteristic = 0;
            let minLenCharacteristicAfterZeroFound = 0;
            let optionalDigitsCharacteristic = 0;
            let zeroFound = false;
            for (i = 0; i < leftFormat.length; i++) {
                if (leftFormat[i] === '0') {
                    zeroFound = true;
                    minLenCharacteristic++;
                }
                else if (leftFormat[i] === '#') {
                    optionalDigitsCharacteristic++;
                }
                if (leftFormat[i] === '#' && zeroFound) {
                    minLenCharacteristicAfterZeroFound++;
                }
            }
            let minLenMantissa = 0;
            let optionalDigitsMantissa = 0;
            for (i = rightFormat.length - 1; i >= 0; i--) {
                if (rightFormat[i] === '0') {
                    minLenMantissa++;
                }
                else if (rightFormat[i] === '#') {
                    optionalDigitsMantissa++;
                }
                else if (rightFormat[i] === '.') {
                    break;
                }
            }
            let dataAsString = data + '';
            let rightData = '';
            if (dataAsString.indexOf('.') >= 0) {
                rightData = dataAsString.split('.')[1];
            }
            let rightDataMantissaLength = rightData.length;
            let mantissaLength = 0;
            if (rightDataMantissaLength <= minLenMantissa) {
                mantissaLength = minLenMantissa;
            }
            else if (rightDataMantissaLength < minLenMantissa + optionalDigitsMantissa) {
                mantissaLength = rightDataMantissaLength;
            }
            else {
                mantissaLength = minLenMantissa + optionalDigitsMantissa;
            }
            if (data instanceof BigNumber) {
                ret = data.toFormat(mantissaLength, BigNumber.ROUND_HALF_UP, {
                    decimalSeparator: numbro.languageData().delimiters.decimal,
                    groupSeparator: numbro.languageData().delimiters.thousands,
                    groupSize: patchedFormat.includes(',') ? 3 : 0,
                });
            }
            else {
                ret = numbro(data).format({
                    thousandSeparated: data > 999 && patchedFormat.includes(',') ? true : false,
                    mantissa: mantissaLength,
                    optionalMantissa: minLenMantissa === 0,
                    trimMantissa: minLenMantissa === 0 && optionalDigitsMantissa >= 0 ? true : false,
                    characteristic: minLenCharacteristic + minLenCharacteristicAfterZeroFound,
                    optionalCharacteristic: rightDataMantissaLength === 0 && minLenMantissa === 0 && minLenCharacteristic === 0 && optionalDigitsCharacteristic > 0
                });
            }
        }
        return prefix + ret + sufix;
    }
    formatText(data, servoyFormat) {
        if (!servoyFormat)
            return data;
        const error = 'input string not corresponding to format : ' + data + ' , ' + servoyFormat;
        let ret = '';
        let isEscaping = false;
        let offset = 0;
        if (data && typeof data === 'number') {
            data = data.toString();
        }
        for (let i = 0; i < servoyFormat.length; i++) {
            const formatChar = servoyFormat[i];
            const dataChar = data[i - offset];
            if (dataChar === undefined)
                break;
            if (isEscaping && formatChar !== '\'') {
                if (dataChar !== formatChar)
                    throw error;
                ret += dataChar;
                continue;
            }
            switch (formatChar) {
                case '\'':
                    isEscaping = !isEscaping;
                    offset++;
                    break;
                case 'U':
                    if (dataChar.match(/[a-zA-Z\u00C0-\u00ff]/) == null)
                        throw error;
                    ret += dataChar.toUpperCase();
                    break;
                case 'L':
                    if (dataChar.match(/[a-zA-Z\u00C0-\u00ff]/) == null)
                        throw error;
                    ret += dataChar.toLowerCase();
                    break;
                case 'A':
                    if (dataChar.match(/[0-9a-zA-Z\u00C0-\u00ff]/) == null)
                        throw error;
                    ret += dataChar;
                    break;
                case '?':
                    if (dataChar.match(/[a-zA-Z\u00C0-\u00ff]/) == null)
                        throw error;
                    ret += dataChar;
                    break;
                case '*':
                    ret += dataChar;
                    break;
                case 'H':
                    if (dataChar.match(/[0-9a-fA-F]/) == null)
                        throw error;
                    ret += dataChar.toUpperCase();
                    break;
                case '#':
                    if (dataChar.match(/[\d]/) == null)
                        throw error;
                    ret += dataChar;
                    break;
                default:
                    ret += formatChar;
                    if (formatChar !== dataChar)
                        offset++;
                    break;
            }
        }
        return ret;
    }
    formatDate(data, dateFormat) {
        if (!(data instanceof Date))
            return data;
        // single quote escape workaround until https://github.com/moment/luxon/issues/649 is fixed
        dateFormat = this.convertFormat(dateFormat).replace("''", "'svy_quote'");
        const formatted = DateTime.fromJSDate(data).setLocale(this.servoyService.getLocale()).toFormat(dateFormat).replace('svy_quote', "'");
        return formatted.trim ? formatted.trim() : formatted;
    }
    convertFormat(dateFormat) {
        let result = '';
        let inSingleQuotes = false;
        let containsEE = dateFormat.includes('EE');
        for (let i = 0; i < dateFormat.length; i++) {
            if (dateFormat[i] === "'") {
                inSingleQuotes = !inSingleQuotes;
                result += dateFormat[i];
                continue;
            }
            if (inSingleQuotes) {
                result += dateFormat[i];
                continue;
            }
            if (!containsEE && dateFormat[i] === 'E') {
                result += 'EEE';
                continue;
            }
            if (dateFormat[i] === 'a' && i < dateFormat.length - 1 && dateFormat[i + 1] === 'a') {
                result += 'a';
                i++;
                continue;
            }
            switch (dateFormat[i]) {
                case 'Y':
                    result += 'y';
                    break;
                case 'u':
                    result += 'E';
                    break;
                case 'w':
                    result += 'W';
                    break;
                case 'K':
                    result += 'h';
                    break;
                case 'k':
                    result += 'H';
                    break;
                case 'D':
                    result += 'o';
                    break;
                default: result += dateFormat[i];
            }
        }
        if (result.includes('W')) {
            let tempResult = '';
            inSingleQuotes = false;
            for (let i = 0; i < result.length; i++) {
                if (result[i] === "'") {
                    inSingleQuotes = !inSingleQuotes;
                    tempResult += result[i];
                    continue;
                }
                if (!inSingleQuotes && result[i] === 'y') {
                    tempResult += 'k';
                }
                else {
                    tempResult += result[i];
                }
            }
            result = tempResult;
        }
        return result;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormattingService, deps: [{ token: ServoyPublicService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormattingService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormattingService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: ServoyPublicService }] });

class FormatFilterPipe {
    constructor(formatService, logFactory) {
        this.formatService = formatService ?? inject(FormattingService);
        this.log = (logFactory ?? inject(LoggerFactory)).getLogger('formatpipe');
    }
    transform(input, format) {
        if (!format)
            return input;
        try {
            return this.formatService.format(input, format, !format.display);
        }
        catch (e) {
            this.log.error(e);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormatFilterPipe, deps: [{ token: FormattingService }, { token: LoggerFactory }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: FormatFilterPipe, isStandalone: true, name: "formatFilter" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormatFilterPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'formatFilter',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: FormattingService }, { type: LoggerFactory }] });

class EmptyValueFilterPipe {
    transform(input) {
        // eslint-disable-next-line eqeqeq
        if (input == '')
            return '\u00A0';
        return input;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: EmptyValueFilterPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: EmptyValueFilterPipe, isStandalone: true, name: "emptyValue" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: EmptyValueFilterPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'emptyValue',
                    standalone: true
                }]
        }] });

class StartEditDirective {
    constructor(logFactory) {
        this.dataProviderID = input(undefined, { ...(ngDevMode ? { debugName: "dataProviderID" } : /* istanbul ignore next */ {}), alias: 'svyStartEdit' });
        this.hostComponent = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "hostComponent" }] : /* istanbul ignore next */ []));
        this.log = (logFactory ?? inject(LoggerFactory)).getLogger('StartEditDirective');
    }
    onFocus(e) {
        if (!this.hostComponent()) {
            this.log.error('host component not found for the start edit directive use [hostComponent]="self" besides this in the template (component must be extending ServoyBaseComponent)');
        }
        else if (this.hostComponent().servoyApi() && this.dataProviderID() !== undefined) {
            this.hostComponent().servoyApi().startEdit(this.dataProviderID());
        }
        else {
            this.log.error('Can\'t call startEdit, missing servoyApi and dataProviderID for field ' + this.hostComponent());
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: StartEditDirective, deps: [{ token: LoggerFactory }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: StartEditDirective, isStandalone: true, selector: "[svyStartEdit]", inputs: { dataProviderID: { classPropertyName: "dataProviderID", publicName: "svyStartEdit", isSignal: true, isRequired: false, transformFunction: null }, hostComponent: { classPropertyName: "hostComponent", publicName: "hostComponent", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "focus": "onFocus($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: StartEditDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyStartEdit]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: LoggerFactory }], propDecorators: { dataProviderID: [{ type: i0.Input, args: [{ isSignal: true, alias: "svyStartEdit", required: false }] }], hostComponent: [{ type: i0.Input, args: [{ isSignal: true, alias: "hostComponent", required: false }] }], onFocus: [{
                type: HostListener,
                args: ['focus', ['$event']]
            }] } });

class TabFixDirective {
    constructor() {
        // this directive needs to be in a module because of listener priority, so i put it here
        this.typeahead = input(undefined, { ...(ngDevMode ? { debugName: "typeahead" } : /* istanbul ignore next */ {}), alias: 'svyTabFix' });
        this.startedTyping = false;
    }
    onFocus(target) {
        this.startedTyping = false;
    }
    handleKeyDown(event) {
        if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
            // stop propagation when using list form component (to not break the selection)
            event.stopPropagation();
        }
        if (event.key !== 'Tab') {
            this.startedTyping = true;
        }
        else if (!this.startedTyping) {
            this.typeahead().closePopup();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TabFixDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: TabFixDirective, isStandalone: true, selector: "[svyTabFix]", inputs: { typeahead: { classPropertyName: "typeahead", publicName: "svyTabFix", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "focus": "onFocus($event)", "keydown": "handleKeyDown($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: TabFixDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyTabFix]',
                    standalone: true
                }]
        }], ctorParameters: () => [], propDecorators: { typeahead: [{ type: i0.Input, args: [{ isSignal: true, alias: "svyTabFix", required: false }] }], onFocus: [{
                type: HostListener,
                args: ['focus', ['$event']]
            }], handleKeyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

class ImageMediaIdDirective {
    constructor(elemRef, renderer, windowRefService) {
        this.media = input(undefined, { ...(ngDevMode ? { debugName: "media" } : /* istanbul ignore next */ {}), alias: 'svyImageMediaId' });
        this.hostComponent = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "hostComponent" }] : /* istanbul ignore next */ []));
        this.imgStyle = null;
        this.rollOverImgStyle = null;
        this._elemRef = elemRef ?? inject(ElementRef);
        this._renderer = renderer ?? inject(Renderer2);
        this.windowRefService = windowRefService ?? inject(WindowRefService);
        this.clearStyle = new Map();
        this.clearStyle.set('width', '0px');
        this.clearStyle.set('height', '0px');
        this.clearStyle.set('backgroundImage', '');
    }
    ngOnChanges(changes) {
        if (changes['hostComponent']) {
            this.hostComponent().addViewStateListener(this);
        }
        if (changes['media']) {
            this.setImageStyle();
        }
    }
    ngOnDestroy() {
        if (this.hostComponent()) {
            this.hostComponent().removeViewStateListener(this);
            if (this.resizeObserver)
                this.resizeObserver.unobserve(this.hostComponent().getNativeElement());
        }
    }
    afterViewInit() {
        const nativeElement = this.hostComponent().getNativeElement();
        const renderer = this.hostComponent().getRenderer();
        renderer.listen(nativeElement, 'mouseenter', (e) => {
            if (this.rollOverImgStyle) {
                this.setCSSStyle(this.rollOverImgStyle);
            }
        });
        renderer.listen(nativeElement, 'mouseleave', (e) => {
            if (this.rollOverImgStyle) {
                if (this.imgStyle) {
                    this.setCSSStyle(this.imgStyle);
                }
                else {
                    this.setCSSStyle(this.clearStyle);
                }
            }
        });
        this.resizeObserver = new ResizeObserver(() => {
            this.setImageStyle();
        });
        this.resizeObserver.observe(nativeElement);
        this.setImageStyle();
    }
    setImageStyle() {
        if (this.media() && (this.media().img || this.media().rollOverImg) || this.rollOverImgStyle || this.imgStyle) {
            const componentSize = {
                width: this._elemRef.nativeElement.parentNode.parentNode.clientWidth,
                height: this._elemRef.nativeElement.parentNode.parentNode.clientHeight
            };
            if (componentSize.height === 0 || componentSize.width === 0)
                setTimeout(() => this.setImageStyle(), 100);
            else {
                const mediaOptions = this.media().mediaOptions;
                if (this.media().rollOverImg) {
                    this.rollOverImgStyle = this.parseImageOptions(this.media().rollOverImg, mediaOptions, componentSize);
                }
                else {
                    this.rollOverImgStyle = null;
                }
                if (this.media().img) {
                    this.imgStyle = this.parseImageOptions(this.media().img, mediaOptions, componentSize);
                    this.setCSSStyle(this.imgStyle);
                }
                else {
                    this.imgStyle = null;
                    this.setCSSStyle(this.clearStyle);
                }
            }
        }
    }
    parseImageOptions(image, mediaOptions, componentSize) {
        const bgstyle = new Map();
        bgstyle.set('background-image', 'url(\'' + image + '\')');
        bgstyle.set('background-repeat', 'no-repeat');
        bgstyle.set('background-position', 'left');
        bgstyle.set('display', 'inline-block');
        bgstyle.set('vertical-align', 'middle');
        if (mediaOptions === undefined)
            mediaOptions = 14; // reduce-enlarge & keep aspect ration
        const mediaKeepAspectRatio = mediaOptions === 0 || ((mediaOptions & 8) === 8);
        // default  img size values
        let imgWidth = 16;
        let imgHeight = 16;
        if (image.indexOf('imageWidth=') > 0 && image.indexOf('imageHeight=') > 0) {
            const vars = {};
            image.replace(/[?&]+([^=&]+)=([^&]*)/gi, (m, key, value) => {
                vars[key] = value;
            });
            imgWidth = vars['imageWidth'];
            imgHeight = vars['imageHeight'];
        }
        const widthChange = imgWidth / componentSize.width;
        const heightChange = imgHeight / componentSize.height;
        if (widthChange > 1.01 || heightChange > 1.01 || widthChange < 0.99 || heightChange < 0.99) {
            if ((mediaOptions & 6) === 6) {
                if (mediaKeepAspectRatio) {
                    if (widthChange > heightChange) {
                        imgWidth = imgWidth / widthChange;
                        imgHeight = imgHeight / widthChange;
                    }
                    else {
                        imgWidth = imgWidth / heightChange;
                        imgHeight = imgHeight / heightChange;
                    }
                }
                else {
                    imgWidth = componentSize.width;
                    imgHeight = componentSize.height;
                }
            }
            else if ((mediaOptions & 2) == 2) {
                if (widthChange > 1.01 && heightChange > 1.01) {
                    if (mediaKeepAspectRatio) {
                        if (widthChange > heightChange) {
                            imgWidth = imgWidth / widthChange;
                            imgHeight = imgHeight / widthChange;
                        }
                        else {
                            imgWidth = imgWidth / heightChange;
                            imgHeight = imgHeight / heightChange;
                        }
                    }
                    else {
                        imgWidth = componentSize.width;
                        imgHeight = componentSize.height;
                    }
                }
                else if (widthChange > 1.01) {
                    imgWidth = imgWidth / widthChange;
                    if (mediaKeepAspectRatio) {
                        imgHeight = imgHeight / widthChange;
                    }
                    else {
                        imgHeight = componentSize.height;
                    }
                }
                else if (heightChange > 1.01) {
                    imgHeight = imgHeight / heightChange;
                    if (mediaKeepAspectRatio) {
                        imgWidth = imgWidth / heightChange;
                    }
                    else {
                        imgWidth = componentSize.width;
                    }
                }
            }
            else if ((mediaOptions & 4) == 4) {
                if (widthChange < 0.99 && heightChange < 0.99) {
                    if (mediaKeepAspectRatio) {
                        if (widthChange > heightChange) {
                            imgWidth = imgWidth / widthChange;
                            imgHeight = imgHeight / widthChange;
                        }
                        else {
                            imgWidth = imgWidth / heightChange;
                            imgHeight = imgHeight / heightChange;
                        }
                    }
                    else {
                        imgWidth = componentSize.width;
                        imgHeight = componentSize.height;
                    }
                }
                else if (widthChange < 0.99) {
                    imgWidth = imgWidth / widthChange;
                    if (mediaKeepAspectRatio) {
                        imgHeight = imgHeight / widthChange;
                    }
                    else {
                        imgHeight = componentSize.height;
                    }
                }
                else if (heightChange < 0.99) {
                    imgHeight = imgHeight / heightChange;
                    if (mediaKeepAspectRatio) {
                        imgWidth = imgWidth / heightChange;
                    }
                    else {
                        imgWidth = componentSize.width;
                    }
                }
            }
        }
        bgstyle.set('background-size', mediaKeepAspectRatio ? 'contain' : '100% 100%');
        bgstyle.set('width', Math.round(imgWidth) + 'px');
        bgstyle.set('height', Math.round(imgHeight) + 'px');
        return bgstyle;
    }
    setCSSStyle(cssStyle) {
        cssStyle.forEach((value, key) => {
            this._renderer.setStyle(this._elemRef.nativeElement, key, value);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ImageMediaIdDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: WindowRefService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: ImageMediaIdDirective, isStandalone: true, selector: "[svyImageMediaId]", inputs: { media: { classPropertyName: "media", publicName: "svyImageMediaId", isSignal: true, isRequired: false, transformFunction: null }, hostComponent: { classPropertyName: "hostComponent", publicName: "hostComponent", isSignal: true, isRequired: false, transformFunction: null } }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ImageMediaIdDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyImageMediaId]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: WindowRefService }], propDecorators: { media: [{ type: i0.Input, args: [{ isSignal: true, alias: "svyImageMediaId", required: false }] }], hostComponent: [{ type: i0.Input, args: [{ isSignal: true, alias: "hostComponent", required: false }] }] } });

class AutosaveDirective {
    constructor(servoyService, elementRef) {
        this.servoyService = servoyService ?? inject(ServoyPublicService);
        this.elementRef = elementRef ?? inject(ElementRef);
    }
    onClick(target) {
        if (target == this.elementRef.nativeElement || target.parentNode == this.elementRef.nativeElement) {
            this.servoyService.callService('applicationServerService', 'autosave', {}, true);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: AutosaveDirective, deps: [{ token: ServoyPublicService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.0", type: AutosaveDirective, isStandalone: true, selector: "[svyAutosave]", host: { listeners: { "click": "onClick($event.target)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: AutosaveDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyAutosave]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: ServoyPublicService }, { type: i0.ElementRef }], propDecorators: { onClick: [{
                type: HostListener,
                args: ['click', ['$event.target']]
            }] } });

class UploadDirective {
    constructor(servoyService) {
        this.formname = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "formname" }] : /* istanbul ignore next */ []));
        this.componentName = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "componentName" }] : /* istanbul ignore next */ []));
        this.propertyName = 'dataProviderID';
        this.servoyService = servoyService ?? inject(ServoyPublicService);
    }
    click(e) {
        this.servoyService.showFileOpenDialog('Please select a file', false, null, this.url);
    }
    ngOnInit() {
        this.url = this.servoyService.generateUploadUrl(this.formname(), this.componentName(), this.propertyName);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: UploadDirective, deps: [{ token: ServoyPublicService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: UploadDirective, isStandalone: true, selector: "[svyUpload]", inputs: { formname: { classPropertyName: "formname", publicName: "formname", isSignal: true, isRequired: false, transformFunction: null }, componentName: { classPropertyName: "componentName", publicName: "componentName", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "click($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: UploadDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[svyUpload]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: ServoyPublicService }], propDecorators: { formname: [{ type: i0.Input, args: [{ isSignal: true, alias: "formname", required: false }] }], componentName: [{ type: i0.Input, args: [{ isSignal: true, alias: "componentName", required: false }] }], click: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

const MASK_CONST = {
    // Predefined character definitions
    definitions: {
        '#': '[0-9]',
        0: '[0-9]',
        U: '[A-Z]',
        L: '[a-z]',
        A: '[A-Za-z0-9]',
        '?': '[A-Za-z]',
        '*': '.',
        H: '[A-F0-9]'
    },
    converters: {
        U(c) {
            return c.toUpperCase();
        },
        L(c) {
            return c.toLowerCase();
        },
        H(c) {
            return c.toUpperCase();
        }
    }
};
let MaskFormat = class MaskFormat {
    constructor(format, _renderer, element, formatService, doc) {
        this.format = format;
        this._renderer = _renderer;
        this.element = element;
        this.formatService = formatService;
        this.doc = doc;
        this.firstNonMaskPos = -1;
        this.buffer = [];
        this.tests = [];
        this.converters = [];
        this.listeners = [];
        this.ignore = false;
        this.settings = {};
        this.settings['placeholder'] = this.format.placeHolder ? this.format.placeHolder : ' ';
        if (this.format.allowedCharacters)
            this.settings['allowedCharacters'] = this.format.allowedCharacters;
        if (!this.settings['completed']) {
            this.settings['completed'] = null;
        }
        this.mask = this.format.edit;
        //          if (!this.mask && this.element.value.length > 0) { //TODO check condition
        //              return this.buffer.map(function(c, i) { //TODO why return??
        //                  return this.tests[i] ? c : null;
        //              }, this).join('');
        //          }
        let skipNextMask = false;
        this.filteredMask = '';
        const defs = MASK_CONST.definitions;
        const converts = MASK_CONST.converters;
        this.converters = [];
        let partialPosition = this.mask.length;
        let len = this.mask.length;
        const chars = this.mask.split('');
        for (let i = 0; i < chars.length; i++) {
            const c = chars[i];
            //            if (c == '?') {
            //                len--;
            //                partialPosition = i;
            //            } else
            if (!skipNextMask && c === '\'') {
                skipNextMask = true;
                len--;
                partialPosition--;
            }
            else {
                if (!skipNextMask && defs[c]) {
                    if (c === '*' && this.settings['allowedCharacters']) {
                        this.tests.push(new RegExp('[' + this.settings['allowedCharacters'] + ']'));
                    }
                    else {
                        this.tests.push(new RegExp(defs[c]));
                    }
                    if (this.firstNonMaskPos === -1)
                        this.firstNonMaskPos = this.tests.length - 1;
                }
                else {
                    this.tests.push(null);
                    skipNextMask = false;
                }
                this.converters.push(converts[c]);
                this.filteredMask += c;
            }
        }
        this.buffer = this.filteredMask.split('').map((c, i, array) => {
            return this.tests[i] ? this.getPlaceHolder(i) : c;
        });
        this.listeners.push(this._renderer.listen(this.element, 'input', () => {
            this.setCaret(this.checkVal(true));
        }));
        this.listeners.push(this._renderer.listen(this.element, 'focus', () => this.onFocus()));
        this.listeners.push(this._renderer.listen(this.element, 'blur', () => this.onBlur()));
        this.listeners.push(this._renderer.listen(this.element, 'keypress', (event) => this.onKeypress(event)));
        this.listeners.push(this._renderer.listen(this.element, 'keydown', (event) => this.onKeydown(event)));
    }
    onFocus() {
        this.focusText = this.element.value;
        const pos = this.checkVal(true);
        this.writeBuffer();
        setTimeout(() => this.setCaretOnFocus(pos), 0);
    }
    setCaretOnFocus(pos) {
        if (pos !== this.filteredMask.length) {
            this.setCaret(pos);
        }
        else {
            this.setCaret(this.element.selectionStart);
        }
    }
    onBlur() {
        this.checkVal(true);
        if (this.element.value !== this.focusText) {
            this.element.dispatchEvent(new CustomEvent('change', { bubbles: true }));
        }
    }
    onKeypress(e) {
        if (this.formatService.testKeyPressed(e, 13) && e.target.tagName.toUpperCase() === 'INPUT') {
            //do not looses focus, just apply the format and push value
            this.element.dispatchEvent(new CustomEvent('change', { bubbles: true }));
            return true;
        }
        if (this.ignore) {
            this.ignore = false;
            // Fixes Mac FF bug on backspace
            return (e.keyCode === 8) ? false : null;
        }
        // TODO needed? e = e || window.event;
        const k = e.charCode || e.keyCode || e.which;
        const posBegin = this.element.selectionStart;
        const posEnd = this.element.selectionEnd;
        if (e.ctrlKey || e.altKey || e.metaKey) { // Ignore
            return true;
        }
        else if ((k >= 32 && k <= 125) || k > 186) { // typeable characters
            const p = this.seekNext(posBegin - 1);
            if (p < this.mask.length) {
                let c = String.fromCharCode(k);
                if (this.converters[p]) {
                    c = this.converters[p](c);
                }
                if (this.tests[p].test(c)) {
                    //                    shiftR(p);
                    this.buffer[p] = c;
                    this.writeBuffer();
                    const next = this.seekNext(p);
                    this.setCaret(next);
                    if (this.settings['completed'] && next == this.mask.length)
                        this.settings['completed'].call(this.element);
                }
            }
        }
        return false;
    }
    onKeydown(e) {
        const iPhone = (window.orientation !== undefined);
        let posBegin = this.element.selectionStart;
        let posEnd = this.element.selectionEnd;
        const k = e.keyCode;
        this.ignore = (k < 16 || (k > 16 && k < 32) || (k > 32 && k < 41));
        if (k === 37) {
            const nextValidChar = this.seekPrevious(posBegin);
            if (nextValidChar !== posBegin) {
                this.setCaret(nextValidChar);
                return false;
            }
            return;
        }
        else if (k === 39) {
            const nextValidChar = this.seekNext(posBegin);
            if (nextValidChar !== posBegin) {
                this.setCaret(nextValidChar);
                return false;
            }
            return;
        }
        else {
            const nextValidChar = this.seekNext(posBegin - 1) - posBegin;
            if (nextValidChar > 0) {
                posBegin += nextValidChar;
                posEnd += nextValidChar;
            }
        }
        // backspace, delete, and escape get special treatment
        if (k === 8 || k === 46 || (iPhone && k === 127)) {
            if (posBegin === posEnd) {
                this.clear(posBegin + (k === 46 ? 0 : -1), (k === 46 ? 1 : 0));
            }
            else {
                this.clearBuffer(posBegin, posEnd);
                this.writeBuffer();
                this.setCaret(Math.max(this.firstNonMaskPos, posBegin));
            }
            return false;
        }
        else if (k === 27) { // escape
            this.element.value = this.focusText;
            this.setCaret(0, this.checkVal());
            return false;
        }
        else if (posBegin !== posEnd && !this.ignore) {
            this.clearBuffer(posBegin, posEnd);
        }
    }
    setCaret(begin, end) {
        if (this.element.value.length === 0)
            return;
        if (typeof begin === 'number') {
            end = (typeof end === 'number') ? end : begin;
            if (this.element != null) {
                if (this.element['createTextRange']) {
                    const range = this.element['createTextRange']();
                    range.move('character', begin);
                    range.select();
                }
                else if (this.element.selectionStart >= 0) {
                    this.element.setSelectionRange(begin, end);
                }
            }
        }
        else {
            if (this.element['setSelectionRange']) {
                begin = this.element.selectionStart;
                end = this.element.selectionEnd;
            }
            else if (this.doc.getSelection() && this.doc.getSelection()['createRange']) {
                const range = this.doc.getSelection()['createRange']();
                begin = 0 - range.duplicate().moveStart('character', -100000);
                end = begin + range.text.length;
            }
            return { begin, end };
        }
    }
    seekPrevious(pos) {
        while (--pos >= 0 && !this.tests[pos])
            ;
        return pos;
    }
    seekNext(pos) {
        while (++pos <= this.mask.length && !this.tests[pos])
            ;
        return pos;
    }
    clear(pos, caretAddition) {
        while (!this.tests[pos] && --pos >= 0)
            ;
        if (this.tests[pos]) {
            this.buffer[pos] = this.getPlaceHolder(pos);
        }
        this.writeBuffer();
        if (caretAddition !== 0) {
            let nextPos = pos + caretAddition;
            while (nextPos >= 0 && nextPos < this.mask.length) {
                if (this.tests[nextPos]) {
                    pos = nextPos;
                    break;
                }
                nextPos = nextPos + caretAddition;
            }
        }
        this.setCaret(Math.max(this.firstNonMaskPos, pos));
    }
    clearBuffer(start, end) {
        for (let i = start; i < end && i < this.mask.length; i++) {
            if (this.tests[i])
                this.buffer[i] = this.getPlaceHolder(i);
        }
    }
    writeBuffer() {
        this.element.value = this.buffer.join('');
        return this.element.value;
    }
    checkVal(allow = false) {
        // try to place characters where they belong
        const partialPosition = this.mask.length;
        const test = this.element.value;
        let lastMatch = -1;
        let firstError = -1;
        let i = 0;
        for (let pos = 0; i < this.mask.length; i++) {
            if (this.tests[i]) {
                this.buffer[i] = this.getPlaceHolder(i);
                while (pos++ < test.length) {
                    const c = test.charAt(pos - 1);
                    // if the char is the place holder then dont shift..
                    if (c === this.buffer[i]) {
                        if (firstError === -1)
                            firstError = i;
                        break;
                    }
                    if (this.tests[i].test(c)) {
                        this.buffer[i] = c;
                        lastMatch = i;
                        break;
                    }
                }
                if (pos > test.length)
                    break;
            }
            else if (this.buffer[i] === test.charAt(pos) && i !== partialPosition) {
                pos++;
                //                    lastMatch = i;
            }
        }
        if (!allow && lastMatch + 1 < partialPosition) {
            this.element.value = '';
            this.clearBuffer(0, this.mask.length);
        }
        else if (allow && lastMatch === -1) {
            this.element.value = '';
            this.clearBuffer(0, this.mask.length);
        }
        else if (allow || lastMatch + 1 >= partialPosition) {
            this.writeBuffer();
            if (!allow)
                this.element.value = this.element.value.substring(0, lastMatch + 1);
        }
        return firstError !== -1 ? firstError : (partialPosition ? i : this.firstNonMaskPos);
    }
    getPlaceHolder(i) {
        return this.settings['placeholder'].length > 1 ? this.settings['placeholder'].charAt(i) : this.settings['placeholder'];
    }
    destroy() {
        this.listeners.forEach(unregisterFunction => unregisterFunction());
        this.listeners = [];
    }
};
MaskFormat = __decorate([
    __param(4, Inject(DOCUMENT))
], MaskFormat);

class NumberParser {
    constructor() {
        const locale = new Intl.NumberFormat().resolvedOptions().locale;
        const parts = new Intl.NumberFormat(locale).formatToParts(12345.6);
        const numerals = [...new Intl.NumberFormat(locale, { useGrouping: false }).format(9876543210)].reverse();
        const index = new Map(numerals.map((d, i) => [d, i]));
        this._group = new RegExp(`[${parts.find((d) => d.type === 'group').value}]`, 'g');
        this._decimal = new RegExp(`[${parts.find((d) => d.type === 'decimal').value}]`);
        this._numeral = new RegExp(`[${numerals.join('')}]`, 'g');
        this._index = d => index.get(d).toString();
    }
    parse(str) {
        return (str.trim().replace(this._group, '').replace(this._decimal, '.').replace(this._numeral, this._index)) ? +str : NaN;
    }
}
/**
  * This is the format directive [svyFormat]="format" that can format the dataprovider value in a input field and parse the value back when the user changes the value.
  * this is an Angular  ControlValueAccessor  that sits between the angular component ( {@link ServoyBaseComponent } and the dom element, it writes the formatted value to the dom
  * and parses and pushes the parsed value back into the component.
  *
  * it uses the {@link FormattingService} for this.
  */
class FormatDirective {
    static { this.DATETIMEFORMAT = { display: 'yyyy-MM-dd\'T\'HH:mm:ss', type: 'DATETIME' }; }
    static { this.DATEFORMAT = { display: 'yyyy-MM-dd', type: 'DATETIME' }; }
    static { this.MONTHFORMAT = { display: 'yyyy-MM', type: 'DATETIME' }; }
    static { this.WEEKFORMAT = { display: 'YYYY-\'W\'WW', type: 'DATETIME' }; }
    static { this.TIMEFORMAT = { display: 'HH:mm', type: 'DATETIME' }; }
    static { this.BROWSERNUMBERFORMAT = new NumberParser(); }
    constructor(renderer, elementRef, formatService, doc, logFactory) {
        this.format = input(undefined, { ...(ngDevMode ? { debugName: "format" } : /* istanbul ignore next */ {}), alias: 'svyFormat' });
        this.findmode = input(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "findmode" }] : /* istanbul ignore next */ []));
        this.hasFocus = false;
        this.realValue = null;
        this.isKeyPressEventFired = false;
        this.oldInputValue = null;
        this.listeners = [];
        this.maskFormat = null;
        this.onChangeCallback = (_) => { };
        this.onTouchedCallback = () => { };
        this._renderer = renderer ?? inject(Renderer2);
        this._elementRef = elementRef ?? inject(ElementRef);
        this.formatService = formatService ?? inject(FormattingService);
        this.doc = doc ?? inject(DOCUMENT);
        this.log = (logFactory ?? inject(LoggerFactory)).getLogger('formatdirective');
    }
    touched(target) {
        if (target && "value" in target) {
            this.onTouchedCallback();
            this.hasFocus = false;
            this.dateInputChange(target.value);
            const inputType = this.getType();
            if (this.format().display && !this.format().isMask && !(inputType === 'datetime-local' || inputType === 'date' || inputType === 'time' || inputType === 'month' || inputType === 'week')) {
                this.writeValue(this.realValue);
            }
            if (!this.format().isMask && (this.format().uppercase || this.format().lowercase) && this.focusText != this._elementRef.nativeElement.value && inputType === 'text') {
                this._elementRef.nativeElement.dispatchEvent(new CustomEvent('change', { bubbles: true }));
            }
        }
    }
    focussed() {
        this.hasFocus = true;
        // make sure all updates are processed
        setTimeout(() => {
            this.focusText = this._elementRef.nativeElement.value;
        });
        if (this.format().display && this.format().edit && this.format().edit !== this.format().display) {
            this.writeValue(this.realValue);
        }
    }
    keyDown(event) {
        if (event.key === 'Enter') {
            this.dateInputChange(event.target.value);
        }
    }
    input(target) {
        if (target && "value" in target) {
            let data = target.value;
            const inputType = this.getType();
            if (inputType === 'datetime-local' || inputType === 'date' || inputType === 'time' || inputType === 'month' || inputType === 'week') {
                return;
            }
            else if (inputType === 'number') {
                data = FormatDirective.BROWSERNUMBERFORMAT.parse(data);
            }
            else if (inputType === 'email') {
                data = target.value;
            }
            else if (!this.findmode() && this.format()) {
                const type = this.format().type;
                let format = this.format().display ? this.format().display : this.format().edit;
                if (this.hasFocus && this.format().edit && !this.format().isMask)
                    format = this.format().edit;
                try {
                    data = this.formatService.unformat(data, format, type, this.realValue, true);
                }
                catch (e) {
                    this.log.error(e);
                    //TODO set error state
                }
                if (this.format().type === 'TEXT' && this.format().isRaw && this.format().isMask && typeof data === 'string') {
                    if (data && format && data.length === format.length) {
                        let ret = '';
                        for (let i = 0; i < format.length; i++) {
                            switch (format[i]) {
                                case 'U':
                                case 'L':
                                case 'A':
                                case '?':
                                case '*':
                                case 'H':
                                case '#':
                                    ret += data[i];
                                    break;
                                default:
                                    // ignore literal characters
                                    break;
                            }
                        }
                        data = ret;
                    }
                }
            }
            this.setRealValue(data);
        }
    }
    dateInputChange(value) {
        let data = value;
        const inputType = this.getType();
        if (inputType === 'datetime-local' || inputType === 'date' || inputType === 'time' || inputType === 'month' || inputType === 'week') {
            const luxonDate = DateTime.fromISO(data);
            if (luxonDate.isValid)
                data = luxonDate.toJSDate();
            else
                data = null;
            this.setRealValue(data);
        }
    }
    setRealValue(value) {
        this.realValue = value;
        this.onChangeCallback(value);
    }
    ngAfterViewInit() {
        this.setFormat();
    }
    ngOnChanges() {
        this.setFormat();
    }
    registerOnChange(fn) {
        this.onChangeCallback = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedCallback = fn;
    }
    writeValue(value) {
        this.realValue = value;
        const inputType = this.getType();
        if (inputType === 'datetime-local') {
            const data = this.formatService.format(value, FormatDirective.DATETIMEFORMAT, false);
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', data);
        }
        else if (inputType === 'date') {
            const data = this.formatService.format(value, FormatDirective.DATEFORMAT, false);
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', data);
        }
        else if (inputType === 'time') {
            const data = this.formatService.format(value, FormatDirective.TIMEFORMAT, false);
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', data);
        }
        else if (inputType === 'month') {
            const data = this.formatService.format(value, FormatDirective.MONTHFORMAT, false);
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', data);
        }
        else if (inputType === 'week') {
            const data = this.formatService.format(value, FormatDirective.WEEKFORMAT, false);
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', data);
        }
        else if (inputType === 'number') {
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', value);
        }
        else if (inputType === 'email') {
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', value);
        }
        else if ((value !== null && value !== undefined) && this.format()) {
            let data = value;
            if (!this.findmode()) {
                data = inputType === 'number' && data.toString().length >= this.format().maxLength ? data.toString().substring(0, this.format().maxLength) : data;
                let useEdit = !this.format().display;
                if (this.format().edit && !this.format().isMask && this.hasFocus)
                    useEdit = true;
                try {
                    data = this.formatService.format(data, this.format(), useEdit);
                }
                catch (e) {
                    this.log.error(e);
                }
                if (data && this.format().type === 'TEXT') {
                    if (this.format().uppercase)
                        data = data.toUpperCase();
                    else if (this.format().lowercase)
                        data = data.toLowerCase();
                }
            }
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', data);
        }
        else {
            this._renderer.setProperty(this._elementRef.nativeElement, 'value', (value !== null && value !== undefined) ? value : '');
        }
    }
    getType() {
        const type = this._elementRef.nativeElement.type;
        return type ? type.toLocaleLowerCase() : 'text';
    }
    setFormat() {
        this.listeners.forEach(lFn => lFn());
        this.listeners = [];
        if (this.maskFormat) {
            this.maskFormat.destroy();
            this.maskFormat = null;
        }
        if (this.format()) {
            if (!this.findmode() && (this.format().uppercase || this.format().lowercase)) {
                this.listeners.push(this._renderer.listen(this._elementRef.nativeElement, 'input', () => this.upperOrLowerCase()));
            }
            if (this.format().isNumberValidator || this.format().type === 'NUMBER' || this.format().type === 'INTEGER') {
                this.listeners.push(this._renderer.listen(this._elementRef.nativeElement, 'keypress', (event) => {
                    this.isKeyPressEventFired = true;
                    return this.formatService.testForNumbersOnly(event, null, this._elementRef.nativeElement, this.findmode(), true, this.format(), false);
                }));
                this.listeners.push(this._renderer.listen(this._elementRef.nativeElement, 'input', (event) => this.inputFiredForNumbersCheck(event)));
            }
            if (this.format().maxLength) {
                if (!this.findmode()) {
                    this._renderer.setAttribute(this._elementRef.nativeElement, 'maxlength', this.format().maxLength + '');
                }
                else {
                    this._renderer.removeAttribute(this._elementRef.nativeElement, 'maxlength');
                }
            }
            if (!this.findmode() && this.format().isMask) {
                this.maskFormat = new MaskFormat(this.format(), this._renderer, this._elementRef.nativeElement, this.formatService, this.doc);
            }
            this.writeValue(this.realValue);
        }
    }
    // lower and upper case handling
    upperOrLowerCase() {
        const element = this._elementRef.nativeElement;
        const caretPos = element.selectionStart;
        element.value = this.format().uppercase ? element.value.toUpperCase() : element.value.toLowerCase();
        element.setSelectionRange(caretPos, caretPos);
    }
    inputFiredForNumbersCheck(event) {
        let currentValue = this._elementRef.nativeElement.value;
        if (!this.isKeyPressEventFired && event.target.tagName.toUpperCase() === 'INPUT') {
            // get inserted chars
            const inserted = this.findDelta(currentValue, this.oldInputValue);
            // get removed chars
            const removed = this.findDelta(this.oldInputValue, currentValue);
            // determine if user pasted content
            const pasted = inserted.length > 1 || (!inserted && !removed);
            if (!pasted && !removed) {
                if (!this.formatService.testForNumbersOnly(event, inserted, this._elementRef.nativeElement, this.findmode(), true, this.format(), true)) {
                    currentValue = this.oldInputValue;
                }
            }
            //If number validator, check all chars in string and extract only the valid chars.
            if (event.target.type.toUpperCase() === 'NUMBER' || this.format().type === 'NUMBER' || this.format().type === 'INTEGER' || this.format().isNumberValidator) {
                currentValue = this.getNumbersFromString(event, currentValue, this.oldInputValue);
            }
            if (currentValue !== this._elementRef.nativeElement.value) {
                this._elementRef.nativeElement.value = currentValue;
                // // detect IE8 and above, and Edge; call on change manually because of https://bugs.jquery.com/ticket/10818
                // if (/MSIE/.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge/.test(navigator.userAgent)) {
                // 	var changeOnBlurForIE = function() {
                // 		 element.change();
                // 		 element.off("blur", callChangeOnBlur);
                // 	 }
                // 	 element.on("blur", changeOnBlurForIE);
                // }
            }
            this.oldInputValue = currentValue;
            this.isKeyPressEventFired = false;
        }
        if (this.isKeyPressEventFired) {
            this.oldInputValue = currentValue;
            this.isKeyPressEventFired = false;
        }
    }
    findDelta(value, prevValue) {
        let delta = '';
        if (typeof value === 'string' && typeof prevValue === 'string' && value.length >= prevValue.length) {
            for (let i = 0; i < value.length; i++) {
                const str = value.substr(0, i) + value.substr(i + value.length - prevValue.length);
                if (str === prevValue) {
                    delta = value.substr(i, value.length - prevValue.length);
                    break;
                }
            }
        }
        return delta;
    }
    getNumbersFromString(e, currentValue, oldInputValue) {
        if (oldInputValue === currentValue) {
            return currentValue;
        }
        let stripped = '';
        const editFormat = this.format().edit ? this.format().edit : this.format().display;
        for (let i = 0; i < currentValue.length; i++) {
            if (this.formatService.testForNumbersOnly(e, currentValue.charAt(i), this._elementRef.nativeElement, this.findmode(), true, this.format(), true)
                || (editFormat && i < editFormat.length && editFormat.charAt(i) === currentValue.charAt(i))) {
                stripped = stripped + currentValue.charAt(i);
                if (stripped.length === this.format().maxLength)
                    break;
            }
        }
        return stripped;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormatDirective, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: FormattingService }, { token: DOCUMENT }, { token: LoggerFactory }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: FormatDirective, isStandalone: true, selector: "[svyFormat]", inputs: { format: { classPropertyName: "format", publicName: "svyFormat", isSignal: true, isRequired: false, transformFunction: null }, findmode: { classPropertyName: "findmode", publicName: "findmode", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "blur": "touched($event.target)", "focus": "focussed()", "keydown": "keyDown($event)", "change": "input($event.target)" } }, providers: [{
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FormatDirective),
                multi: true
            }], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: FormatDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[svyFormat]',
                    providers: [{
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FormatDirective),
                            multi: true
                        }],
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: FormattingService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: LoggerFactory }], propDecorators: { format: [{ type: i0.Input, args: [{ isSignal: true, alias: "svyFormat", required: false }] }], findmode: [{ type: i0.Input, args: [{ isSignal: true, alias: "findmode", required: false }] }], touched: [{
                type: HostListener,
                args: ['blur', ['$event.target']]
            }], focussed: [{
                type: HostListener,
                args: ['focus', []]
            }], keyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], input: [{
                type: HostListener,
                args: ['change', ['$event.target']]
            }] } });

// eslint-disable-next-line @angular-eslint/directive-class-suffix
class SabloTabseq {
    constructor(elemRef /*, private _cdRef: ChangeDetectorRef*/) {
        this.designTabSeqInput = input(undefined, { ...(ngDevMode ? { debugName: "designTabSeqInput" } : /* istanbul ignore next */ {}), alias: 'sabloTabseq' });
        this.configInput = input(undefined, { ...(ngDevMode ? { debugName: "configInput" } : /* istanbul ignore next */ {}), alias: 'sabloTabseqConfig' });
        this.designChildIndexToArrayPosition = {};
        this.designChildTabSeq = []; // contains ordered numbers that will be keys in 'runtimeChildIndexes'; can have duplicates
        // map designChildIndex[i] -> runtimeIndex for child or designChildIndex[i] -> [runtimeIndex1, runtimeIndex2] in case there are multiple equal design time indexes
        this.runtimeChildIndexes = {};
        this._elemRef = elemRef ?? inject(ElementRef);
    }
    get config() {
        return this.configInput();
    }
    setParentSTS(parentSTS) {
        this.parentSTS = parentSTS;
    }
    // handle event: Child Servoy Tab Sequence registered
    registerChildHandler(event) {
        const customEvent = event;
        customEvent.detail.childSTS.setParentSTS(this);
        if (this.designTabSeq === -2 || customEvent.detail.designChildIndex === -2) {
            this.recalculateIndexes(customEvent.detail.designChildIndex ? customEvent.detail.designChildIndex : 0, false);
            event.stopPropagation();
            return false;
        }
        // insert it sorted
        let posInDesignArray = 0;
        for (let tz = 0; tz < this.designChildTabSeq.length && this.designChildTabSeq[tz] < customEvent.detail.designChildIndex; tz++) {
            posInDesignArray = tz + 1;
        }
        if (posInDesignArray === this.designChildTabSeq.length || this.designChildTabSeq[posInDesignArray] > customEvent.detail.designChildIndex) {
            this.designChildTabSeq.splice(posInDesignArray, 0, customEvent.detail.designChildIndex);
            // always keep in designChildIndexToArrayPosition[i] the first occurrance of design index i in the sorted designChildTabSeq array
            for (let tz = posInDesignArray; tz < this.designChildTabSeq.length; tz++) {
                this.designChildIndexToArrayPosition[this.designChildTabSeq[tz]] = tz;
            }
            this.runtimeChildIndexes[customEvent.detail.designChildIndex] = customEvent.detail.runtimeChildIndex;
        }
        else {
            // its == that means that we have dupliate design indexes; we treat this special - all same design index children as a list in one runtime index array cell
            if (!isRuntimeIndexArray(this.runtimeChildIndexes[customEvent.detail.designChildIndex])) {
                this.runtimeChildIndexes[customEvent.detail.designChildIndex] = [this.runtimeChildIndexes[customEvent.detail.designChildIndex]];
            }
            this.runtimeChildIndexes[customEvent.detail.designChildIndex].push(customEvent.detail.runtimeChildIndex);
        }
        this.recalculateIndexes(customEvent.detail.designChildIndex ? customEvent.detail.designChildIndex : 0, false);
        event.stopPropagation();
        return false;
    }
    unregisterChildSTS(designChildIndex, runtimeChildIndex) {
        if (this.designTabSeq === -2 || designChildIndex === -2) {
            return; // nothing to do; either this parent or the child was/were already excluded from the tabSeq
        }
        const posInDesignArray = this.designChildIndexToArrayPosition[designChildIndex];
        if (posInDesignArray !== undefined) {
            const keyInRuntimeArray = this.designChildTabSeq[posInDesignArray];
            const runtimeChildIndexForKey = this.runtimeChildIndexes[keyInRuntimeArray];
            if (!isRuntimeIndexArray(runtimeChildIndexForKey)) {
                delete this.designChildIndexToArrayPosition[designChildIndex];
                for (const tmp in this.designChildIndexToArrayPosition) {
                    if (this.designChildIndexToArrayPosition[tmp] > posInDesignArray)
                        this.designChildIndexToArrayPosition[tmp]--;
                }
                this.designChildTabSeq.splice(posInDesignArray, 1);
                delete this.runtimeChildIndexes[keyInRuntimeArray];
            }
            else { // multiple equal design values
                runtimeChildIndexForKey.splice(runtimeChildIndexForKey.indexOf(runtimeChildIndex), 1);
                if (runtimeChildIndexForKey.length === 1)
                    this.runtimeChildIndexes[keyInRuntimeArray] = runtimeChildIndexForKey[0];
            }
        }
    }
    // handle event: child tree was now linked or some child needs extra indexes; runtime indexes can be computed starting at the given child;
    // recalculate Parent Servoy Tab Sequence
    recalculateIndexesHandler(event) {
        const customEvent = event;
        const designChildIndex = customEvent.detail.designChildIndex;
        const initialRootRecalculate = customEvent.detail.initialRootRecalculate;
        return this.recalculateIndexes(designChildIndex, initialRootRecalculate, event);
    }
    recalculateIndexes(designChildIndex, initialRootRecalculate, event) {
        if (this.designTabSeq === -2 || designChildIndex === -2) {
            if (event)
                event.stopPropagation();
            return false;
        }
        if (!this.initializing) {
            // a new child is ready/linked; recalculate tab indexes for it and after it
            const startIdx = (this.designChildIndexToArrayPosition && this.designChildIndexToArrayPosition[designChildIndex] !== undefined) ?
                this.designChildIndexToArrayPosition[designChildIndex] : 0;
            this.recalculateChildRuntimeIndexesStartingAt(startIdx, false);
        }
        else if (initialRootRecalculate) {
            // this is $rootScope (one $parent extra cause the directive creates it); we always assume a sabloTabseq directive is bound to it;
            // now that it is linked we can do initial calculation of tre
            this.runtimeIndex.startIndex = this.runtimeIndex.nextAvailableIndex = 1;
            this.recalculateChildRuntimeIndexesStartingAt(0, true);
        } // else wait for parent tabSeq directives to get linked as well
        if (event)
            event.stopPropagation();
        return false;
    }
    disableTabseq(event) {
        const customEvent = event;
        this.isEnabled = false;
        this.recalculateChildRuntimeIndexesStartingAt(0, true);
        customEvent.stopPropagation();
        return false;
    }
    enableTabseq(event) {
        const customEvent = event;
        this.isEnabled = true;
        this.triggerRecalculatePSTSInParent(0);
        customEvent.stopPropagation();
        return false;
    }
    ngOnInit() {
        // called by angular in parents first then in children
        this.designTabSeq = this.designTabSeqInput() || 0;
        this.initializing = true;
        this.isEnabled = true;
        // runtime index -1 == SKIP focus traversal in browser
        // runtime index  0 == DEFAULT == design tab seq 0 (no tabIndex attr set to element or it's children)
        this.runtimeIndex = { startIndex: -1, nextAvailableIndex: -1, sablotabseq: this };
        // -1 runtime initially for all (in case some node in the tree has -2 design (skip) and children have >= 0,
        // at runtime all children should be excluded as well)
        this.updateCurrentDomElTabIndex();
        // check to see if this is the top-most tabSeq container
        if (this.config && this.config.root) {
            // it's root tab seq container (so no parent); just do initial tree calculation
            this.recalculateIndexes(0, true);
        }
        else {
            if (this.designTabSeq !== -2) {
                this.triggerRegisterCSTSInParent(this.designTabSeq, this.runtimeIndex);
            }
        }
    }
    ngOnChanges(changes) {
        const change = changes['designTabSeqInput'];
        if (change && !change.firstChange) {
            if (!(this.config && this.config.root)) {
                if (change.previousValue !== -2)
                    this.triggerUnregisterCSTSInParent(change.previousValue, this.runtimeIndex);
                this.designTabSeq = this.designTabSeqInput() || 0;
                this.runtimeIndex.startIndex = -1;
                this.runtimeIndex.nextAvailableIndex = -1;
                this.initializing = true;
                if (this.designTabSeq !== -2) {
                    this.triggerRegisterCSTSInParent(this.designTabSeq, this.runtimeIndex);
                    // here we could send [0] instead of [designTabSeq] - it would potentially calculate more but start again from first parent available index,
                    // not higher index (the end user behavior being the same)
                    this.triggerRecalculatePSTSInParent(this.designTabSeq);
                }
                else {
                    this.updateCurrentDomElTabIndex(); // -1 runtime
                }
            }
        }
    }
    recalculateChildRuntimeIndexesStartingAt(posInDesignArray /*inclusive*/, triggeredByParent) {
        if (this.designTabSeq === -2)
            return;
        if (!this.isEnabled || this.runtimeIndex.startIndex === -1) {
            this.runtimeIndex.nextAvailableIndex = this.runtimeIndex.startIndex;
            this.runtimeIndex.startIndex = -1;
        }
        else if (this.designTabSeq === 0) {
            // this element doesn't set any tabIndex attribute (default behavior)
            this.runtimeIndex.nextAvailableIndex = this.runtimeIndex.startIndex;
            this.runtimeIndex.startIndex = 0;
        }
        else if (this.runtimeIndex.startIndex === 0) {
            this.runtimeIndex.nextAvailableIndex = 0;
        }
        else if (this.runtimeIndex.nextAvailableIndex === -1) {
            const reservedGap = (this.config && this.config.reservedGap) ? this.config.reservedGap : 0;
            this.runtimeIndex.nextAvailableIndex = this.runtimeIndex.startIndex + reservedGap;
        }
        if (posInDesignArray === 0)
            this.updateCurrentDomElTabIndex();
        let recalculateStartIndex = this.runtimeIndex.startIndex;
        if (posInDesignArray > 0 && posInDesignArray - 1 < this.designChildTabSeq.length) {
            const runtimeCI = this.runtimeChildIndexes[this.designChildTabSeq[posInDesignArray - 1]]; // this can be an array in case of multiple equal design indexes being siblings
            recalculateStartIndex = isRuntimeIndexArray(runtimeCI) ? runtimeCI[runtimeCI.length - 1].nextAvailableIndex : runtimeCI.nextAvailableIndex;
        }
        for (let i = posInDesignArray; i < this.designChildTabSeq.length; i++) {
            const childRuntimeIndex = this.runtimeChildIndexes[this.designChildTabSeq[i]];
            if (isRuntimeIndexArray(childRuntimeIndex)) {
                // multiple equal design time indexes as siblings
                let max = recalculateStartIndex;
                for (const oneChildRuntimeIndex of childRuntimeIndex) {
                    oneChildRuntimeIndex.startIndex = recalculateStartIndex;
                    // call recalculate on whole child; normally it only makes sense for same index siblings
                    // if they are not themselfes containers, just apply the given value
                    oneChildRuntimeIndex.sablotabseq.recalculateChildRuntimeIndexesStartingAt(0, true);
                    if (max < oneChildRuntimeIndex.nextAvailableIndex)
                        max = oneChildRuntimeIndex.nextAvailableIndex;
                }
                recalculateStartIndex = max;
            }
            else {
                childRuntimeIndex.startIndex = recalculateStartIndex;
                childRuntimeIndex.sablotabseq.recalculateChildRuntimeIndexesStartingAt(0, true); // call recalculate on whole child
                recalculateStartIndex = childRuntimeIndex.nextAvailableIndex;
            }
        }
        if (this.initializing)
            this.initializing = false; // it's now considered initialized as first runtime index caluculation is done
        let parentRecalculateNeeded;
        if (this.runtimeIndex.startIndex !== 0 && this.runtimeIndex.startIndex !== -1) {
            const ownTabIndexBump = this.hasOwnTabIndex() ? 1 : 0;
            parentRecalculateNeeded = (this.runtimeIndex.nextAvailableIndex < recalculateStartIndex + ownTabIndexBump);
            const reservedGap = (this.config && this.config.reservedGap) ? this.config.reservedGap : 0;
            if (parentRecalculateNeeded)
                this.runtimeIndex.nextAvailableIndex = recalculateStartIndex + reservedGap + ownTabIndexBump;
        }
        else {
            // start index 0 means default (no tabIndex attr. set)
            parentRecalculateNeeded = false;
        }
        // if this container now needs more tab indexes than it was reserved; a recalculate on parent needs to be triggered in this case
        if (parentRecalculateNeeded && !triggeredByParent)
            this.triggerRecalculatePSTSInParent(this.designTabSeq);
    }
    hasOwnTabIndex() {
        return (!this.config || !(this.config.container || this.config.root));
    }
    updateCurrentDomElTabIndex() {
        if (this.hasOwnTabIndex()) {
            if (this.runtimeIndex.startIndex !== 0) {
                this.setDOMTabIndex(this.runtimeIndex.startIndex);
            }
            else {
                this.setDOMTabIndex(undefined);
            }
        }
    }
    setDOMTabIndex(tabindex) {
        if (this.config && this.config.tabSeqSetter)
            this.config.tabSeqSetter.setTabIndex(tabindex);
        else
            this._elemRef.nativeElement.setAttribute('tabindex', `${tabindex}`);
    }
    triggerRecalculatePSTSInParent(designChildIndex) {
        this.triggerInParent('recalculatePSTS', { designChildIndex, initialRootRecalculate: false });
    }
    triggerRegisterCSTSInParent(designChildIndex, runtimeChildIndex) {
        this.triggerInParent('registerCSTS', { designChildIndex, runtimeChildIndex, childSTS: this });
    }
    triggerUnregisterCSTSInParent(designChildIndex, runtimeChildIndex) {
        if (this.parentSTS) {
            this.parentSTS.unregisterChildSTS(designChildIndex, runtimeChildIndex);
            this.parentSTS = undefined;
        }
    }
    triggerInParent(eventName, arg) {
        this._elemRef.nativeElement.parentNode.dispatchEvent(new CustomEvent(eventName, {
            bubbles: true,
            detail: arg
        }));
    }
    ngOnDestroy() {
        // unregister current tabSeq from parent tabSeq container
        this.triggerUnregisterCSTSInParent(this.designTabSeq, this.runtimeIndex);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SabloTabseq, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.0", type: SabloTabseq, isStandalone: true, selector: "[sabloTabseq]", inputs: { designTabSeqInput: { classPropertyName: "designTabSeqInput", publicName: "sabloTabseq", isSignal: true, isRequired: false, transformFunction: null }, configInput: { classPropertyName: "configInput", publicName: "sabloTabseqConfig", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "registerCSTS": "registerChildHandler($event)", "recalculatePSTS": "recalculateIndexesHandler($event)", "disableTabseq": "disableTabseq($event)", "enableTabseq": "enableTabseq($event)" } }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SabloTabseq, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[sabloTabseq]',
                    standalone: true
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { designTabSeqInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "sabloTabseq", required: false }] }], configInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "sabloTabseqConfig", required: false }] }], registerChildHandler: [{
                type: HostListener,
                args: ['registerCSTS', ['$event']]
            }], recalculateIndexesHandler: [{
                type: HostListener,
                args: ['recalculatePSTS', ['$event']]
            }], disableTabseq: [{
                type: HostListener,
                args: ['disableTabseq', ['$event']]
            }], enableTabseq: [{
                type: HostListener,
                args: ['enableTabseq', ['$event']]
            }] } });
const isRuntimeIndexArray = (o) => {
    return o.push !== undefined;
};

class ServoyPublicModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicModule, imports: [TabFixDirective,
            TooltipDirective,
            HTMLTooltipDirective,
            MnemonicletterFilterPipe,
            NotNullOrEmptyPipe,
            HtmlFilterPipe,
            FormatDirective,
            DecimalkeyconverterDirective,
            FormatFilterPipe,
            EmptyValueFilterPipe,
            StartEditDirective,
            ImageMediaIdDirective,
            AutosaveDirective,
            UploadDirective,
            SabloTabseq,
            TrustAsHtmlPipe], exports: [TabFixDirective,
            TooltipDirective,
            HTMLTooltipDirective,
            MnemonicletterFilterPipe,
            NotNullOrEmptyPipe,
            HtmlFilterPipe,
            FormatDirective,
            DecimalkeyconverterDirective,
            FormatFilterPipe,
            EmptyValueFilterPipe,
            StartEditDirective,
            ImageMediaIdDirective,
            AutosaveDirective,
            UploadDirective,
            SabloTabseq,
            TrustAsHtmlPipe] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicModule, providers: [TooltipService, FormattingService, ComponentContributor] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [TabFixDirective,
                        TooltipDirective,
                        HTMLTooltipDirective,
                        MnemonicletterFilterPipe,
                        NotNullOrEmptyPipe,
                        HtmlFilterPipe,
                        FormatDirective,
                        DecimalkeyconverterDirective,
                        FormatFilterPipe,
                        EmptyValueFilterPipe,
                        StartEditDirective,
                        ImageMediaIdDirective,
                        AutosaveDirective,
                        UploadDirective,
                        SabloTabseq,
                        TrustAsHtmlPipe
                    ],
                    exports: [TabFixDirective,
                        TooltipDirective,
                        HTMLTooltipDirective,
                        MnemonicletterFilterPipe,
                        NotNullOrEmptyPipe,
                        HtmlFilterPipe,
                        FormatDirective,
                        DecimalkeyconverterDirective,
                        FormatFilterPipe,
                        EmptyValueFilterPipe,
                        StartEditDirective,
                        ImageMediaIdDirective,
                        AutosaveDirective,
                        UploadDirective,
                        SabloTabseq,
                        TrustAsHtmlPipe
                    ],
                    providers: [TooltipService, FormattingService, ComponentContributor]
                }]
        }] });

class LocalStorageService {
    constructor(logFactory) {
        this.prefix = '';
        this.hasLocalStorage = this.isSupported();
        this.log = (logFactory ?? inject(LoggerFactory)).getLogger('LocalStorageService');
    }
    isSupported() {
        try {
            localStorage.setItem(this.prefix + 'key', 'value');
            localStorage.removeItem(this.prefix + 'key');
            return true;
        }
        catch (e) {
            return false;
        }
    }
    set(key, value) {
        if (this.hasLocalStorage) {
            try {
                localStorage.setItem(this.prefix + key, JSON.stringify(value));
            }
            catch (e) {
                this.log.error(e);
                return false;
            }
            return true;
        }
        return false;
    }
    get(key) {
        if (this.hasLocalStorage) {
            try {
                const value = localStorage.getItem(this.prefix + key);
                return value && JSON.parse(value);
            }
            catch (e) {
                this.log.error(e);
                return null;
            }
        }
        return null;
    }
    has(key) {
        return null !== this.get(key);
    }
    remove(key) {
        if (this.hasLocalStorage) {
            try {
                localStorage.removeItem(this.prefix + key);
            }
            catch (e) {
                this.log.error(e);
                return false;
            }
            return true;
        }
        return false;
    }
    clear() {
        if (!this.hasLocalStorage)
            return false;
        if (!!this.prefix) {
            const prefixLength = this.prefix.length;
            try {
                for (const key in localStorage) {
                    if (key.substr(0, prefixLength) === this.prefix) {
                        localStorage.removeItem(key);
                    }
                }
            }
            catch (e) {
                this.log.error(e);
                return false;
            }
            return true;
        }
        try {
            localStorage.clear();
        }
        catch (e) {
            this.log.error(e);
            return false;
        }
        return true;
    }
    key(index) {
        if (this.hasLocalStorage) {
            return localStorage.key(index);
        }
        return null;
    }
    changePrefix(newPrefix) {
        this.prefix = newPrefix;
    }
    length() {
        if (this.hasLocalStorage) {
            return localStorage.length;
        }
        return 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: LocalStorageService, deps: [{ token: LoggerFactory }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: LocalStorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: LocalStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: LoggerFactory }] });

class SessionStorageService {
    constructor(logFactory) {
        this.prefix = '';
        this.hasSessionStorage = this.isSupported();
        this.log = (logFactory ?? inject(LoggerFactory)).getLogger('SessionStorageService');
    }
    isSupported() {
        try {
            sessionStorage.setItem(this.prefix + 'key', 'value');
            sessionStorage.removeItem(this.prefix + 'key');
            return true;
        }
        catch (e) {
            return false;
        }
    }
    set(key, value) {
        if (this.hasSessionStorage) {
            try {
                sessionStorage.setItem(this.prefix + key, JSON.stringify(value));
            }
            catch (e) {
                this.log.error(e);
                return false;
            }
            return true;
        }
        return false;
    }
    get(key) {
        if (this.hasSessionStorage) {
            try {
                const value = sessionStorage.getItem(this.prefix + key);
                return value && JSON.parse(value);
            }
            catch (e) {
                this.log.error(e);
                return null;
            }
        }
        return null;
    }
    has(key) {
        return null !== this.get(key);
    }
    remove(key) {
        if (this.hasSessionStorage) {
            try {
                sessionStorage.removeItem(this.prefix + key);
            }
            catch (e) {
                this.log.error(e);
                return false;
            }
            return true;
        }
        return false;
    }
    clear() {
        if (!this.hasSessionStorage)
            return false;
        if (!!this.prefix) {
            const prefixLength = this.prefix.length;
            try {
                for (const key in sessionStorage) {
                    if (key.substr(0, prefixLength) === this.prefix) {
                        sessionStorage.removeItem(key);
                    }
                }
            }
            catch (e) {
                this.log.error(e);
                return false;
            }
            return true;
        }
        try {
            sessionStorage.clear();
        }
        catch (e) {
            this.log.error(e);
            return false;
        }
        return true;
    }
    key(index) {
        if (this.hasSessionStorage) {
            return localStorage.key(index);
        }
        return null;
    }
    length() {
        if (this.hasSessionStorage) {
            return sessionStorage.length;
        }
        return 0;
    }
    changePrefix(newPrefix) {
        this.prefix = newPrefix;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SessionStorageService, deps: [{ token: LoggerFactory }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SessionStorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SessionStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: LoggerFactory }] });

class MainViewRefService {
    get mainContainer() {
        return this._mainRef;
    }
    set mainContainer(ref) {
        this._mainRef = ref;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: MainViewRefService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: MainViewRefService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: MainViewRefService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

const scrollbarConstants = {
    SCROLLBARS_WHEN_NEEDED: 0,
    VERTICAL_SCROLLBAR_AS_NEEDED: 1,
    VERTICAL_SCROLLBAR_ALWAYS: 2,
    VERTICAL_SCROLLBAR_NEVER: 4,
    HORIZONTAL_SCROLLBAR_AS_NEEDED: 8,
    HORIZONTAL_SCROLLBAR_ALWAYS: 16,
    HORIZONTAL_SCROLLBAR_NEVER: 32
};
class PropertyUtils {
    static setHorizontalAlignment(element, renderer, halign) {
        if (halign !== -1) {
            if (halign === 0) {
                renderer.setStyle(element, 'text-align', 'center');
            }
            else if (halign === 4) {
                renderer.setStyle(element, 'text-align', 'right');
            }
            else {
                renderer.setStyle(element, 'text-align', 'left');
            }
        }
    }
    static setRotation(element, renderer, rotation, size) {
        const r = 'rotate(' + rotation + 'deg)';
        renderer.setStyle(element, '-moz-transform', r);
        renderer.setStyle(element, '-webkit-transform', r);
        renderer.setStyle(element, '-o-transform', r);
        renderer.setStyle(element, '-ms-transform', r);
        renderer.setStyle(element, 'transform', r);
        renderer.setStyle(element, 'position', 'absolute');
        if ((rotation === 90 || rotation === 270) && size) {
            renderer.setStyle(element, 'width', size.height + 'px');
            renderer.setStyle(element, 'height', size.width + 'px');
            renderer.setStyle(element, 'left', (size.width - size.height) / 2 + 'px');
            renderer.setStyle(element, 'top', (size.height - size.width) / 2 + 'px');
        }
    }
    static setBorder(element, renderer, newVal) {
        if (typeof newVal !== 'object' || newVal == null) {
            renderer.removeStyle(element, 'border');
            return;
        }
        if (renderer.parentNode(element).nodeName === 'FIELDSET') {
            // unwrap fieldset
            const parent = renderer.parentNode(element);
            renderer.insertBefore(renderer.parentNode(parent), element, parent);
            renderer.removeChild(renderer.parentNode(parent), parent);
        }
        if (newVal.type === 'TitledBorder') {
            const fieldset = renderer.createElement('fieldset');
            renderer.setAttribute(fieldset, 'style', 'padding:5px;margin:0px;border:1px solid silver;width:100%;height:100%');
            const legend = renderer.createElement('legend');
            renderer.setAttribute(legend, 'style', 'float: none;border-bottom:0px; margin:0px;width:auto;color:' + newVal.color + ';text-align:' + newVal.titleJustification);
            if (newVal.font) {
                for (const key of Object.keys(newVal.font)) {
                    // keys like 'fontSize' need to be converted into 'font-size'
                    renderer.setStyle(legend, key.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase(), newVal.font[key]);
                }
            }
            renderer.appendChild(legend, renderer.createText(newVal.title));
            // this is the way it is done in the old ngclient, but the actual component is positioned partially outside the border
            //            var parent = renderer.parentNode(element);
            //            renderer.insertBefore(parent, fieldset, element);
            //            renderer.appendChild(fieldset, legend);
            //            renderer.appendChild(fieldset, element);
            renderer.appendChild(fieldset, legend);
            for (const i in element.childNodes) {
                if (element.childNodes[i].nodeType === 1) {
                    renderer.appendChild(fieldset, element.childNodes[i]);
                }
            }
            renderer.appendChild(element, fieldset);
        }
        else if (newVal.borderStyle) {
            renderer.removeStyle(element, 'border');
            for (const key of Object.keys(newVal.borderStyle)) {
                renderer.setStyle(element, key.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase(), newVal.borderStyle[key]);
            }
        }
    }
    static setFont(element, renderer, newVal) {
        if (typeof newVal !== 'object' || newVal == null) {
            renderer.removeStyle(element, 'font');
            return;
        }
        renderer.removeStyle(element, 'font');
        for (const key of Object.keys(newVal)) {
            renderer.setStyle(element, key, newVal[key]);
        }
    }
    static setVisible(element, renderer, newVal) {
        let correctElement = element;
        if (renderer.parentNode(renderer.parentNode(element)) === element.closest('.svy-wrapper')) {
            correctElement = renderer.parentNode(renderer.parentNode(element));
        }
        if (newVal === true) {
            // can we improve this ?
            renderer.removeStyle(correctElement, 'display');
        }
        else if (newVal === false) {
            renderer.setStyle(correctElement, 'display', 'none');
        }
    }
    static addSelectOnEnter(element, renderer, doc) {
        renderer.listen(element, 'focus', () => {
            setTimeout(() => {
                // this access "document" directly which shoudn't really be done, but angular doesn't have encapsuled support for testing "is(":focus")"
                const currentFocusedElement = doc.querySelector(':focus');
                if (currentFocusedElement === element)
                    element.select();
            }, 0);
        });
    }
    static getScrollbarsStyleObj(scrollbars) {
        const style = {};
        /* eslint-disable no-bitwise */
        if ((scrollbars & scrollbarConstants.HORIZONTAL_SCROLLBAR_NEVER) === scrollbarConstants.HORIZONTAL_SCROLLBAR_NEVER) {
            style['overflowX'] = 'hidden';
        }
        else if ((scrollbars & scrollbarConstants.HORIZONTAL_SCROLLBAR_ALWAYS) === scrollbarConstants.HORIZONTAL_SCROLLBAR_ALWAYS) {
            style['overflowX'] = 'scroll';
        }
        else {
            style['overflowX'] = 'auto';
        }
        if ((scrollbars & scrollbarConstants.VERTICAL_SCROLLBAR_NEVER) === scrollbarConstants.VERTICAL_SCROLLBAR_NEVER) {
            style['overflowY'] = 'hidden';
        }
        else if ((scrollbars & scrollbarConstants.VERTICAL_SCROLLBAR_ALWAYS) === scrollbarConstants.VERTICAL_SCROLLBAR_ALWAYS) {
            style['overflowY'] = 'scroll'; // $NON-NLS-1$
        }
        else {
            style['overflowY'] = 'auto'; // $NON-NLS-1$
        }
        /* eslint-enable no-bitwise */
        return style;
    }
    static setScrollbars(element, renderer, value) {
        const style = this.getScrollbarsStyleObj(value);
        Object.keys(style).forEach(key => {
            renderer.setStyle(element, key, style[key]);
        });
    }
    // internal function
    static getPropByStringPath(o, s) {
        s = s.replace(/\[(\w+)\]/g, '.$1'); // convert indexes to properties
        s = s.replace(/^\./, ''); // strip a leading dot
        const a = s.split('.');
        while (a.length) {
            const n = a.shift();
            if (n in o) {
                o = o[n];
            }
            else {
                return;
            }
            return o;
        }
    }
}

let fixedFirstDayOfWeek = null;
/**
 * Returns a zero-based index for first day of the week, as used by the specified locale
 * e.g. Sunday (returns 0), or Monday (returns 1)
 *
 * @param locale
 * @returns
 */
const getFirstDayOfWeek = (locale) => {
    if (fixedFirstDayOfWeek !== null)
        return fixedFirstDayOfWeek;
    // from http://www.unicode.org/cldr/data/common/supplemental/supplementalData.xml:supplementalData/weekData/firstDay
    const firstDay = {
        bd: 5,
        mv: 5,
        ae: 6,
        af: 6,
        bh: 6,
        dj: 6,
        dz: 6,
        eg: 6,
        iq: 6,
        ir: 6,
        jo: 6,
        kw: 6,
        ly: 6,
        ma: 6,
        om: 6,
        qa: 6,
        sa: 6,
        sd: 6,
        sy: 6,
        ye: 6,
        ag: 0,
        ar: 0,
        as: 0,
        au: 0,
        br: 0,
        bs: 0,
        bt: 0,
        bw: 0,
        by: 0,
        bz: 0,
        ca: 0,
        cn: 0,
        co: 0,
        dm: 0,
        do: 0,
        et: 0,
        gt: 0,
        gu: 0,
        hk: 0,
        hn: 0,
        id: 0,
        ie: 0,
        il: 0,
        in: 0,
        jm: 0,
        jp: 0,
        ke: 0,
        kh: 0,
        kr: 0,
        la: 0,
        mh: 0,
        mm: 0,
        mo: 0,
        mt: 0,
        mx: 0,
        mz: 0,
        ni: 0,
        np: 0,
        nz: 0,
        pa: 0,
        pe: 0,
        ph: 0,
        pk: 0,
        pr: 0,
        py: 0,
        sg: 0,
        sv: 0,
        th: 0,
        tn: 0,
        tt: 0,
        tw: 0,
        um: 0,
        us: 0,
        ve: 0,
        vi: 0,
        ws: 0,
        za: 0,
        zw: 0
    };
    const split = locale.split('-');
    const country = split.length > 1 ? split[1].toLowerCase() : split[0].toLowerCase();
    const dow = firstDay[country];
    return (dow === undefined) ? 1 : dow; /*Number*/
};
/**
 * Floors the specified date to the beginning of week.
 *
 * @param date
 * @returns
 */
const floorToWeek = (date) => {
    const fd = getFirstDayOfWeek(date.locale);
    const day = date.weekday % 7; // convert to 0=sunday .. 6=saturday
    const dayAdjust = day >= fd ? -day + fd : -day + fd - 7;
    return date.plus({ days: dayAdjust });
};
const setFirstDayOfWeek = (value) => {
    fixedFirstDayOfWeek = value;
};

class PopupForm {
}
class Callback {
}

class SpecTypesService {
    constructor(logFactory) {
        this.registeredCustomObjectTypes = new Map();
        this.log = (logFactory ?? inject(LoggerFactory)).getLogger('SpecTypesService');
    }
    /**
     * This method is DEPRECATED, as now, more .spec info about components/services is being sent to client (types + pushToServer info), and
     * for pushToServer SHALLOW or DEEP in .spec file (for custom objects/custom arrays), a proxy object will be used
     * on client to automatically detect reference changes and send them to server as needed.
     *
     * So there isn't a need anymore to provide 'watched' properties list by extending BaseCustomObject or manually pushing them. Just make sure that, if it
     * has pushToServer > ALLOW and if you assign a new full value (array or obj) to the property on client, read it back from the model after it's pushed to server (as that will be
     * updated/wrapped into a Proxy of your new value) and use that one instead.
     *
     * If you still need/want to use a custom class for your custom objects (maybe you want to have methods on them or do instanceof Checks in code...) you
     * can do that by calling registerCustomObjectType(...) instead; the constructor's class you give there does not need to be a BaseCustomObject. For backwards
     * compatibility, this method will call the new registerCustomObjectType(...).
     *
     * @deprecated
     */
    registerType(customObjectTypeName, customObjectTypeConstructor) {
        this.log.info(this.log.buildMessage(() => ('SpecTypesService * SpecTypesService.registerTypeupdates and extending BaseCustomObject is no longer necessary. Code that registers it for "'
            + customObjectTypeName + '", "' + customObjectTypeConstructor + '" should be safe to remove/clean up (as long as the servoy component definition .spec file is ok). If you really need a custom class for these custom objects client-side '
            + ' do call registerCustomObjectType() instead, so that the no-arg constructor that you give there can be used for new objects that come from the server.')));
        this.registerCustomObjectType(customObjectTypeName, customObjectTypeConstructor);
    }
    /**
     * Registers a custom object type constructor to the system for components that want to use specialized classes for custom objects that come from the server.
     *
     * Calling this IS NOT MANDATORY. You can just use simple interfaces (or interfaces that extend as well ICustomObjectValue) for your custom objects now. See .registerType(...) deprecation comment for more information.
     *
     * @param customObjectTypeName the type name as defined in the .spec of the component/service, prefixed with the name of the
     *          component/service + ".". For example "bootstrapextracomponents-navbar.menuItem".
     * @param customObjectTypeConstructor a constructor that custom object type should use when receiving new values from the server for
     *          the given customObjectTypeName. Be aware though that the values of the given class constructor will be augmented (via prototype chain)
     *          with some internal implementation of the custom object type.
     */
    registerCustomObjectType(customObjectTypeName, customObjectTypeConstructor) {
        this.registeredCustomObjectTypes.set(customObjectTypeName, customObjectTypeConstructor);
    }
    getRegisteredCustomObjectTypeConstructor(customObjectTypeName) {
        return this.registeredCustomObjectTypes.get(customObjectTypeName);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SpecTypesService, deps: [{ token: LoggerFactory }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SpecTypesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: SpecTypesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: LoggerFactory }] });
/**
 * This type is DEPRECATED.
 *
 * You can remove extends BaseCustomObject from any custom types that you have.
 *
 * You can even turn your custom types into interfaces (that can also - optionally - implement ICustomObjectValue - if you need that; see details below). The
 * system will automatically generate the correct object for that interface (as long as it follows what is defined in the .spec file for this custom
 * object) - and you can use it.
 *
 * For example you can use something like ('extends ICustomObjectValue' is only needed for sending deeply nested changes to server in case of plain 'object'
 * typed subproperties):
 *      @Input() myCustomObjectProperty: IMyCustomObject;
 *
 *      interface IMyCustomObject extends ICustomObjectValue {
 *          p1: string; // for example
 *          (... any properties that are defined in the component's spec file for this custom object ...)
 *      }
 *
 * Now, more .spec info about components/services is being automatically sent to client (types + pushToServer info), and
 * for pushToServer SHALLOW/DEEP or even for ALLOW in .spec file (for custom objects/custom arrays), a proxy object will be used
 * on client to automatically detect reference changes in subproperties (and send them to server if it is SHALLOW/DEEP) (note: for deep nested JSON changes
 * in plain 'object' subproperties - if any - you need to use ICustomObjectValue interface in order to tell the system that it changed, but
 * that is probably rarely needed).
 *
 * So there isn't a need anymore to provide 'watched' properties list by extending BaseCustomObject or to manually push them to server by using
 * getter/setter pair; that is done automatically via use of Proxy objects. Just make sure that, if it has pushToServer >= ALLOW, and if you assign
 * a new full value (full custom object value - although it is the same for arrays from .spec as well) to the property on client-side, you read it
 * back from the model when you need to use it (as that reference will be updated to a newly created Proxy of your new value - after being sent to server)
 * and use the new reference instead.
 *
 * @deprecated
 */
class BaseCustomObject {
    /**
     * DEPRECATED: See class jsdoc for more information.
     *
     * @deprecated
     */
    getStateHolder() {
        return getDeprecatedCustomObjectState(); // dummy; just not to generate compile errors for older code
    }
    /**
     * DEPRECATED: See class jsdoc for more information.
     *
     * @deprecated
     */
    getWatchedProperties() {
        return null;
    }
}
/**
 * DEPRECATED: See BaseCustomObject jsdoc for more information.
 *
 * @deprecated
 */
class BaseCustomObjectState {
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    getChangedKeys() {
        return new Set(); // dummy; just not to generate compile errors for older code
    }
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    markAllChanged(_notifyListener) { }
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    setPropertyAndHandleChanges(thisBaseCustoomObject, internalPropertyName, _propertyName, value) {
        thisBaseCustoomObject[internalPropertyName] = value;
    }
    /**
     * DEPRECATED: See BaseCustomObject jsdoc for more information.
     *
     * @deprecated
     */
    notifyChangeListener() { }
}
/**
 * This type is DEPRECATED - see ICustomArray jsdoc for more information.
 *
 * @deprecated
 */
class ArrayState extends BaseCustomObjectState {
    /**
     * DEPRECATED: See ICustomArray jsdoc for more information.
     *
     * @deprecated
     */
    initDiffer() {
    }
    /**
     * DEPRECATED: See ICustomArray jsdoc for more information.
     *
     * @deprecated
     */
    clearChanges() {
    }
    /**
     * DEPRECATED: See ICustomArray jsdoc for more information.
     *
     * @deprecated
     */
    getChangedKeys() {
        return super.getChangedKeys();
    }
}
let deprecatedCustomObjectState;
let deprecatedCustomArrayState;
/** @deprecated see BaseCustomObjectState jsdoc */
const getDeprecatedCustomObjectState = () => {
    if (!deprecatedCustomObjectState)
        deprecatedCustomObjectState = new BaseCustomObjectState();
    return deprecatedCustomObjectState;
};
/** @deprecated see ArrayState jsdoc */
const getDeprecatedCustomArrayState = () => {
    if (!deprecatedCustomArrayState)
        deprecatedCustomArrayState = new ArrayState();
    return deprecatedCustomArrayState;
};
;
var ChangeType;
(function (ChangeType) {
    ChangeType[ChangeType["ROWS_CHANGED"] = 0] = "ROWS_CHANGED";
    /**
     * When an INSERT happened but viewport size remained the same, it is
     * possible that some of the rows that were previously at the end of the viewport
     * slided out of it;
     * NOTE: insert signifies an insert into the client viewport, not necessarily
     * an insert in the foundset itself; for example calling "loadExtraRecordsAsync"
     * can result in an insert notification + bigger viewport size notification
     */
    ChangeType[ChangeType["ROWS_INSERTED"] = 1] = "ROWS_INSERTED";
    /**
     * When a DELETE happened inside the viewport but there were more rows available in the
     * foundset after current viewport, it is possible that some of those rows
     * slided into the viewport;
     * NOTE: delete signifies a delete from the client viewport, not necessarily
     * a delete in the foundset itself; for example calling "loadLessRecordsAsync" can
     * result in a delete notification + smaller viewport size notification
     */
    ChangeType[ChangeType["ROWS_DELETED"] = 2] = "ROWS_DELETED";
})(ChangeType || (ChangeType = {}));

class ServoyPublicServiceTestingImpl extends ServoyPublicService {
    constructor() {
        super(...arguments);
        this.messages = {};
        this.forms = {};
        this.localeNumberSymbol = null;
    }
    addForm(name, formCache) {
        this.forms[name] = formCache;
    }
    getFormCacheByName(containedForm) {
        if (this.forms[containedForm])
            return this.forms[containedForm];
        const form = {
            absolute: true,
            size: { width: 100, height: 100 },
            getComponent: (name) => {
                const comp = {
                    name,
                    model: {},
                    layout: {}
                };
                return comp;
            }
        };
        return form;
    }
    generateServiceUploadUrl(serviceName, apiFunctionName) {
        return 'resources/upload/1/svy_services/' + serviceName + '/' + apiFunctionName;
    }
    generateUploadUrl(formname, componentName, propertyName) {
        return 'resources/upload/1' +
            (formname ? '/' + formname : '') +
            (componentName ? '/' + componentName : '') +
            (propertyName ? '/' + propertyName : '');
    }
    generateMediaDownloadUrl(media) {
        return null;
    }
    getUIProperty(key) {
        return null;
    }
    executeInlineScript(formname, script, params) {
        throw new Error('Method not implemented.');
    }
    callServiceServerSideApi(servicename, methodName, args) {
        throw new Error('Method not implemented.');
    }
    addMessage(key, message) {
        this.messages[key] = message;
    }
    getI18NMessages(...keys) {
        const resolvedMessages = {};
        keys.forEach(key => resolvedMessages[key] = this.messages[key] ? this.messages[key] : '');
        return Promise.resolve(resolvedMessages);
    }
    listenForI18NMessages(...keys) {
        throw new Error('Method not implemented.');
    }
    callService(serviceName, methodName, argsObject, async) {
        throw new Error('Method not implemented.');
    }
    setLocale(locale) {
        this.locale = locale;
    }
    getLocale() {
        return this.locale ? this.locale.language : 'en';
    }
    getLocaleObject() {
        return this.locale ? this.locale : { language: 'en', country: 'US', full: 'en-US' };
    }
    getAGGridLocale() {
        return null;
    }
    createJSEvent(event, eventType, contextFilter, contextFilterElement) {
        const ev = new JSEvent();
        ev.eventType = eventType;
        ev.svyType = eventType;
        ev.formName = 'test';
        ev.elementName = 'test';
        ev.timestamp = new Date().getTime();
        return ev;
    }
    showFileOpenDialog(title, multiselect, acceptFilter, url) {
        throw new Error('Method not implemented.');
    }
    showMessageDialog(dialogTitle, dialogMessage, styleClass, values, buttonsText, inputType) {
        throw new Error('Method not implemented.');
    }
    getLocaleNumberSymbol(symbol) {
        if (this.localeNumberSymbol)
            return this.localeNumberSymbol;
        return super.getLocaleNumberSymbol(symbol);
    }
    setLocaleNumberSymbol(symbol) {
        this.localeNumberSymbol = symbol;
    }
    /** @deprecated */
    sendServiceChanges(_serviceName, _propertyName, _propertyValue) { }
    sendServiceChangeToServer(_serviceName, _propertyName, _propertyValue, _oldPropertyValue) { }
    showForm(_popup) { }
    cancelFormPopup(_disableClearPopupFormCallToServer_or_name) { }
    setFormStyleClasses(_styleclasses) { }
    isInTestingMode() {
        return false;
    }
    getTemplateForFormComponentChild(_formName, _item) {
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicServiceTestingImpl, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicServiceTestingImpl }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicServiceTestingImpl, decorators: [{
            type: Injectable
        }] });
class ServoyPublicTestingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicTestingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicTestingModule, imports: [ServoyPublicModule], exports: [ServoyPublicModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicTestingModule, providers: [
            ServoyPublicServiceTestingImpl, { provide: ServoyPublicService, useExisting: ServoyPublicServiceTestingImpl }
        ], imports: [ServoyPublicModule, ServoyPublicModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: ServoyPublicTestingModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [
                        ServoyPublicModule
                    ],
                    exports: [
                        ServoyPublicModule
                    ],
                    providers: [
                        ServoyPublicServiceTestingImpl, { provide: ServoyPublicService, useExisting: ServoyPublicServiceTestingImpl }
                    ],
                    schemas: []
                }]
        }] });

class ServoyApiTesting {
    formWillShow(formname, relationname, formIndex) {
        return Promise.resolve(true);
    }
    hideForm(formname, relationname, formIndex, formNameThatWillShow, relationnameThatWillBeShown, formIndexThatWillBeShown) {
        return Promise.resolve(true);
    }
    startEdit(propertyName) {
    }
    apply(propertyName, value) {
    }
    callServerSideApi(methodName, args) {
        return Promise.resolve(null);
    }
    isInDesigner() {
        return false;
    }
    trustAsHtml() {
        return false;
    }
    isInAbsoluteLayout() {
        return true;
    }
    getMarkupId() {
        return 'testid';
    }
    getFormName() {
        return 'testform';
    }
    registerComponent(component) {
    }
    unRegisterComponent(component) {
    }
    getClientProperty(key) {
        return key;
    }
}

// eslint-disable-next-line prefer-arrow/prefer-arrow-functions
async function runOnPushChangeDetection(cf) {
    const cd = cf.debugElement.injector.get(ChangeDetectorRef);
    cd.detectChanges();
    return cf.whenStable();
}

class PopupStateService {
    constructor() {
        this.activePopups = new Set();
        this.activePopupCount = signal(0, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "activePopupCount" }] : /* istanbul ignore next */ []));
        this.isPopupActive = computed(() => this.activePopupCount() > 0, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "isPopupActive" }] : /* istanbul ignore next */ []));
    }
    isAnyPopupActive() {
        return this.activePopups.size > 0;
    }
    activatePopup(id) {
        this.activePopups.add(id);
        this.activePopupCount.set(this.activePopups.size);
    }
    deactivatePopup(id) {
        setTimeout(() => {
            this.activePopups.delete(id);
            this.activePopupCount.set(this.activePopups.size);
        }, 200); // a delay is required to allow the window.service.ts keyListener to complete execution
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: PopupStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: PopupStateService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.0", ngImport: i0, type: PopupStateService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ArrayState, AutosaveDirective, BaseCustomObject, BaseCustomObjectState, Callback, ChangeType, ComponentContributor, DecimalkeyconverterDirective, Deferred, EmptyValueFilterPipe, Format, FormatDirective, FormatFilterPipe, FormattingService, HTMLTooltipDirective, HtmlFilterPipe, ImageMediaIdDirective, JSEvent, LocalStorageService, LogConfiguration, LogLevel, LoggerFactory, LoggerService, MainViewRefService, MaskFormat, MnemonicletterFilterPipe, NotNullOrEmptyPipe, PopupForm, PopupStateService, PropertyUtils, SabloTabseq, ServoyApi, ServoyApiTesting, ServoyBaseComponent, ServoyPublicModule, ServoyPublicService, ServoyPublicServiceTestingImpl, ServoyPublicTestingModule, SessionStorageService, SpecTypesService, StartEditDirective, TabFixDirective, TooltipDirective, TooltipService, TrustAsHtmlPipe, UploadDirective, WindowRefService, floorToWeek, getDeprecatedCustomArrayState, getFirstDayOfWeek, runOnPushChangeDetection, setFirstDayOfWeek };
//# sourceMappingURL=servoy-public.mjs.map
